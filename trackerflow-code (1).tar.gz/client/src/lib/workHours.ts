export type WorkDay = {
  enabled: boolean;
  start: string;
  end: string;
};

export type WorkHours = {
  mon: WorkDay;
  tue: WorkDay;
  wed: WorkDay;
  thu: WorkDay;
  fri: WorkDay;
  sat: WorkDay;
  sun: WorkDay;
};

export const WORK_HOURS_KEY = "trackerflow_work_hours_v1";

export const DEFAULT_WORK_HOURS: WorkHours = {
  mon: { enabled: true,  start: "09:00", end: "17:00" },
  tue: { enabled: true,  start: "09:00", end: "17:00" },
  wed: { enabled: true,  start: "09:00", end: "17:00" },
  thu: { enabled: true,  start: "09:00", end: "17:00" },
  fri: { enabled: true,  start: "09:00", end: "17:00" },
  sat: { enabled: false, start: "09:00", end: "13:00" },
  sun: { enabled: false, start: "09:00", end: "13:00" },
};

export function loadWorkHours(): WorkHours {
  try {
    const raw = localStorage.getItem(WORK_HOURS_KEY);
    if (!raw) return DEFAULT_WORK_HOURS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_WORK_HOURS,
      ...parsed,
      mon: { ...DEFAULT_WORK_HOURS.mon, ...(parsed.mon || {}) },
      tue: { ...DEFAULT_WORK_HOURS.tue, ...(parsed.tue || {}) },
      wed: { ...DEFAULT_WORK_HOURS.wed, ...(parsed.wed || {}) },
      thu: { ...DEFAULT_WORK_HOURS.thu, ...(parsed.thu || {}) },
      fri: { ...DEFAULT_WORK_HOURS.fri, ...(parsed.fri || {}) },
      sat: { ...DEFAULT_WORK_HOURS.sat, ...(parsed.sat || {}) },
      sun: { ...DEFAULT_WORK_HOURS.sun, ...(parsed.sun || {}) },
    };
  } catch {
    return DEFAULT_WORK_HOURS;
  }
}

export function saveWorkHours(v: WorkHours) {
  localStorage.setItem(WORK_HOURS_KEY, JSON.stringify(v));
}

export function weekdayKeyFromDate(d: Date): keyof WorkHours {
  const map: (keyof WorkHours)[] = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  return map[d.getDay()];
}

export function minutesFromHHMM(hhmm: string) {
  const [h, m] = hhmm.split(":").map((x) => Number(x));
  return (h || 0) * 60 + (m || 0);
}
