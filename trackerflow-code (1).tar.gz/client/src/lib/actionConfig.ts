export type ActionType = "call" | "text" | "email";

export type ActionConfig = {
  enabled: boolean;
  mode: "system" | "custom";
  customUrlTemplate: string;
};

export const ACTION_KEY = "trackerflow_action_config_v1";

export const ACTION_DEFAULTS: Record<ActionType, ActionConfig> = {
  call:  { enabled: true, mode: "system", customUrlTemplate: "tel:{phone}" },
  text:  { enabled: true, mode: "system", customUrlTemplate: "sms:{phone}" },
  email: { enabled: true, mode: "system", customUrlTemplate: "mailto:{email}" },
};

export function loadActionCfg(): Record<ActionType, ActionConfig> {
  try {
    const raw = localStorage.getItem(ACTION_KEY);
    if (!raw) return ACTION_DEFAULTS;
    const parsed = JSON.parse(raw);
    return {
      call:  { ...ACTION_DEFAULTS.call,  ...(parsed.call  || {}) },
      text:  { ...ACTION_DEFAULTS.text,  ...(parsed.text  || {}) },
      email: { ...ACTION_DEFAULTS.email, ...(parsed.email || {}) },
    };
  } catch {
    return ACTION_DEFAULTS;
  }
}

export function buildActionUrl(type: ActionType, cfg: ActionConfig, phone: string, email: string): string {
  const samplePhone = phone.replace(/\D/g, "");
  if (cfg.mode === "system") {
    if (type === "call") return `tel:${phone}`;
    if (type === "text") return `sms:${phone}`;
    if (type === "email") return `mailto:${email}`;
  }
  return cfg.customUrlTemplate
    .replace(/\{phone\}/g, samplePhone)
    .replace(/\{email\}/g, email);
}
