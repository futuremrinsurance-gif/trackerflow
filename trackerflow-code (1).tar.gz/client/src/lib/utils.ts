import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function groupLeadsBySource(leads: any[]) {
  const sorted = [...leads].sort((a, b) => {
    const ga = String(a.leadSource || "Unsorted").toLowerCase();
    const gb = String(b.leadSource || "Unsorted").toLowerCase();
    if (ga < gb) return -1;
    if (ga > gb) return 1;
    const ta = a.timesCalled ?? 0;
    const tb = b.timesCalled ?? 0;
    if (tb !== ta) return tb - ta;
    const la = String(a.lastName || "").toLowerCase();
    const lb = String(b.lastName || "").toLowerCase();
    if (la !== lb) return la < lb ? -1 : 1;
    const fa = String(a.firstName || "").toLowerCase();
    const fb = String(b.firstName || "").toLowerCase();
    return fa < fb ? -1 : fa > fb ? 1 : 0;
  });

  const groups: Record<string, any[]> = {};
  for (const l of sorted) {
    const key = l.leadSource || "Unsorted";
    groups[key] = groups[key] || [];
    groups[key].push(l);
  }

  return Object.keys(groups)
    .sort((a, b) => a.localeCompare(b))
    .map((k) => ({ name: k, leads: groups[k] }));
}

export const STATUSES = [
  "New",
  "Attempted Contact",
  "Contacted",
  "Quoted",
  "Follow-Up Scheduled",
  "Sold",
  "Lost",
  "Declined",
] as const;

export const INSURANCE_TYPES = ["Auto", "Home", "Life", "Health", "Commercial", "Other"] as const;
export const PRIORITIES = ["Hot", "Warm", "Cold"] as const;

export function statusColor(status: string) {
  const map: Record<string, string> = {
    New: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
    "Attempted Contact": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
    Contacted: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
    Quoted: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
    "Follow-Up Scheduled": "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-300",
    Sold: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
    Lost: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
    Declined: "bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300",
  };
  return map[status] ?? "bg-muted text-muted-foreground";
}

export function priorityColor(priority: string) {
  const map: Record<string, string> = {
    Hot: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
    Warm: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
    Cold: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300",
  };
  return map[priority] ?? "bg-muted text-muted-foreground";
}

export function insuranceColor(insurance: string) {
  const map: Record<string, string> = {
    Auto: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300",
    Home: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
    Life: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300",
    Health: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300",
    Commercial: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
    Other: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  };
  return map[insurance] ?? "bg-muted text-muted-foreground";
}

export function formatDate(date: string | Date | null) {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(new Date(date));
}

export function formatDateTime(date: string | Date | null) {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(date));
}

export function formatRelative(date: string | Date | null) {
  if (!date) return "—";
  const d = new Date(date);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);
  if (diffMin < 1) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return formatDate(date);
}

export function daysSince(date: string | Date | null): number {
  if (!date) return 0;
  const d = new Date(date);
  const now = new Date();
  return Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
}
