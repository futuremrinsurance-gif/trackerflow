const INSURANCE_KEY = "trackerflow_insurance_types_v1";
const LEAD_SOURCES_KEY = "trackerflow_lead_sources_v1";
const DEFAULT_STATE_KEY = "trackerflow_default_state_v1";

export const DEFAULT_INSURANCE_TYPES = [
  "Auto",
  "Home",
  "Life",
  "Health",
  "Commercial",
  "Other",
];

export const DEFAULT_LEAD_SOURCES = [
  "Facebook Ads",
  "Google Ads",
  "Referral",
  "Cold Call",
  "Website",
  "Other",
];

export const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA",
  "HI","ID","IL","IN","IA","KS","KY","LA","ME","MD",
  "MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
  "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY",
];

function loadList(key: string, defaults: string[]): string[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [...defaults];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : [...defaults];
  } catch {
    return [...defaults];
  }
}

function saveList(key: string, list: string[]) {
  localStorage.setItem(key, JSON.stringify(list));
}

export function loadInsuranceTypes(): string[] {
  return loadList(INSURANCE_KEY, DEFAULT_INSURANCE_TYPES);
}

export function saveInsuranceTypes(types: string[]) {
  saveList(INSURANCE_KEY, types);
}

export function loadLeadSources(): string[] {
  return loadList(LEAD_SOURCES_KEY, DEFAULT_LEAD_SOURCES);
}

export function saveLeadSources(sources: string[]) {
  saveList(LEAD_SOURCES_KEY, sources);
}

export function loadDefaultState(): string {
  return localStorage.getItem(DEFAULT_STATE_KEY) ?? "";
}

export function saveDefaultState(state: string) {
  localStorage.setItem(DEFAULT_STATE_KEY, state);
}

const PREMIUM_GOAL_KEY = "trackerflow_premium_goal_v1";

export function loadPremiumGoal(): number {
  const raw = localStorage.getItem(PREMIUM_GOAL_KEY);
  if (!raw) return 0;
  const n = parseInt(raw, 10);
  return isNaN(n) ? 0 : n;
}

export function savePremiumGoal(goal: number) {
  localStorage.setItem(PREMIUM_GOAL_KEY, String(Math.max(0, goal)));
}

const AGENCY_COMPANY_KEY = "trackerflow_agency_company_v1";

export function loadAgencyCompany(): string {
  return localStorage.getItem(AGENCY_COMPANY_KEY) ?? "";
}

export function saveAgencyCompany(name: string) {
  localStorage.setItem(AGENCY_COMPANY_KEY, name.trim());
  window.dispatchEvent(new StorageEvent("storage", { key: AGENCY_COMPANY_KEY }));
}
