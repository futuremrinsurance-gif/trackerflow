import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useAuth } from "@/hooks/use-auth";
import LoginPage from "@/pages/login";
import NotFound from "@/pages/not-found";
import LeadsPage from "@/pages/leads";
import NewLeadPage from "@/pages/new-lead";
import LeadDetailPage from "@/pages/lead-detail";
import PipelinePage from "@/pages/pipeline";
import AnalyticsPage from "@/pages/analytics";
import DashboardPage from "@/pages/dashboard";
import ArchivePage from "@/pages/archive";

import SettingsPage from "@/pages/settings";
import SharePage from "@/pages/share";

function Router() {
  return (
    <Switch>
      <Route path="/" component={DashboardPage} />
      <Route path="/leads" component={LeadsPage} />
      <Route path="/leads/new" component={NewLeadPage} />
      <Route path="/leads/:id" component={LeadDetailPage} />
      <Route path="/pipeline" component={PipelinePage} />
      <Route path="/analytics" component={AnalyticsPage} />
      <Route path="/archive" component={ArchivePage} />

      <Route path="/settings" component={SettingsPage} />
      <Route path="/share" component={SharePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

const sidebarStyle = {
  "--sidebar-width": "14rem",
  "--sidebar-width-icon": "3rem",
} as React.CSSProperties;

function AppShell() {
  const { isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30">
        <div className="flex flex-col items-center gap-3">
          <img src="/logo.png" alt="TrackerFlow" className="w-12 h-12 rounded-xl object-contain animate-pulse" />
          <p className="text-sm text-muted-foreground font-medium">Loading…</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full overflow-hidden">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center gap-3 px-4 py-3 border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-40">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </header>
          <main className="flex-1 overflow-y-auto pb-16">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppShell />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
