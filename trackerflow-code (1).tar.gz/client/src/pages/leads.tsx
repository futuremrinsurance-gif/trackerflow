import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Users, PhoneCall, RefreshCw, Upload, Download, Trash2, ChevronDown, ChevronRight, Square, CheckSquare, Archive, Filter, X, ArrowUpDown } from "lucide-react";
import { cn, groupLeadsBySource, statusColor, insuranceColor, formatRelative, STATUSES } from "@/lib/utils";
import { useState, useCallback, useEffect } from "react";
import type { Lead } from "@shared/schema";
import ExcelImportDialog from "@/components/excel-import-dialog";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LeadSheet } from "@/components/lead-sheet";

function TimesCalledDots({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 9 }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "w-1.5 h-1.5 rounded-full transition-colors",
            i < value
              ? value >= 7
                ? "bg-red-500"
                : value >= 4
                ? "bg-amber-500"
                : "bg-primary"
              : "bg-muted-foreground/20"
          )}
        />
      ))}
    </div>
  );
}

async function downloadExport(ids: string[], includeArchived: boolean, filename: string) {
  const res = await fetch("/api/export/leads", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ids, includeArchived }),
  });
  if (!res.ok) throw new Error("Export failed");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function LeadsPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [progressFilter, setProgressFilter] = useState("all");
  const [importOpen, setImportOpen] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [timesOrder, setTimesOrder] = useState<"desc" | "asc">("desc");
  const [sheetLeadId, setSheetLeadId] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem("leads-collapsed-groups");
      return saved ? new Set<string>(JSON.parse(saved)) : new Set<string>();
    } catch { return new Set<string>(); }
  });
  const [exporting, setExporting] = useState(false);

  const { data: leads = [], isLoading, refetch } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const archiveMutation = useMutation({
    mutationFn: (id: string) =>
      apiRequest("PATCH", `/api/leads/${id}`, { isArchived: true, archivedAt: new Date().toISOString() }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: "Lead archived", description: "Moved to archive." });
    },
  });

  const filtered = leads.filter((l) => {
    if (search) {
      const q = search.toLowerCase();
      const matchesSearch =
        l.firstName.toLowerCase().includes(q) ||
        l.lastName.toLowerCase().includes(q) ||
        (l.phone ?? "").includes(q) ||
        (l.leadSource ?? "").toLowerCase().includes(q) ||
        (l.city ?? "").toLowerCase().includes(q);
      if (!matchesSearch) return false;
    }
    if (statusFilter !== "all" && l.status !== statusFilter) return false;
    if (progressFilter !== "all") {
      const calls = l.timesCalled ?? 0;
      if (progressFilter === "0" && calls !== 0) return false;
      if (progressFilter === "1-3" && (calls < 1 || calls > 3)) return false;
      if (progressFilter === "4-6" && (calls < 4 || calls > 6)) return false;
      if (progressFilter === "7-9" && (calls < 7 || calls > 9)) return false;
    }
    return true;
  });

  const hasFilters = statusFilter !== "all" || progressFilter !== "all";

  const rawGroups = groupLeadsBySource(filtered);
  const groups = rawGroups.map((g) => ({
    ...g,
    leads: [...g.leads].sort((a, b) => {
      const ta = a.timesCalled ?? 0;
      const tb = b.timesCalled ?? 0;
      if (ta !== tb) return timesOrder === "desc" ? tb - ta : ta - tb;
      const na = `${a.lastName} ${a.firstName}`.toLowerCase();
      const nb = `${b.lastName} ${b.firstName}`.toLowerCase();
      return na < nb ? -1 : na > nb ? 1 : 0;
    }),
  }));
  const allIds = filtered.map((l) => l.id);
  const allSelected = allIds.length > 0 && allIds.every((id) => selected.has(id));
  const someSelected = selected.size > 0;

  function toggleSelect(id: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function toggleSelectAll() {
    if (allSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(allIds));
    }
  }

  function toggleGroupSelect(groupLeadIds: string[], e: React.MouseEvent) {
    e.stopPropagation();
    const allGroupSelected = groupLeadIds.every((id) => selected.has(id));
    setSelected((prev) => {
      const next = new Set(prev);
      if (allGroupSelected) {
        groupLeadIds.forEach((id) => next.delete(id));
      } else {
        groupLeadIds.forEach((id) => next.add(id));
      }
      return next;
    });
  }

  useEffect(() => {
    try { localStorage.setItem("leads-collapsed-groups", JSON.stringify(Array.from(collapsed))); } catch {}
  }, [collapsed]);

  function toggleCollapse(name: string) {
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(name) ? next.delete(name) : next.add(name);
      return next;
    });
  }

  const handleExport = useCallback(async () => {
    setExporting(true);
    try {
      const ids = someSelected ? Array.from(selected) : [];
      await downloadExport(ids, false, "active-leads.xlsx");
      toast({ title: `Exported ${ids.length || leads.length} lead${(ids.length || leads.length) !== 1 ? "s" : ""}` });
    } catch {
      toast({ title: "Export failed", variant: "destructive" });
    } finally {
      setExporting(false);
    }
  }, [selected, someSelected, leads.length, toast]);

  const [archivingSelected, setArchivingSelected] = useState(false);
  const handleArchiveSelected = useCallback(async () => {
    const ids = Array.from(selected);
    if (!ids.length) return;
    setArchivingSelected(true);
    try {
      await Promise.all(
        ids.map((id) => apiRequest("PATCH", `/api/leads/${id}`, { isArchived: true }))
      );
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: `${ids.length} lead${ids.length !== 1 ? "s" : ""} archived` });
    } catch {
      toast({ title: "Archive failed", variant: "destructive" });
    } finally {
      setArchivingSelected(false);
    }
  }, [selected, toast]);

  const [deleting, setDeleting] = useState(false);
  const handleDeleteSelected = useCallback(async () => {
    const ids = Array.from(selected);
    if (!ids.length) return;
    const confirmed = window.confirm(
      `Permanently delete ${ids.length} lead${ids.length !== 1 ? "s" : ""}? This cannot be undone.`
    );
    if (!confirmed) return;
    setDeleting(true);
    try {
      await Promise.all(ids.map((id) => apiRequest("DELETE", `/api/leads/${id}`)));
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: `${ids.length} lead${ids.length !== 1 ? "s" : ""} deleted` });
    } catch {
      toast({ title: "Delete failed", variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  }, [selected, toast]);

  return (
    <div className="p-6 space-y-5 max-w-5xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-black tracking-tight">Leads</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {leads.length} active lead{leads.length !== 1 ? "s" : ""} grouped by source
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button size="icon" variant="outline" onClick={() => refetch()} data-testid="button-refresh">
            <RefreshCw className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setTimesOrder(timesOrder === "desc" ? "asc" : "desc")}
            data-testid="button-sort-times-called"
          >
            <ArrowUpDown className="w-3.5 h-3.5 mr-1.5" />
            Calls: {timesOrder === "desc" ? "High → Low" : "Low → High"}
          </Button>
          <Button variant="outline" onClick={() => setImportOpen(true)} data-testid="button-import-excel">
            <Upload className="w-4 h-4 mr-1.5" />
            Import
          </Button>
          {!isLoading && leads.length > 0 && (
            <Button
              variant="outline"
              onClick={handleExport}
              disabled={exporting}
              data-testid="button-export-leads"
            >
              <Download className="w-4 h-4 mr-1.5" />
              {someSelected ? `Export (${selected.size})` : "Export All"}
            </Button>
          )}
          {someSelected && (
            <Button
              variant="outline"
              onClick={handleArchiveSelected}
              disabled={archivingSelected}
              data-testid="button-archive-selected"
              className="border-amber-300 text-amber-700 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-400 dark:hover:bg-amber-950"
            >
              <Archive className="w-4 h-4 mr-1.5" />
              Archive ({selected.size})
            </Button>
          )}
          {someSelected && (
            <Button
              variant="destructive"
              onClick={handleDeleteSelected}
              disabled={deleting}
              data-testid="button-delete-selected"
            >
              <Trash2 className="w-4 h-4 mr-1.5" />
              Delete ({selected.size})
            </Button>
          )}
          <Button asChild data-testid="button-new-lead">
            <Link href="/leads/new">
              <Plus className="w-4 h-4 mr-1.5" />
              New Lead
            </Link>
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search leads by name, phone, city, or source…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-leads"
          />
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36" data-testid="select-filter-status">
            <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {STATUSES.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={progressFilter} onValueChange={setProgressFilter}>
          <SelectTrigger className="w-36" data-testid="select-filter-progress">
            <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
            <SelectValue placeholder="Calls" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Progress</SelectItem>
            <SelectItem value="0">No calls (0)</SelectItem>
            <SelectItem value="1-3">Early (1–3 calls)</SelectItem>
            <SelectItem value="4-6">Mid (4–6 calls)</SelectItem>
            <SelectItem value="7-9">Late (7–9 calls)</SelectItem>
          </SelectContent>
        </Select>

        {hasFilters && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => { setStatusFilter("all"); setProgressFilter("all"); }}
            className="text-xs text-muted-foreground"
            data-testid="button-clear-filters"
          >
            <X className="w-3.5 h-3.5 mr-1" />
            Clear
          </Button>
        )}

        {!isLoading && leads.length > 0 && (
          <Button
            size="sm"
            variant="ghost"
            onClick={toggleSelectAll}
            className="flex-shrink-0 text-xs"
            data-testid="button-select-all"
          >
            {allSelected ? (
              <><CheckSquare className="w-4 h-4 mr-1.5 text-primary" />Deselect All</>
            ) : (
              <><Square className="w-4 h-4 mr-1.5" />Select All</>
            )}
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      ) : groups.length === 0 ? (
        <Card>
          <CardContent className="py-16 flex flex-col items-center text-center text-muted-foreground">
            <Users className="w-10 h-10 mb-3 opacity-30" />
            <p className="font-semibold">No leads found</p>
            <p className="text-sm mt-1">{search ? "Try a different search term" : "Create your first lead to get started"}</p>
            {!search && (
              <Button asChild className="mt-4" size="sm">
                <Link href="/leads/new">
                  <Plus className="w-4 h-4 mr-1.5" />
                  New Lead
                </Link>
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {groups.map((group) => {
            const groupIds = group.leads.map((l) => l.id);
            const allGroupSelected = groupIds.length > 0 && groupIds.every((id) => selected.has(id));
            const someGroupSelected = groupIds.some((id) => selected.has(id));
            const isCollapsed = collapsed.has(group.name);
            return (
              <Card key={group.name}>
                <CardHeader className="pb-3 pt-4 px-5">
                  <div
                    className="flex items-center justify-between gap-2 cursor-pointer select-none"
                    onClick={() => toggleCollapse(group.name)}
                    data-testid={`group-header-${group.name}`}
                  >
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => toggleGroupSelect(groupIds, e)}
                        className="flex-shrink-0 text-muted-foreground hover:text-primary transition-colors"
                        data-testid={`button-select-group-${group.name}`}
                        title={allGroupSelected ? "Deselect group" : "Select group"}
                      >
                        {allGroupSelected ? (
                          <CheckSquare className="w-4 h-4 text-primary" />
                        ) : someGroupSelected ? (
                          <CheckSquare className="w-4 h-4 text-primary/50" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                      <div className="w-2 h-2 rounded-full bg-primary" />
                      <span className="text-xs font-black uppercase tracking-widest text-muted-foreground">
                        {group.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="font-bold" data-testid={`badge-group-count-${group.name}`}>
                        {group.leads.length}
                      </Badge>
                      {isCollapsed
                        ? <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        : <ChevronDown className="w-4 h-4 text-muted-foreground" />
                      }
                    </div>
                  </div>
                </CardHeader>
                {!isCollapsed && (
                  <CardContent className="pt-0 px-3 pb-3">
                    <div className="space-y-2">
                      {group.leads.map((lead) => {
                        const isSelected = selected.has(lead.id);
                        return (
                          <div key={lead.id} className="relative">
                            <div
                              className={cn(
                                "group flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors bg-background/50",
                                isSelected
                                  ? "border-primary/50 bg-primary/5"
                                  : "border-border/50 hover-elevate"
                              )}
                              onClick={() => setSheetLeadId(lead.id)}
                              data-testid={`card-lead-${lead.id}`}
                            >
                              <button
                                onClick={(e) => toggleSelect(lead.id, e)}
                                className="flex-shrink-0 text-muted-foreground hover:text-primary transition-colors"
                                data-testid={`checkbox-lead-${lead.id}`}
                                title={isSelected ? "Deselect" : "Select"}
                              >
                                {isSelected
                                  ? <CheckSquare className="w-4 h-4 text-primary" />
                                  : <Square className="w-4 h-4" />
                                }
                              </button>

                              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 font-black text-sm text-primary">
                                {lead.firstName[0]}{lead.lastName[0]}
                              </div>

                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-bold text-sm">
                                    {lead.firstName} {lead.lastName}
                                  </span>
                                  <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", statusColor(lead.status))}>
                                    {lead.status}
                                  </span>
                                  <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", insuranceColor(lead.insurance))}>
                                    {lead.insurance}
                                  </span>
                                </div>
                                <div className="flex items-center gap-3 mt-1 flex-wrap">
                                  {lead.phone && (
                                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                                      <PhoneCall className="w-3 h-3" />
                                      {lead.phone}
                                    </span>
                                  )}
                                  {lead.city && (
                                    <span className="text-xs text-muted-foreground">
                                      {lead.city}{lead.state ? `, ${lead.state}` : ""}
                                    </span>
                                  )}
                                  <span className="text-xs text-muted-foreground/60">
                                    {formatRelative(lead.updatedAt)}
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 flex-shrink-0">
                                <div className="flex flex-col items-end gap-1.5 group-hover:opacity-0 transition-opacity">
                                  <TimesCalledDots value={lead.timesCalled ?? 0} />
                                  <span className="text-[10px] font-bold text-muted-foreground">
                                    {lead.timesCalled ?? 0}/9 calls
                                  </span>
                                </div>
                                <button
                                  onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    archiveMutation.mutate(lead.id);
                                  }}
                                  disabled={archiveMutation.isPending}
                                  className="absolute right-3 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-muted"
                                  title="Archive lead"
                                  data-testid={`button-archive-${lead.id}`}
                                >
                                  <Archive className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <ExcelImportDialog open={importOpen} onClose={() => setImportOpen(false)} />

      <LeadSheet
        leadId={sheetLeadId}
        open={!!sheetLeadId}
        onClose={() => setSheetLeadId(null)}
      />
    </div>
  );
}
