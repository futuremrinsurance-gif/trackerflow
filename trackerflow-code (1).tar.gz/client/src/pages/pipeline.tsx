import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw, Phone, Flame, LayoutList, ChevronDown, ChevronRight, ExternalLink } from "lucide-react";
import { cn, statusColor, insuranceColor, priorityColor } from "@/lib/utils";
import { useMemo, useState, useEffect, useCallback } from "react";
import { LeadSheet } from "@/components/lead-sheet";
import type { Lead } from "@shared/schema";

const COLLAPSED_KEY = "pipeline-collapsed-groups";

function isHighlyLikely(l: Lead) {
  const p = (l.priority || "").toLowerCase();
  const s = (l.status || "").toLowerCase();
  const engagedStatuses = new Set(["contacted", "quoted", "follow-up scheduled"]);
  return p === "hot" || engagedStatuses.has(s);
}

function leadSortKey(l: Lead) {
  const last = (l.lastName || "").trim().toLowerCase();
  const first = (l.firstName || "").trim().toLowerCase();
  return `${last}, ${first}`;
}

function sortLeads(a: Lead, b: Lead, timesOrder: "desc" | "asc") {
  const ta = a.timesCalled ?? 0;
  const tb = b.timesCalled ?? 0;
  if (ta !== tb) return timesOrder === "desc" ? tb - ta : ta - tb;
  const na = leadSortKey(a);
  const nb = leadSortKey(b);
  return na < nb ? -1 : na > nb ? 1 : 0;
}

function TimesCalledPips({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 9 }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "w-1.5 h-1.5 rounded-full",
            i < value
              ? value >= 7 ? "bg-red-500" : value >= 4 ? "bg-amber-500" : "bg-primary"
              : "bg-muted-foreground/20"
          )}
        />
      ))}
    </div>
  );
}

function LeadRow({ lead, onOpen }: { lead: Lead; onOpen: () => void }) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-3 rounded-lg border border-border/50 bg-background/60 hover-elevate cursor-pointer"
      onClick={onOpen}
      data-testid={`pipeline-row-${lead.id}`}
    >
      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 font-black text-sm text-primary">
        {lead.firstName[0]}{lead.lastName[0]}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-sm">
            {lead.firstName} {lead.lastName}
          </span>
          <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", statusColor(lead.status))}>
            {lead.status}
          </span>
          <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", insuranceColor(lead.insurance))}>
            {lead.insurance}
          </span>
          {lead.priority && (
            <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", priorityColor(lead.priority))}>
              {lead.priority}
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 mt-1.5 flex-wrap">
          <TimesCalledPips value={lead.timesCalled ?? 0} />
          <span className="text-[11px] font-bold text-muted-foreground tabular-nums">
            {lead.timesCalled ?? 0}/9
          </span>
          {lead.phone && (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Phone className="w-3 h-3" />
              {lead.phone}
            </span>
          )}
          {(lead.city || lead.state) && (
            <span className="text-xs text-muted-foreground">
              {[lead.city, lead.state].filter(Boolean).join(", ")}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        {lead.phone && (
          <Button
            size="sm"
            variant="default"
            asChild
            data-testid={`button-call-${lead.id}`}
            onClick={(e) => e.stopPropagation()}
          >
            <a href={`tel:${lead.phone}`}>
              <Phone className="w-3.5 h-3.5 mr-1" />
              Call
            </a>
          </Button>
        )}
        <Button
          size="icon"
          variant="outline"
          data-testid={`button-open-${lead.id}`}
          onClick={(e) => { e.stopPropagation(); onOpen(); }}
        >
          <ExternalLink className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

function GroupSection({
  title,
  leads,
  icon,
  accent,
  collapsed,
  onToggle,
  onOpenLead,
}: {
  title: string;
  leads: Lead[];
  icon?: React.ReactNode;
  accent?: boolean;
  collapsed: boolean;
  onToggle: () => void;
  onOpenLead: (id: string) => void;
}) {
  return (
    <Card className={cn(accent && "border-amber-200 dark:border-amber-800/50")}>
      <CardHeader className="pb-3 pt-4 px-5">
        <button
          className="flex items-center justify-between gap-2 w-full text-left"
          onClick={onToggle}
          data-testid={`toggle-group-${title.replace(/\s+/g, "-").toLowerCase()}`}
        >
          <div className="flex items-center gap-2">
            {icon ?? <div className="w-2 h-2 rounded-full bg-primary" />}
            <span className={cn(
              "text-xs font-black uppercase tracking-widest",
              accent ? "text-amber-700 dark:text-amber-400" : "text-muted-foreground"
            )}>
              {title}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="font-bold">
              {leads.length}
            </Badge>
            {collapsed
              ? <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            }
          </div>
        </button>
      </CardHeader>
      {!collapsed && (
        <CardContent className="pt-0 px-3 pb-3 space-y-2">
          {leads.length === 0 ? (
            <p className="text-sm text-muted-foreground/60 px-2 py-3 text-center">None right now</p>
          ) : (
            leads.map((l) => <LeadRow key={l.id} lead={l} onOpen={() => onOpenLead(l.id)} />)
          )}
        </CardContent>
      )}
    </Card>
  );
}

export default function PipelinePage() {
  const [timesOrder, setTimesOrder] = useState<"desc" | "asc">("desc");
  const [sheetLeadId, setSheetLeadId] = useState<string | null>(null);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem(COLLAPSED_KEY);
      return stored ? new Set(JSON.parse(stored)) : new Set<string>();
    } catch {
      return new Set<string>();
    }
  });

  useEffect(() => {
    localStorage.setItem(COLLAPSED_KEY, JSON.stringify(Array.from(collapsedGroups)));
  }, [collapsedGroups]);

  const toggleGroup = useCallback((key: string) => {
    setCollapsedGroups((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  }, []);

  const { data: leads = [], isLoading, refetch } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const { highlyLikely, groups, nextToCall } = useMemo(() => {
    const active = leads.filter((l) => !l.isArchived);

    const nextToCall = [...active]
      .sort((a, b) => {
        const ta = a.timesCalled ?? 0;
        const tb = b.timesCalled ?? 0;
        if (ta !== tb) return ta - tb;
        const pa = (a.priority || "").toLowerCase();
        const pb = (b.priority || "").toLowerCase();
        if (pa === "hot") return -1;
        if (pb === "hot") return 1;
        return leadSortKey(a).localeCompare(leadSortKey(b));
      })
      .slice(0, 5);

    const hl = active
      .filter(isHighlyLikely)
      .sort((a, b) => sortLeads(a, b, timesOrder));

    const rest = active.filter((l) => !isHighlyLikely(l));

    const map: Record<string, Lead[]> = {};
    for (const l of rest) {
      const key = (l.leadSource || "").trim() || "Unsorted";
      map[key] = map[key] || [];
      map[key].push(l);
    }

    const groupList = Object.keys(map)
      .sort((a, b) => a.localeCompare(b))
      .map((name) => ({
        name,
        leads: map[name].sort((a, b) => sortLeads(a, b, timesOrder)),
      }));

    return { highlyLikely: hl, groups: groupList, nextToCall };
  }, [leads, timesOrder]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-4 max-w-4xl mx-auto">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 rounded-xl" />
        <Skeleton className="h-48 rounded-xl" />
        <Skeleton className="h-48 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-5 max-w-4xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-black tracking-tight">Pipeline</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {leads.filter((l) => !l.isArchived).length} active leads
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setTimesOrder(timesOrder === "desc" ? "asc" : "desc")}
            data-testid="button-sort-toggle"
          >
            Times Called: {timesOrder === "desc" ? "High → Low" : "Low → High"}
          </Button>

          <Button size="icon" variant="outline" onClick={() => refetch()} data-testid="button-refresh">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <GroupSection
        title="Next To Call"
        leads={nextToCall}
        icon={<Phone className="w-3.5 h-3.5 text-primary" />}
        collapsed={collapsedGroups.has("__next-to-call__")}
        onToggle={() => toggleGroup("__next-to-call__")}
        onOpenLead={setSheetLeadId}
      />

      <GroupSection
        title="Highly Likely"
        leads={highlyLikely}
        icon={<Flame className="w-3.5 h-3.5 text-amber-500" />}
        accent
        collapsed={collapsedGroups.has("__highly-likely__")}
        onToggle={() => toggleGroup("__highly-likely__")}
        onOpenLead={setSheetLeadId}
      />

      {groups.map((g) => (
        <GroupSection
          key={g.name}
          title={g.name}
          leads={g.leads}
          collapsed={collapsedGroups.has(g.name)}
          onToggle={() => toggleGroup(g.name)}
          onOpenLead={setSheetLeadId}
        />
      ))}

      {groups.length === 0 && highlyLikely.length === leads.filter((l) => !l.isArchived).length && (
        <div className="text-center py-8 text-muted-foreground">
          <LayoutList className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm font-medium">All active leads are in the Highly Likely group</p>
        </div>
      )}

      <LeadSheet
        leadId={sheetLeadId}
        open={!!sheetLeadId}
        onClose={() => setSheetLeadId(null)}
      />
    </div>
  );
}
