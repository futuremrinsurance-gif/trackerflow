import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users,
  CheckCircle2,
  CalendarClock,
  Clock,
  AlertCircle,
  ArrowRight,
  Flame,
  Phone,
  ChevronLeft,
  ChevronRight,
  X,
  CalendarDays,
} from "lucide-react";
import { cn, statusColor, formatDateTime, daysSince } from "@/lib/utils";
import { useState } from "react";
import type { Lead, Task } from "@shared/schema";

function StatCard({ label, value, icon: Icon, sub, className }: any) {
  return (
    <Card className={cn("", className)}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">{label}</p>
            <p className="text-3xl font-black leading-none">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1.5 font-medium">{sub}</p>}
          </div>
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function TaskItem({ task, lead, onComplete, isPending }: {
  task: Task;
  lead?: Lead;
  onComplete: (id: string) => void;
  isPending: boolean;
}) {
  const now = new Date();
  const isOver = new Date(task.dueAt) < now;
  return (
    <div
      className={cn(
        "flex items-start gap-3 p-4 rounded-xl border transition-colors",
        isOver
          ? "border-red-200 bg-red-50/50 dark:border-red-900/40 dark:bg-red-950/20"
          : "border-border/50 bg-background"
      )}
      data-testid={`task-item-${task.id}`}
    >
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold truncate">{task.title || "Follow-up"}</p>
        {lead && (
          <p className="text-xs text-muted-foreground mt-0.5">
            {lead.firstName} {lead.lastName}
            {lead.phone ? ` · ${lead.phone}` : ""}
          </p>
        )}
        <p className={cn("text-xs font-medium mt-1", isOver ? "text-red-500" : "text-muted-foreground")}>
          {formatDateTime(task.dueAt)}
        </p>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        {lead && (
          <Button size="icon" variant="ghost" className="w-8 h-8" asChild>
            <Link href={`/leads/${lead.id}`} data-testid={`link-open-lead-${lead.id}`}>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </Button>
        )}
        {lead?.phone && (
          <Button size="icon" variant="ghost" className="w-8 h-8" asChild>
            <a href={`tel:${lead.phone}`} data-testid={`link-call-${lead.id}`}>
              <Phone className="w-3.5 h-3.5 text-primary" />
            </a>
          </Button>
        )}
        <button
          onClick={() => onComplete(task.id)}
          disabled={isPending}
          title="Mark done"
          className="w-8 h-8 rounded-full border-2 border-primary/40 hover:border-primary hover:bg-primary/10 flex-shrink-0 transition-colors flex items-center justify-center"
          data-testid={`button-complete-task-${task.id}`}
        />
      </div>
    </div>
  );
}

function LeadCalendar({ tasks, leads }: { tasks: Task[]; leads: Lead[] }) {
  const today = new Date();
  const [cursor, setCursor] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstDow = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const tasksByDate: Record<string, Task[]> = {};
  for (const t of tasks) {
    if (!t.completedAt) {
      const d = new Date(t.dueAt);
      if (d.getFullYear() === year && d.getMonth() === month) {
        const key = d.getDate().toString();
        tasksByDate[key] = tasksByDate[key] || [];
        tasksByDate[key].push(t);
      }
    }
  }

  const isToday = (day: number) =>
    today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;

  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
  const currentWeekRow = isCurrentMonth
    ? Math.floor((firstDow + today.getDate() - 1) / 7)
    : -1;

  const cells: (number | null)[] = [
    ...Array.from({ length: firstDow }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  const weeks: (number | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) {
    weeks.push(cells.slice(i, i + 7).concat(Array(Math.max(0, 7 - (cells.length - i))).fill(null)));
  }

  const monthLabel = cursor.toLocaleString("default", { month: "long", year: "numeric" });

  const selectedDayTasks = selectedDay ? (tasksByDate[selectedDay.toString()] || []) : [];
  const selectedDate = selectedDay ? new Date(year, month, selectedDay) : null;

  function goToday() {
    setCursor(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDay(today.getDate());
  }

  function handleDayClick(day: number) {
    setSelectedDay(selectedDay === day ? null : day);
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="font-bold text-sm">{monthLabel}</span>
        <div className="flex gap-1 items-center">
          {!isCurrentMonth && (
            <Button
              size="sm"
              variant="outline"
              className="h-7 px-2 text-xs font-semibold"
              onClick={goToday}
              data-testid="button-cal-today"
            >
              Today
            </Button>
          )}
          <Button
            size="icon"
            variant="ghost"
            className="w-7 h-7"
            onClick={() => { setCursor(new Date(year, month - 1, 1)); setSelectedDay(null); }}
            data-testid="button-cal-prev"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="w-7 h-7"
            onClick={() => { setCursor(new Date(year, month + 1, 1)); setSelectedDay(null); }}
            data-testid="button-cal-next"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-px text-center mb-1">
        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => (
          <div key={d} className="text-[10px] font-bold text-muted-foreground py-1">{d}</div>
        ))}
      </div>

      <div className="space-y-0.5">
        {weeks.map((week, wi) => {
          const isCurrentWeekRow = wi === currentWeekRow;
          return (
            <div
              key={wi}
              className={cn(
                "grid grid-cols-7 gap-1 rounded-lg px-0.5",
                isCurrentWeekRow && "bg-primary/5 dark:bg-primary/10"
              )}
              data-testid={isCurrentWeekRow ? "cal-current-week" : undefined}
            >
              {week.map((day, di) => {
                if (!day) return <div key={`empty-${wi}-${di}`} className="min-h-[2.5rem]" />;
                const dayTasks = tasksByDate[day.toString()] || [];
                const overdue = dayTasks.some((t) => new Date(t.dueAt) < today && !isToday(day));
                const isSelected = selectedDay === day;
                return (
                  <button
                    key={day}
                    onClick={() => handleDayClick(day)}
                    className={cn(
                      "relative flex flex-col items-center justify-start pt-1 pb-1.5 rounded-lg min-h-[2.5rem] text-xs font-semibold transition-colors cursor-pointer w-full",
                      isSelected && !isToday(day)
                        ? "ring-2 ring-primary ring-offset-1 bg-primary/10 text-primary"
                        : isToday(day)
                        ? "bg-primary text-primary-foreground"
                        : dayTasks.length > 0
                        ? overdue
                          ? "bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-950/50"
                          : "bg-primary/10 text-primary hover:bg-primary/20"
                        : "text-foreground hover:bg-muted"
                    )}
                    data-testid={`cal-day-${day}`}
                  >
                    {day}
                    {dayTasks.length > 0 && (
                      <span className={cn(
                        "mt-0.5 text-[9px] font-bold px-1 rounded-full",
                        isToday(day)
                          ? "bg-primary-foreground/20 text-primary-foreground"
                          : overdue
                          ? "text-red-600 dark:text-red-400"
                          : "text-primary"
                      )}>
                        {dayTasks.length}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      {selectedDay && selectedDate && (
        <div className="mt-4 border rounded-xl overflow-hidden" data-testid="cal-day-panel">
          <div className="flex items-center justify-between px-4 py-2.5 bg-muted/50 border-b">
            <div className="flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-primary" />
              <span className="text-sm font-bold">
                {selectedDate.toLocaleDateString("default", { weekday: "long", month: "long", day: "numeric" })}
              </span>
            </div>
            <button
              onClick={() => setSelectedDay(null)}
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-cal-close-day"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y">
            {selectedDayTasks.length === 0 ? (
              <div className="py-6 text-center text-muted-foreground">
                <CheckCircle2 className="w-6 h-6 mx-auto mb-1.5 opacity-40" />
                <p className="text-sm font-medium">No tasks on this day.</p>
              </div>
            ) : (
              selectedDayTasks.map((t) => {
                const lead = leads.find((l) => l.id === t.leadId);
                const dueTime = new Date(t.dueAt).toLocaleTimeString("default", { hour: "numeric", minute: "2-digit" });
                return (
                  <div key={t.id} className="flex items-start gap-3 px-4 py-3" data-testid={`cal-task-${t.id}`}>
                    <div className="flex-1 min-w-0">
                      {t.note && <p className="text-sm font-semibold truncate">{t.note}</p>}
                      {lead && (
                        <Link href={`/leads/${lead.id}`}>
                          <span className="text-xs text-primary font-medium hover:underline cursor-pointer">
                            {lead.firstName} {lead.lastName}
                          </span>
                        </Link>
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground font-medium flex-shrink-0 mt-0.5">{dueTime}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  const { data: leads = [], isLoading: leadsLoading } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const completeMutation = useMutation({
    mutationFn: (id: string) =>
      apiRequest("PATCH", `/api/tasks/${id}`, { completedAt: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }),
  });

  const now = new Date();
  const pending = tasks.filter((t) => !t.completedAt);
  const overdue = pending.filter((t) => new Date(t.dueAt) < now && new Date(t.dueAt).toDateString() !== now.toDateString());
  const today = pending.filter((t) => new Date(t.dueAt).toDateString() === now.toDateString());
  const sold = leads.filter((l) => l.status === "Sold");
  const hot = leads.filter((l) => l.priority === "Hot" && !l.isArchived);
  const totalRevenue = sold.reduce((sum, l) => sum + (l.soldPremium || 0), 0);
  const staleLeads = leads.filter((l) => !l.isArchived && daysSince(l.updatedAt) > 3);

  const getLeadForTask = (task: Task) => leads.find((l) => l.id === task.leadId);

  const TaskSection = ({ title, items, accent }: { title: string; items: Task[]; accent?: "red" }) => (
    <Card className={cn(accent === "red" && "border-red-200 dark:border-red-900/40")}>
      <CardHeader className="pb-3">
        <CardTitle className={cn(
          "text-sm font-bold flex items-center justify-between",
          accent === "red" ? "text-red-600 dark:text-red-400" : ""
        )}>
          <span className="flex items-center gap-2">
            {accent === "red"
              ? <AlertCircle className="w-4 h-4" />
              : <CalendarClock className="w-4 h-4 text-primary" />}
            {title}
          </span>
          <span className={cn(
            "text-xs font-bold px-2 py-0.5 rounded-full",
            accent === "red"
              ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
              : "bg-primary/10 text-primary"
          )}>
            {items.length}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0 space-y-2">
        {items.length === 0 ? (
          <div className="py-6 text-center text-muted-foreground">
            <CheckCircle2 className="w-7 h-7 mx-auto mb-2 opacity-40" />
            <p className="text-sm font-medium">Nothing here.</p>
          </div>
        ) : (
          items.map((t) => (
            <TaskItem
              key={t.id}
              task={t}
              lead={getLeadForTask(t)}
              onComplete={(id) => completeMutation.mutate(id)}
              isPending={completeMutation.isPending}
            />
          ))
        )}
      </CardContent>
    </Card>
  );

  if (leadsLoading || tasksLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-black tracking-tight">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Your lead activity at a glance</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Active Leads" value={leads.filter((l) => !l.isArchived).length} icon={Users} />
        <StatCard label="Policies Sold" value={sold.length} icon={CheckCircle2} sub={totalRevenue > 0 ? `$${totalRevenue.toLocaleString()} premium` : undefined} />
        <StatCard label="Hot Leads" value={hot.length} icon={Flame} />
        <StatCard label="Tasks Due" value={pending.length} icon={CalendarClock} sub={overdue.length > 0 ? `${overdue.length} overdue` : "All on track"} />
      </div>

      {staleLeads.length > 0 && (
        <Card className="border-amber-200 dark:border-amber-900/40">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2 text-amber-700 dark:text-amber-400">
              <Clock className="w-4 h-4" />
              Stale Leads — No Activity in 3+ Days
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex flex-wrap gap-2">
              {staleLeads.slice(0, 8).map((lead) => (
                <Link key={lead.id} href={`/leads/${lead.id}`}>
                  <Badge variant="secondary" className="cursor-pointer font-semibold" data-testid={`badge-stale-${lead.id}`}>
                    {lead.firstName} {lead.lastName} · {daysSince(lead.updatedAt)}d
                  </Badge>
                </Link>
              ))}
              {staleLeads.length > 8 && (
                <Badge variant="outline">+{staleLeads.length - 8} more</Badge>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <TaskSection title="Overdue" items={overdue} accent="red" />
        <TaskSection title="Today" items={today} />
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <CalendarClock className="w-4 h-4 text-primary" />
            Calendar
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <LeadCalendar tasks={tasks} leads={leads} />
        </CardContent>
      </Card>
    </div>
  );
}
