import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, UserPlus, AlertCircle, Link2 } from "lucide-react";
import { PRIORITIES, STATUSES } from "@/lib/utils";
import { loadInsuranceTypes, loadLeadSources, loadDefaultState, US_STATES } from "@/lib/leadSettings";
import { Link } from "wouter";

export default function NewLeadPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const insuranceTypes = loadInsuranceTypes();
  const leadSources = loadLeadSources();
  const defaultState = loadDefaultState();

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    city: "",
    state: defaultState,
    zip: "",
    leadSource: leadSources[0] ?? "",
    insurance: insuranceTypes[0] ?? "Auto",
    status: "New",
    priority: "Warm",
    street: "",
    crmLink: "",
  });

  const set = (key: string, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const mutation = useMutation({
    mutationFn: (data: typeof form) => apiRequest("POST", "/api/leads", data),
    onSuccess: async (res) => {
      const lead = await res.json();
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: "Lead created", description: `${form.firstName} ${form.lastName} added successfully.` });
      navigate(`/leads/${lead.id}`);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create lead. Please try again.", variant: "destructive" });
    },
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.firstName || !form.lastName) return;
    mutation.mutate(form);
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <Button variant="ghost" size="sm" asChild className="mb-4 -ml-2">
          <Link href="/leads">
            <ArrowLeft className="w-4 h-4 mr-1.5" />
            Back to Leads
          </Link>
        </Button>
        <h1 className="text-2xl font-black tracking-tight">New Lead</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Add a new insurance lead to your pipeline</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Contact Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-0">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName" className="text-xs font-semibold">First Name *</Label>
                  <Input
                    id="firstName"
                    value={form.firstName}
                    onChange={(e) => set("firstName", e.target.value)}
                    placeholder="Jane"
                    required
                    className="mt-1"
                    data-testid="input-first-name"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName" className="text-xs font-semibold">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={form.lastName}
                    onChange={(e) => set("lastName", e.target.value)}
                    placeholder="Doe"
                    required
                    className="mt-1"
                    data-testid="input-last-name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone" className="text-xs font-semibold">Phone</Label>
                  <Input
                    id="phone"
                    value={form.phone}
                    onChange={(e) => set("phone", e.target.value)}
                    placeholder="555-000-1234"
                    className="mt-1"
                    data-testid="input-phone"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-xs font-semibold">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={(e) => set("email", e.target.value)}
                    placeholder="jane@example.com"
                    className="mt-1"
                    data-testid="input-email"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="street" className="text-xs font-semibold">Street Address</Label>
                <Input
                  id="street"
                  value={form.street}
                  onChange={(e) => set("street", e.target.value)}
                  placeholder="123 Main St"
                  className="mt-1"
                  data-testid="input-street"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="city" className="text-xs font-semibold">City</Label>
                  <Input
                    id="city"
                    value={form.city}
                    onChange={(e) => set("city", e.target.value)}
                    placeholder="Houston"
                    className="mt-1"
                    data-testid="input-city"
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold">State</Label>
                  <Select value={form.state} onValueChange={(v) => set("state", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-state">
                      <SelectValue placeholder="Select…" />
                    </SelectTrigger>
                    <SelectContent>
                      {US_STATES.map((s) => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="zip" className="text-xs font-semibold">Zip</Label>
                  <Input
                    id="zip"
                    value={form.zip}
                    onChange={(e) => set("zip", e.target.value)}
                    placeholder="77001"
                    className="mt-1"
                    data-testid="input-zip"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Lead Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-0">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs font-semibold">Lead Source</Label>
                  <Select value={form.leadSource} onValueChange={(v) => set("leadSource", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-lead-source">
                      <SelectValue placeholder="Select…" />
                    </SelectTrigger>
                    <SelectContent>
                      {leadSources.map((s) => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-semibold">Insurance Type</Label>
                  <Select value={form.insurance} onValueChange={(v) => set("insurance", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-insurance">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {insuranceTypes.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="crmLink" className="text-xs font-semibold flex items-center gap-1.5">
                  <Link2 className="w-3 h-3" />
                  CRM Link
                </Label>
                <Input
                  id="crmLink"
                  type="url"
                  value={form.crmLink}
                  onChange={(e) => set("crmLink", e.target.value)}
                  placeholder="https://your-crm.com/lead/123"
                  className="mt-1"
                  data-testid="input-crm-link"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs font-semibold">Status</Label>
                  <Select value={form.status} onValueChange={(v) => set("status", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-semibold">Priority</Label>
                  <Select value={form.priority} onValueChange={(v) => set("priority", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIORITIES.map((p) => (
                        <SelectItem key={p} value={p}>{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {mutation.isError && (
            <div className="flex items-center gap-2 text-sm text-destructive p-3 bg-destructive/10 rounded-lg border border-destructive/20">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              Failed to create lead. Please check your inputs and try again.
            </div>
          )}

          <div className="flex items-center gap-3">
            <Button type="submit" disabled={mutation.isPending} className="flex-1" data-testid="button-submit-lead">
              {mutation.isPending ? (
                "Creating…"
              ) : (
                <>
                  <UserPlus className="w-4 h-4 mr-1.5" />
                  Create Lead
                </>
              )}
            </Button>
            <Button type="button" variant="outline" asChild>
              <Link href="/leads">Cancel</Link>
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
