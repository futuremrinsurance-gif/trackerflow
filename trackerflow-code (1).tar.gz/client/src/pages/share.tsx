import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Share2, Copy, Check, Link as LinkIcon } from "lucide-react";
import { useState } from "react";

export default function SharePage() {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const appUrl = window.location.origin;

  function copyUrl() {
    navigator.clipboard.writeText(appUrl).then(() => {
      setCopied(true);
      toast({ title: "Copied!", description: "App URL copied to clipboard." });
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <div className="p-6 space-y-6 max-w-xl mx-auto">
      <div>
        <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
          <Share2 className="w-6 h-6 text-muted-foreground" />
          Share
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">Share access to TrackerFlow</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <LinkIcon className="w-3.5 h-3.5" />
            App URL
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-3">
          <p className="text-sm text-muted-foreground">
            Share this link to give others access to TrackerFlow.
          </p>
          <div className="flex gap-2">
            <Input
              value={appUrl}
              readOnly
              className="font-mono text-sm"
              data-testid="input-share-url"
            />
            <Button
              onClick={copyUrl}
              variant="outline"
              size="icon"
              data-testid="button-copy-url"
            >
              {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Quick Access</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <p className="text-sm text-muted-foreground mb-4">
            On mobile, open this app in Safari and tap <strong>Share → Add to Home Screen</strong> for a native app experience.
          </p>
          <div className="grid grid-cols-2 gap-3 text-sm">
            {[
              { label: "Dashboard", path: "/" },
              { label: "Leads", path: "/leads" },
              { label: "Pipeline", path: "/pipeline" },
              { label: "Analytics", path: "/analytics" },
            ].map(({ label, path }) => (
              <a
                key={path}
                href={`${appUrl}${path}`}
                className="flex items-center gap-2 p-3 rounded-lg border border-border bg-muted/30 font-semibold hover:bg-muted transition-colors"
                data-testid={`link-quick-${label.toLowerCase()}`}
              >
                <LinkIcon className="w-3.5 h-3.5 text-muted-foreground" />
                {label}
              </a>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
