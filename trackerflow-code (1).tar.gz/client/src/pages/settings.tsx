import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { loadWorkHours, saveWorkHours, DEFAULT_WORK_HOURS, type WorkHours } from "@/lib/workHours";
import {
  loadInsuranceTypes, saveInsuranceTypes,
  loadLeadSources, saveLeadSources,
  loadDefaultState, saveDefaultState,
  loadPremiumGoal, savePremiumGoal,
  loadAgencyCompany, saveAgencyCompany,
  DEFAULT_INSURANCE_TYPES, DEFAULT_LEAD_SOURCES,
  US_STATES,
} from "@/lib/leadSettings";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Settings, Moon, Sun, Monitor, Check, Phone, MessageSquare, Mail, Bell, Globe, Star, Trash2, Plus, ExternalLink, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { ACTION_KEY, ACTION_DEFAULTS, loadActionCfg, type ActionType, type ActionConfig } from "@/lib/actionConfig";

type Theme = "light" | "dark" | "system";

type NotifSettings = {
  enableInApp: boolean;
  enableBrowser: boolean;
  sound: boolean;
  quietHoursEnabled: boolean;
  quietStart: string;
  quietEnd: string;
};

type ExternalSource = {
  id: string;
  name: string;
  slug: string;
  url: string;
  isMain?: boolean;
};

const SOURCES_KEY = "trackerflow_external_sources_v1";

function slugify(name: string) {
  return name.toLowerCase().trim().replace(/['"]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

function loadSources(): ExternalSource[] {
  try {
    const raw = localStorage.getItem(SOURCES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

const NOTIF_KEY = "trackerflow_notification_settings_v1";
const NOTIF_DEFAULTS: NotifSettings = {
  enableInApp: true,
  enableBrowser: false,
  sound: false,
  quietHoursEnabled: false,
  quietStart: "22:00",
  quietEnd: "08:00",
};
const ACCENT_COLORS = [
  { name: "Blue", value: "blue", cls: "bg-blue-500" },
  { name: "Indigo", value: "indigo", cls: "bg-indigo-500" },
  { name: "Violet", value: "violet", cls: "bg-violet-500" },
  { name: "Green", value: "green", cls: "bg-green-500" },
  { name: "Orange", value: "orange", cls: "bg-orange-500" },
  { name: "Red", value: "red", cls: "bg-red-500" },
];

function getSystemTheme(): "light" | "dark" {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function applyTheme(theme: Theme) {
  const resolved = theme === "system" ? getSystemTheme() : theme;
  document.documentElement.classList.toggle("dark", resolved === "dark");
  localStorage.setItem("tf-theme", theme);
}

function ToggleRow({ label, description, checked, onChange, testId }: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  testId?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div className="space-y-0.5 flex-1">
        <p className="text-sm font-semibold">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative inline-flex h-6 w-11 flex-shrink-0 rounded-full border-2 border-transparent transition-colors focus-visible:outline-none",
          checked ? "bg-primary" : "bg-muted"
        )}
        data-testid={testId}
      >
        <span
          className={cn(
            "pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform",
            checked ? "translate-x-5" : "translate-x-0"
          )}
        />
      </button>
    </div>
  );
}

const ACTION_META: Record<ActionType, { label: string; icon: typeof Phone; placeholder: string; hint: string }> = {
  call:  { label: "Call",  icon: Phone,          placeholder: "tel:{phone}",       hint: 'Use {phone}. e.g. tel:{phone} or a VoIP app scheme.' },
  text:  { label: "Text",  icon: MessageSquare,   placeholder: "sms:{phone}",       hint: 'Use {phone}. e.g. sms:{phone} or a messaging app scheme.' },
  email: { label: "Email", icon: Mail,            placeholder: "mailto:{email}",    hint: 'Use {email}. e.g. mailto:{email} or a mail app scheme.' },
};

function ActionCard({
  type, cfg, onUpdate,
}: {
  type: ActionType;
  cfg: ActionConfig;
  onUpdate: (patch: Partial<ActionConfig>) => void;
}) {
  const { label, icon: Icon, placeholder, hint } = ACTION_META[type];
  const samplePhone = "15551234567";
  const sampleEmail = "test@example.com";
  const resolvedUrl = cfg.customUrlTemplate
    .replaceAll("{phone}", samplePhone)
    .replaceAll("{email}", sampleEmail);
  const testUrl = cfg.mode === "system"
    ? (type === "call" ? `tel:${samplePhone}` : type === "text" ? `sms:${samplePhone}` : `mailto:${sampleEmail}`)
    : resolvedUrl;

  return (
    <div className="rounded-xl border border-border/60 p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 font-bold text-sm">
          <Icon className="w-4 h-4 text-primary" />
          {label}
        </div>
        <label className="flex items-center gap-2 text-sm cursor-pointer select-none">
          <input
            type="checkbox"
            checked={cfg.enabled}
            onChange={(e) => onUpdate({ enabled: e.target.checked })}
            className="w-4 h-4 accent-primary"
            data-testid={`checkbox-action-${type}`}
          />
          <span className="text-muted-foreground font-medium">Enabled</span>
        </label>
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Mode</label>
          <select
            value={cfg.mode}
            onChange={(e) => onUpdate({ mode: e.target.value as "system" | "custom" })}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
            data-testid={`select-action-mode-${type}`}
          >
            <option value="system">System default</option>
            <option value="custom">Custom URL scheme</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">URL Template</label>
          <input
            type="text"
            value={cfg.customUrlTemplate}
            onChange={(e) => onUpdate({ customUrlTemplate: e.target.value })}
            placeholder={placeholder}
            disabled={cfg.mode !== "custom"}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium disabled:opacity-50"
            data-testid={`input-action-url-${type}`}
          />
        </div>
      </div>

      <div className="flex items-start justify-between gap-3">
        <p className="text-[11px] text-muted-foreground leading-relaxed">{hint}</p>
        <a
          href={cfg.enabled ? testUrl : undefined}
          onClick={!cfg.enabled ? (e) => e.preventDefault() : undefined}
          className={cn(
            "text-xs font-bold px-3 py-1.5 rounded-lg border whitespace-nowrap transition-colors",
            cfg.enabled
              ? "border-border bg-background hover:bg-muted text-foreground"
              : "border-border/40 text-muted-foreground cursor-not-allowed opacity-50"
          )}
          data-testid={`link-test-action-${type}`}
        >
          Test
        </a>
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const { toast } = useToast();

  const [theme, setTheme] = useState<Theme>(
    () => (localStorage.getItem("tf-theme") as Theme) ?? "light"
  );
  const [accent, setAccent] = useState(
    () => localStorage.getItem("tf-accent") ?? "blue"
  );
  const [actionCfg, setActionCfg] = useState<Record<ActionType, ActionConfig>>(ACTION_DEFAULTS);
  const [notif, setNotif] = useState<NotifSettings>(NOTIF_DEFAULTS);
  const [sources, setSources] = useState<ExternalSource[]>([]);
  const [newName, setNewName] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [workHours, setWorkHours] = useState<WorkHours>(DEFAULT_WORK_HOURS);

  const [insuranceTypes, setInsuranceTypes] = useState<string[]>([]);
  const [leadSources, setLeadSources] = useState<string[]>([]);
  const [defaultState, setDefaultStateVal] = useState<string>("");
  const [newInsurance, setNewInsurance] = useState("");
  const [newLeadSource, setNewLeadSource] = useState("");
  const [premiumGoal, setPremiumGoalState] = useState<number>(0);
  const [premiumGoalInput, setPremiumGoalInput] = useState("");
  const [agencyCompany, setAgencyCompany] = useState("");
  const [agencyInput, setAgencyInput] = useState("");
  const [notifEmailInput, setNotifEmailInput] = useState("");

  const { data: currentUser } = useQuery<{ id: string; username: string; email?: string | null }>({
    queryKey: ["/api/auth/me"],
  });

  useEffect(() => {
    if (currentUser?.email) setNotifEmailInput(currentUser.email);
  }, [currentUser?.email]);

  const updateEmailMutation = useMutation({
    mutationFn: (email: string) => apiRequest("PATCH", "/api/user", { email }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Notification email saved" });
    },
    onError: () => toast({ title: "Failed to save email", variant: "destructive" }),
  });

  useEffect(() => {
    setActionCfg(loadActionCfg());
    try {
      const raw = localStorage.getItem(NOTIF_KEY);
      if (raw) setNotif({ ...NOTIF_DEFAULTS, ...JSON.parse(raw) });
    } catch {}
    setSources(loadSources());
    setWorkHours(loadWorkHours());
    setInsuranceTypes(loadInsuranceTypes());
    setLeadSources(loadLeadSources());
    setDefaultStateVal(loadDefaultState());
    const g = loadPremiumGoal();
    setPremiumGoalState(g);
    setPremiumGoalInput(g > 0 ? String(g) : "");
    const agency = loadAgencyCompany();
    setAgencyCompany(agency);
    setAgencyInput(agency);
  }, []);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem(ACTION_KEY, JSON.stringify(actionCfg));
  }, [actionCfg]);

  useEffect(() => {
    localStorage.setItem(NOTIF_KEY, JSON.stringify(notif));
  }, [notif]);

  useEffect(() => {
    localStorage.setItem(SOURCES_KEY, JSON.stringify(sources));
  }, [sources]);

  useEffect(() => {
    saveWorkHours(workHours);
  }, [workHours]);

  function updateWorkDay(day: keyof WorkHours, patch: Partial<WorkHours[keyof WorkHours]>) {
    setWorkHours((prev) => ({ ...prev, [day]: { ...prev[day], ...patch } }));
  }

  function addSource() {
    const name = newName.trim();
    let url = newUrl.trim();
    if (!name || !url) return;
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    const slug = slugify(name);
    if (!slug) { toast({ title: "Invalid name", variant: "destructive" }); return; }
    if (sources.some((s) => s.slug === slug)) {
      toast({ title: "A source with that name already exists", variant: "destructive" }); return;
    }
    const src: ExternalSource = { id: crypto.randomUUID(), name, slug, url, isMain: sources.length === 0 };
    setSources((prev) => [...prev, src]);
    setNewName("");
    setNewUrl("");
    toast({ title: `"${name}" added to sidebar` });
  }

  function removeSource(id: string) {
    setSources((prev) => {
      const next = prev.filter((s) => s.id !== id);
      if (next.length && !next.some((s) => s.isMain)) next[0] = { ...next[0], isMain: true };
      return next;
    });
  }

  function setMain(id: string) {
    setSources((prev) => prev.map((s) => ({ ...s, isMain: s.id === id })));
  }

  function addInsuranceType() {
    const val = newInsurance.trim();
    if (!val) return;
    if (insuranceTypes.includes(val)) {
      toast({ title: "Already in list", variant: "destructive" }); return;
    }
    const updated = [...insuranceTypes, val];
    setInsuranceTypes(updated);
    saveInsuranceTypes(updated);
    setNewInsurance("");
    toast({ title: `"${val}" added` });
  }

  function removeInsuranceType(item: string) {
    const updated = insuranceTypes.filter((t) => t !== item);
    setInsuranceTypes(updated);
    saveInsuranceTypes(updated);
  }

  function resetInsuranceTypes() {
    setInsuranceTypes([...DEFAULT_INSURANCE_TYPES]);
    saveInsuranceTypes([...DEFAULT_INSURANCE_TYPES]);
    toast({ title: "Insurance types reset to defaults" });
  }

  function addLeadSource() {
    const val = newLeadSource.trim();
    if (!val) return;
    if (leadSources.includes(val)) {
      toast({ title: "Already in list", variant: "destructive" }); return;
    }
    const updated = [...leadSources, val];
    setLeadSources(updated);
    saveLeadSources(updated);
    setNewLeadSource("");
    toast({ title: `"${val}" added` });
  }

  function removeLeadSource(item: string) {
    const updated = leadSources.filter((s) => s !== item);
    setLeadSources(updated);
    saveLeadSources(updated);
  }

  function resetLeadSources() {
    setLeadSources([...DEFAULT_LEAD_SOURCES]);
    saveLeadSources([...DEFAULT_LEAD_SOURCES]);
    toast({ title: "Lead sources reset to defaults" });
  }

  function handleDefaultState(state: string) {
    const val = state === "__none__" ? "" : state;
    setDefaultStateVal(val);
    saveDefaultState(val);
    toast({ title: val ? `Default state set to ${val}` : "Default state cleared" });
  }

  function updateNotif(patch: Partial<NotifSettings>) {
    setNotif((prev) => ({ ...prev, ...patch }));
  }

  async function requestBrowserPermission() {
    if (!("Notification" in window)) {
      toast({ title: "Not supported", description: "This browser doesn't support notifications.", variant: "destructive" });
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm === "granted") {
      updateNotif({ enableBrowser: true });
      toast({ title: "Browser notifications enabled" });
    } else {
      updateNotif({ enableBrowser: false });
      toast({ title: "Permission denied", description: "Enable notifications in your browser settings.", variant: "destructive" });
    }
  }

  function handleAccent(value: string) {
    setAccent(value);
    localStorage.setItem("tf-accent", value);
    toast({ title: "Accent color updated" });
  }

  function handleTheme(value: Theme) {
    setTheme(value);
    applyTheme(value);
  }

  function updateAction(type: ActionType, patch: Partial<ActionConfig>) {
    setActionCfg((prev) => ({ ...prev, [type]: { ...prev[type], ...patch } }));
  }

  return (
    <div className="p-6 space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
          <Settings className="w-6 h-6 text-muted-foreground" />
          Settings
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">Customize your TrackerFlow experience</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Agency</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-3">
          <div className="space-y-1.5">
            <Label className="text-sm font-semibold">Company Name</Label>
            <p className="text-xs text-muted-foreground">Displayed in the sidebar to identify your agency.</p>
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="e.g. Smith Insurance Group"
              value={agencyInput}
              onChange={(e) => setAgencyInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  saveAgencyCompany(agencyInput);
                  setAgencyCompany(agencyInput.trim());
                  toast({ title: "Agency name saved" });
                }
              }}
              className="flex-1"
              data-testid="input-agency-company"
            />
            <Button
              size="sm"
              onClick={() => {
                saveAgencyCompany(agencyInput);
                setAgencyCompany(agencyInput.trim());
                toast({ title: "Agency name saved" });
              }}
              data-testid="button-save-agency"
            >
              Save
            </Button>
            {agencyCompany && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  saveAgencyCompany("");
                  setAgencyCompany("");
                  setAgencyInput("");
                  toast({ title: "Agency name cleared" });
                }}
                data-testid="button-clear-agency"
              >
                Clear
              </Button>
            )}
          </div>
          {agencyCompany && (
            <p className="text-xs text-muted-foreground">
              Currently showing: <span className="font-bold text-foreground">{agencyCompany}</span>
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Premium Goal</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          <p className="text-xs text-muted-foreground">
            Set your annual premium goal. Your progress will be shown on the dashboard and archive page based on closed deals.
          </p>
          <div className="flex gap-2 items-center">
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-semibold text-sm">$</span>
              <Input
                type="number"
                min="0"
                step="1000"
                placeholder="e.g. 50000"
                value={premiumGoalInput}
                onChange={(e) => setPremiumGoalInput(e.target.value)}
                className="pl-7"
                data-testid="input-premium-goal"
              />
            </div>
            <Button
              onClick={() => {
                const n = parseInt(premiumGoalInput.replace(/[^0-9]/g, ""), 10);
                const val = isNaN(n) ? 0 : n;
                setPremiumGoalState(val);
                savePremiumGoal(val);
                setPremiumGoalInput(val > 0 ? String(val) : "");
                toast({ title: val > 0 ? `Goal set to $${val.toLocaleString()}` : "Goal cleared" });
              }}
              data-testid="button-save-premium-goal"
            >
              Save
            </Button>
            {premiumGoal > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setPremiumGoalState(0);
                  savePremiumGoal(0);
                  setPremiumGoalInput("");
                  toast({ title: "Goal cleared" });
                }}
                data-testid="button-clear-premium-goal"
              >
                Clear
              </Button>
            )}
          </div>
          {premiumGoal > 0 && (
            <p className="text-xs text-muted-foreground">
              Current goal: <span className="font-semibold text-foreground">${premiumGoal.toLocaleString()}</span>
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Appearance</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-5">
          <div>
            <Label className="text-sm font-semibold mb-3 block">Theme</Label>
            <div className="flex gap-2">
              {(["light", "dark", "system"] as Theme[]).map((t) => {
                const Icon = t === "light" ? Sun : t === "dark" ? Moon : Monitor;
                const labels = { light: "Light", dark: "Dark", system: "System" };
                return (
                  <button
                    key={t}
                    onClick={() => handleTheme(t)}
                    className={cn(
                      "flex-1 flex flex-col items-center gap-2 py-3 px-2 rounded-xl border-2 transition-all text-sm font-semibold",
                      theme === t
                        ? "border-primary bg-primary/5 text-primary"
                        : "border-border bg-background text-muted-foreground"
                    )}
                    data-testid={`button-theme-${t}`}
                  >
                    <Icon className="w-5 h-5" />
                    {labels[t]}
                  </button>
                );
              })}
            </div>
          </div>

          <Separator />

          <div>
            <Label className="text-sm font-semibold mb-3 block">Accent Color</Label>
            <div className="flex gap-3 flex-wrap">
              {ACCENT_COLORS.map((c) => (
                <button
                  key={c.value}
                  onClick={() => handleAccent(c.value)}
                  className={cn(
                    "w-9 h-9 rounded-full transition-all relative flex items-center justify-center",
                    c.cls,
                    accent === c.value ? "ring-2 ring-offset-2 ring-foreground/40 scale-110" : "opacity-70 hover:opacity-100"
                  )}
                  title={c.name}
                  data-testid={`button-accent-${c.value}`}
                >
                  {accent === c.value && <Check className="w-4 h-4 text-white" />}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">
            Work Hours
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
            Set your working hours for each day. These are saved locally and can be used to highlight your schedule on calendars.
          </p>
          {(
            [
              ["mon", "Monday"],
              ["tue", "Tuesday"],
              ["wed", "Wednesday"],
              ["thu", "Thursday"],
              ["fri", "Friday"],
              ["sat", "Saturday"],
              ["sun", "Sunday"],
            ] as const
          ).map(([key, label]) => {
            const day = workHours[key];
            return (
              <div
                key={key}
                className={cn(
                  "flex items-center gap-3 rounded-xl border px-3 py-2.5 transition-colors",
                  day.enabled ? "border-border bg-background" : "border-border/40 bg-muted/20"
                )}
                data-testid={`work-hours-row-${key}`}
              >
                <button
                  role="switch"
                  aria-checked={day.enabled}
                  onClick={() => updateWorkDay(key, { enabled: !day.enabled })}
                  className={cn(
                    "relative inline-flex h-5 w-9 flex-shrink-0 rounded-full border-2 border-transparent transition-colors",
                    day.enabled ? "bg-primary" : "bg-muted"
                  )}
                  data-testid={`toggle-work-${key}`}
                >
                  <span className={cn(
                    "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform",
                    day.enabled ? "translate-x-4" : "translate-x-0"
                  )} />
                </button>
                <span className={cn(
                  "w-24 text-sm font-semibold",
                  !day.enabled && "text-muted-foreground"
                )}>
                  {label}
                </span>
                <div className="flex items-center gap-2 ml-auto">
                  <input
                    type="time"
                    value={day.start}
                    disabled={!day.enabled}
                    onChange={(e) => updateWorkDay(key, { start: e.target.value })}
                    className="rounded-lg border border-border bg-background px-2 py-1 text-sm font-medium disabled:opacity-40 w-28"
                    data-testid={`input-work-start-${key}`}
                  />
                  <span className="text-xs text-muted-foreground font-medium">to</span>
                  <input
                    type="time"
                    value={day.end}
                    disabled={!day.enabled}
                    onChange={(e) => updateWorkDay(key, { end: e.target.value })}
                    className="rounded-lg border border-border bg-background px-2 py-1 text-sm font-medium disabled:opacity-40 w-28"
                    data-testid={`input-work-end-${key}`}
                  />
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">
            Mobile App Actions
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Control what opens when you tap Call / Text / Email on a lead. Use <strong>System default</strong> for the built-in phone, messages, or mail app, or <strong>Custom URL scheme</strong> to open any app (e.g. a VoIP dialer).
          </p>
          {(["call", "text", "email"] as ActionType[]).map((type) => (
            <ActionCard
              key={type}
              type={type}
              cfg={actionCfg[type]}
              onUpdate={(patch) => updateAction(type, patch)}
            />
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <Bell className="w-3.5 h-3.5" />
            Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          <ToggleRow
            label="In-app alerts"
            description="Show toast notifications for reminders inside the app"
            checked={notif.enableInApp}
            onChange={(v) => updateNotif({ enableInApp: v })}
            testId="toggle-notif-inapp"
          />

          <Separator />

          <div className="space-y-3">
            <ToggleRow
              label="Browser notifications"
              description="Show system-level push notifications (requires permission)"
              checked={notif.enableBrowser}
              onChange={(v) => {
                if (v) requestBrowserPermission();
                else updateNotif({ enableBrowser: false });
              }}
              testId="toggle-notif-browser"
            />
            {!notif.enableBrowser && (
              <button
                onClick={requestBrowserPermission}
                className="text-xs font-semibold text-primary underline underline-offset-2"
                data-testid="button-request-browser-permission"
              >
                Request permission
              </button>
            )}
          </div>

          <Separator />

          <ToggleRow
            label="Sound"
            description="Play a sound when a reminder fires"
            checked={notif.sound}
            onChange={(v) => updateNotif({ sound: v })}
            testId="toggle-notif-sound"
          />

          <Separator />

          <ToggleRow
            label="Quiet hours"
            description="Suppress reminders during a set time window"
            checked={notif.quietHoursEnabled}
            onChange={(v) => updateNotif({ quietHoursEnabled: v })}
            testId="toggle-notif-quiet"
          />

          {notif.quietHoursEnabled && (
            <div className="grid grid-cols-2 gap-3 pl-1">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Start</label>
                <input
                  type="time"
                  value={notif.quietStart}
                  onChange={(e) => updateNotif({ quietStart: e.target.value })}
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                  data-testid="input-quiet-start"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">End</label>
                <input
                  type="time"
                  value={notif.quietEnd}
                  onChange={(e) => updateNotif({ quietEnd: e.target.value })}
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                  data-testid="input-quiet-end"
                />
              </div>
            </div>
          )}

          <Separator />

          <div className="space-y-2">
            <Label className="text-sm font-semibold flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              Email Reminders
            </Label>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Enter your email address to receive reminders for scheduled activities. The reminder is sent 24 hours before the activity is due.
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="you@example.com"
                value={notifEmailInput}
                onChange={(e) => setNotifEmailInput(e.target.value)}
                className="flex-1"
                data-testid="input-notif-email"
              />
              <Button
                size="sm"
                disabled={updateEmailMutation.isPending}
                onClick={() => updateEmailMutation.mutate(notifEmailInput)}
                data-testid="button-save-notif-email"
              >
                {updateEmailMutation.isPending ? "Saving…" : "Save"}
              </Button>
              {currentUser?.email && (
                <Button
                  size="sm"
                  variant="ghost"
                  disabled={updateEmailMutation.isPending}
                  onClick={() => { setNotifEmailInput(""); updateEmailMutation.mutate(""); }}
                  data-testid="button-clear-notif-email"
                >
                  Clear
                </Button>
              )}
            </div>
            {currentUser?.email && (
              <p className="text-xs text-muted-foreground">
                Reminders currently going to: <span className="font-semibold text-foreground">{currentUser.email}</span>
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Lead Form Defaults</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-6">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Customize the dropdown options and pre-filled values shown when creating a new lead.
          </p>

          <div>
            <Label className="text-sm font-semibold mb-2 block">Default State</Label>
            <p className="text-xs text-muted-foreground mb-2">Pre-fills the State field on every new lead.</p>
            <select
              value={defaultState || "__none__"}
              onChange={(e) => handleDefaultState(e.target.value)}
              className="w-48 rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
              data-testid="select-default-state"
            >
              <option value="__none__">No default</option>
              {US_STATES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <Separator />

          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <Label className="text-sm font-semibold">Insurance Types</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Options available in the insurance type dropdown.</p>
              </div>
              <button
                onClick={resetInsuranceTypes}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-reset-insurance"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            </div>
            <div className="flex flex-wrap gap-2 mb-3">
              {insuranceTypes.map((t) => (
                <div
                  key={t}
                  className="flex items-center gap-1.5 bg-muted rounded-full px-3 py-1 text-xs font-semibold"
                  data-testid={`insurance-tag-${t}`}
                >
                  {t}
                  <button
                    onClick={() => removeInsuranceType(t)}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    data-testid={`button-remove-insurance-${t}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={newInsurance}
                onChange={(e) => setNewInsurance(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addInsuranceType())}
                placeholder="Add type…"
                className="h-8 text-sm"
                data-testid="input-new-insurance"
              />
              <Button size="sm" variant="outline" onClick={addInsuranceType} data-testid="button-add-insurance">
                <Plus className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>

          <Separator />

          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <Label className="text-sm font-semibold">Lead Sources</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Options available in the lead source dropdown.</p>
              </div>
              <button
                onClick={resetLeadSources}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-reset-lead-sources"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            </div>
            <div className="flex flex-wrap gap-2 mb-3">
              {leadSources.map((s) => (
                <div
                  key={s}
                  className="flex items-center gap-1.5 bg-muted rounded-full px-3 py-1 text-xs font-semibold"
                  data-testid={`lead-source-tag-${s}`}
                >
                  {s}
                  <button
                    onClick={() => removeLeadSource(s)}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    data-testid={`button-remove-lead-source-${s}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={newLeadSource}
                onChange={(e) => setNewLeadSource(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addLeadSource())}
                placeholder="Add source…"
                className="h-8 text-sm"
                data-testid="input-new-lead-source"
              />
              <Button size="sm" variant="outline" onClick={addLeadSource} data-testid="button-add-lead-source">
                <Plus className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <Globe className="w-3.5 h-3.5" />
            External Lead Sources
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Add external pages (portals, carriers, lead vendors) to the sidebar. Each source gets its own page that embeds the URL. The <Star className="w-3 h-3 inline mb-0.5" /> main source appears first.
          </p>

          {sources.length > 0 && (
            <div className="space-y-2">
              {[...sources.filter((s) => s.isMain), ...sources.filter((s) => !s.isMain).sort((a, b) => a.name.localeCompare(b.name))].map((src) => (
                <div
                  key={src.id}
                  className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 px-3 py-2.5"
                  data-testid={`source-row-${src.slug}`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      {src.isMain && <Star className="w-3 h-3 text-yellow-500 flex-shrink-0" />}
                      <span className="text-sm font-semibold truncate">{src.name}</span>
                    </div>
                    <span className="text-[11px] text-muted-foreground font-mono truncate block">{src.url}</span>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {!src.isMain && (
                      <button
                        onClick={() => setMain(src.id)}
                        title="Set as main"
                        className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-yellow-500 transition-colors"
                        data-testid={`button-set-main-${src.slug}`}
                      >
                        <Star className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <a
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="Open in new tab"
                      className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground transition-colors"
                      data-testid={`link-open-source-${src.slug}`}
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                    <button
                      onClick={() => removeSource(src.id)}
                      title="Remove"
                      className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-muted-foreground hover:text-red-500 transition-colors"
                      data-testid={`button-remove-source-${src.slug}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_auto]">
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Source name (e.g. Smart Financial)"
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
              data-testid="input-source-name"
              onKeyDown={(e) => e.key === "Enter" && addSource()}
            />
            <input
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              placeholder="URL (e.g. https://pro.smartfinancial.com)"
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
              data-testid="input-source-url"
              onKeyDown={(e) => e.key === "Enter" && addSource()}
            />
            <Button
              onClick={addSource}
              disabled={!newName.trim() || !newUrl.trim()}
              size="sm"
              data-testid="button-add-source"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>

          {sources.length === 0 && (
            <p className="text-xs text-muted-foreground italic">
              No sources yet. Add one above and it will appear in the sidebar under "Lead Sources".
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">About</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">App</span>
            <span className="font-semibold">TrackerFlow</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Version</span>
            <span className="font-semibold">1.0.0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Description</span>
            <span className="font-semibold">Insurance Lead CRM</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
