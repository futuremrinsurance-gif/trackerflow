import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle } from "lucide-react";

export default function LoginPage() {
  const { login, register } = useAuth();
  const { toast } = useToast();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const isPending = login.isPending || register.isPending;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!username.trim() || !password) return;

    try {
      if (mode === "login") {
        await login.mutateAsync({ username: username.trim(), password });
      } else {
        await register.mutateAsync({ username: username.trim(), password });
        toast({ title: "Account created", description: "Welcome to TrackerFlow!" });
      }
    } catch (err: any) {
      const msg = err?.message || "Something went wrong. Try again.";
      toast({
        title: mode === "login" ? "Sign in failed" : "Registration failed",
        description: msg,
        variant: "destructive",
      });
    }
  }

  const error = mode === "login" ? login.error : register.error;

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <img
            src="/logo.png"
            alt="TrackerFlow"
            className="w-14 h-14 rounded-2xl object-contain mb-4 shadow-md"
          />
          <h1 className="text-2xl font-black tracking-tight">TrackerFlow</h1>
          <p className="text-sm text-muted-foreground mt-1">Insurance Lead CRM</p>
        </div>

        <div className="bg-background rounded-2xl border border-border/60 shadow-sm p-6">
          <div className="flex gap-1 mb-6 bg-muted rounded-xl p-1">
            <button
              onClick={() => setMode("login")}
              className={`flex-1 py-1.5 text-sm font-semibold rounded-lg transition-all ${
                mode === "login"
                  ? "bg-background shadow-sm text-foreground"
                  : "text-muted-foreground"
              }`}
              data-testid="tab-sign-in"
            >
              Sign In
            </button>
            <button
              onClick={() => setMode("register")}
              className={`flex-1 py-1.5 text-sm font-semibold rounded-lg transition-all ${
                mode === "register"
                  ? "bg-background shadow-sm text-foreground"
                  : "text-muted-foreground"
              }`}
              data-testid="tab-create-account"
            >
              Create Account
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="username" className="text-xs font-semibold">
                Email
              </Label>
              <Input
                id="username"
                type="email"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                required
                className="mt-1"
                data-testid="input-username"
              />
            </div>
            <div>
              <Label htmlFor="password" className="text-xs font-semibold">
                Password
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                required
                className="mt-1"
                data-testid="input-password"
              />
              {mode === "register" && (
                <p className="text-xs text-muted-foreground mt-1">At least 6 characters</p>
              )}
            </div>

            {error && (
              <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {(error as any)?.message || "An error occurred"}
              </div>
            )}

            <Button
              type="submit"
              className="w-full"
              disabled={isPending}
              data-testid="button-auth-submit"
            >
              {isPending
                ? mode === "login"
                  ? "Signing in…"
                  : "Creating account…"
                : mode === "login"
                ? "Sign In"
                : "Create Account"}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center mt-4 leading-relaxed">
            {mode === "login" ? "Don't have an account? " : "Already have an account? "}
            <button
              onClick={() => setMode(mode === "login" ? "register" : "login")}
              className="text-primary font-semibold underline underline-offset-2"
              data-testid="button-switch-auth-mode"
            >
              {mode === "login" ? "Create one" : "Sign in"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
