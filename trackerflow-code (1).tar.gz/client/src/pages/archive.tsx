import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Archive, ArchiveRestore, Search, RefreshCw, ArrowRight, Download, Trash2, ChevronDown, ChevronRight, Square, CheckSquare, XCircle } from "lucide-react";
import { cn, statusColor, insuranceColor, formatDate, formatRelative } from "@/lib/utils";
import { useMemo, useState, useCallback, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import type { Lead } from "@shared/schema";

const LOST_STATUSES = ["Lost", "Declined"];

function groupBySource(leads: Lead[]) {
  const map: Record<string, Lead[]> = {};
  for (const l of leads) {
    const key = (l.leadSource || "").trim() || "Unsorted";
    map[key] = map[key] || [];
    map[key].push(l);
  }
  return Object.keys(map)
    .sort((a, b) => a.localeCompare(b))
    .map((name) => ({
      name,
      leads: map[name].sort((a, b) =>
        `${a.lastName} ${a.firstName}`.localeCompare(`${b.lastName} ${b.firstName}`)
      ),
    }));
}

async function downloadExport(ids: string[], filename: string) {
  const res = await fetch("/api/export/leads", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ids, includeArchived: true }),
  });
  if (!res.ok) throw new Error("Export failed");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function LeadRow({
  lead, onAction, actionLabel, isPending, selected, onToggleSelect,
}: {
  lead: Lead;
  onAction: (id: string) => void;
  actionLabel: string;
  isPending: boolean;
  selected: boolean;
  onToggleSelect: (id: string) => void;
}) {
  return (
    <div
      className={cn(
        "flex items-start gap-3 p-4 rounded-xl border bg-background transition-colors",
        selected ? "border-primary/50 bg-primary/5" : "border-border/50"
      )}
      data-testid={`card-archived-lead-${lead.id}`}
    >
      <button
        onClick={() => onToggleSelect(lead.id)}
        className="flex-shrink-0 text-muted-foreground hover:text-primary transition-colors mt-0.5"
        data-testid={`checkbox-archived-lead-${lead.id}`}
      >
        {selected ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4" />}
      </button>

      <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center flex-shrink-0 font-black text-sm text-muted-foreground mt-0.5">
        {lead.firstName[0]}{lead.lastName[0]}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-sm">{lead.firstName} {lead.lastName}</span>
          {lead.insurance && (
            <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", insuranceColor(lead.insurance))}>
              {lead.insurance}
            </span>
          )}
          {lead.status && (
            <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", statusColor(lead.status))}>
              {lead.status}
            </span>
          )}
          {lead.isArchived && (
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
              Archived
            </span>
          )}
          <span className="text-[11px] text-muted-foreground font-medium ml-auto">
            Called {lead.timesCalled ?? 0}x
          </span>
        </div>
        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
          {lead.phone && <span>{lead.phone}</span>}
          {lead.city && <span>{lead.city}{lead.state ? `, ${lead.state}` : ""}</span>}
          {lead.archivedAt
            ? <span>Archived {formatDate(lead.archivedAt)}</span>
            : <span>Updated {formatRelative(lead.updatedAt)}</span>
          }
        </div>
      </div>

      <div className="flex items-center gap-1.5 flex-shrink-0">
        <Button
          size="sm"
          variant="outline"
          onClick={() => onAction(lead.id)}
          disabled={isPending}
          data-testid={`button-action-${lead.id}`}
        >
          <ArchiveRestore className="w-3.5 h-3.5 mr-1.5" />
          {actionLabel}
        </Button>
        <Button size="icon" variant="ghost" asChild>
          <Link href={`/leads/${lead.id}`} data-testid={`link-open-${lead.id}`}>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </Button>
      </div>
    </div>
  );
}

function SourceGroup({
  group, onAction, actionLabel, isPending, selected, onToggleSelect, onToggleGroupSelect, collapsed, onToggleCollapse, collapseKey,
}: {
  group: { name: string; leads: Lead[] };
  onAction: (id: string) => void;
  actionLabel: string;
  isPending: boolean;
  selected: Set<string>;
  onToggleSelect: (id: string) => void;
  onToggleGroupSelect: (ids: string[]) => void;
  collapsed: Set<string>;
  onToggleCollapse: (key: string) => void;
  collapseKey: string;
}) {
  const groupIds = group.leads.map((l) => l.id);
  const allGroupSelected = groupIds.length > 0 && groupIds.every((id) => selected.has(id));
  const someGroupSelected = groupIds.some((id) => selected.has(id));
  const isCollapsed = collapsed.has(collapseKey);

  return (
    <div
      className="rounded-xl border border-border/60 bg-card overflow-hidden"
      data-testid={`group-archive-${group.name}`}
    >
      <div
        className="flex items-center justify-between px-4 py-3 border-b border-border/40 bg-muted/30 cursor-pointer select-none"
        onClick={() => onToggleCollapse(collapseKey)}
      >
        <div className="flex items-center gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); onToggleGroupSelect(groupIds); }}
            className="text-muted-foreground hover:text-primary transition-colors"
            data-testid={`button-select-group-${group.name}`}
          >
            {allGroupSelected ? (
              <CheckSquare className="w-4 h-4 text-primary" />
            ) : someGroupSelected ? (
              <CheckSquare className="w-4 h-4 text-primary/50" />
            ) : (
              <Square className="w-4 h-4" />
            )}
          </button>
          <span className="font-bold text-sm">{group.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground bg-background border border-border/50 px-2 py-0.5 rounded-full">
            {group.leads.length}
          </span>
          {isCollapsed
            ? <ChevronRight className="w-4 h-4 text-muted-foreground" />
            : <ChevronDown className="w-4 h-4 text-muted-foreground" />
          }
        </div>
      </div>
      {!isCollapsed && (
        <div className="p-3 space-y-2">
          {group.leads.map((lead) => (
            <LeadRow
              key={lead.id}
              lead={lead}
              onAction={onAction}
              actionLabel={actionLabel}
              isPending={isPending}
              selected={selected.has(lead.id)}
              onToggleSelect={onToggleSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function TopLevelSection({
  sectionKey, icon: Icon, title, count, groups, onAction, actionLabel, isPending, selected, onToggleSelect,
  onToggleGroupSelect, collapsed, onToggleCollapse,
}: {
  sectionKey: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  count: number;
  groups: { name: string; leads: Lead[] }[];
  onAction: (id: string) => void;
  actionLabel: string;
  isPending: boolean;
  selected: Set<string>;
  onToggleSelect: (id: string) => void;
  onToggleGroupSelect: (ids: string[]) => void;
  collapsed: Set<string>;
  onToggleCollapse: (key: string) => void;
}) {
  if (groups.length === 0) return null;
  const isCollapsed = collapsed.has(sectionKey);
  return (
    <div className="rounded-xl border border-border/60 bg-card overflow-hidden" data-testid={`section-${sectionKey}`}>
      <div
        className="flex items-center justify-between px-4 py-3 border-b border-border/40 bg-muted/40 cursor-pointer select-none"
        onClick={() => onToggleCollapse(sectionKey)}
      >
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-muted-foreground" />
          <span className="font-black text-sm tracking-tight">{title}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground bg-background border border-border/50 px-2 py-0.5 rounded-full">
            {count}
          </span>
          {isCollapsed
            ? <ChevronRight className="w-4 h-4 text-muted-foreground" />
            : <ChevronDown className="w-4 h-4 text-muted-foreground" />
          }
        </div>
      </div>
      {!isCollapsed && (
        <div className="p-3 space-y-2">
          {groups.map((g) => (
            <SourceGroup
              key={g.name}
              group={g}
              onAction={onAction}
              actionLabel={actionLabel}
              isPending={isPending}
              selected={selected}
              onToggleSelect={onToggleSelect}
              onToggleGroupSelect={onToggleGroupSelect}
              collapsed={collapsed}
              onToggleCollapse={onToggleCollapse}
              collapseKey={`${sectionKey}::${g.name}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function ArchivePage() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [exporting, setExporting] = useState(false);
  const { toast } = useToast();

  const { data: activeLeads = [], isLoading: activeLoading, refetch: refetchActive } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const { data: archivedLeads = [], isLoading: archivedLoading, refetch: refetchArchived } = useQuery<Lead[]>({
    queryKey: ["/api/leads?archived=true"],
    queryFn: async () => {
      const res = await fetch("/api/leads?archived=true");
      return res.json();
    },
  });

  const isLoading = activeLoading || archivedLoading;

  function refetch() {
    refetchActive();
    refetchArchived();
  }

  const reopenMutation = useMutation({
    mutationFn: (id: string) =>
      apiRequest("PATCH", `/api/leads/${id}`, { status: "New", isArchived: false, archivedAt: null }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads?archived=true"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: "Lead reopened", description: "Status set back to New." });
    },
  });

  const restoreMutation = useMutation({
    mutationFn: (id: string) =>
      apiRequest("PATCH", `/api/leads/${id}`, { isArchived: false, archivedAt: null }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads?archived=true"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: "Lead restored" });
    },
  });

  const { lostGroups, otherGroups, lostCount, archivedCount, allFilteredIds } = useMemo(() => {
    const activeLost = activeLeads.filter(
      (l) => LOST_STATUSES.includes(l.status ?? "") && !l.isArchived
    );
    const archivedLost = archivedLeads.filter(
      (l) => LOST_STATUSES.includes(l.status ?? "")
    );
    const archivedOther = archivedLeads.filter(
      (l) => !LOST_STATUSES.includes(l.status ?? "")
    );

    const allLost = [...activeLost, ...archivedLost];
    const allFiltered = search
      ? [...allLost, ...archivedOther].filter((l) => {
          const q = search.toLowerCase();
          return (
            l.firstName.toLowerCase().includes(q) ||
            l.lastName.toLowerCase().includes(q) ||
            (l.phone ?? "").includes(q) ||
            (l.leadSource ?? "").toLowerCase().includes(q) ||
            (l.city ?? "").toLowerCase().includes(q) ||
            (l.status ?? "").toLowerCase().includes(q)
          );
        })
      : [...allLost, ...archivedOther];

    const filteredLost = search
      ? allLost.filter((l) => {
          const q = search.toLowerCase();
          return (
            l.firstName.toLowerCase().includes(q) ||
            l.lastName.toLowerCase().includes(q) ||
            (l.phone ?? "").includes(q) ||
            (l.leadSource ?? "").toLowerCase().includes(q) ||
            (l.city ?? "").toLowerCase().includes(q) ||
            (l.status ?? "").toLowerCase().includes(q)
          );
        })
      : allLost;

    const filteredOther = search
      ? archivedOther.filter((l) => {
          const q = search.toLowerCase();
          return (
            l.firstName.toLowerCase().includes(q) ||
            l.lastName.toLowerCase().includes(q) ||
            (l.phone ?? "").includes(q) ||
            (l.leadSource ?? "").toLowerCase().includes(q) ||
            (l.city ?? "").toLowerCase().includes(q) ||
            (l.status ?? "").toLowerCase().includes(q)
          );
        })
      : archivedOther;

    return {
      lostGroups: groupBySource(filteredLost),
      otherGroups: groupBySource(filteredOther),
      lostCount: allLost.length,
      archivedCount: archivedLeads.length,
      allFilteredIds: allFiltered.map((l) => l.id),
    };
  }, [activeLeads, archivedLeads, search]);

  const isEmpty = lostGroups.length === 0 && otherGroups.length === 0;
  const allSelected = allFilteredIds.length > 0 && allFilteredIds.every((id) => selected.has(id));
  const someSelected = selected.size > 0;

  function toggleSelect(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function toggleGroupSelect(ids: string[]) {
    const allIn = ids.every((id) => selected.has(id));
    setSelected((prev) => {
      const next = new Set(prev);
      if (allIn) ids.forEach((id) => next.delete(id));
      else ids.forEach((id) => next.add(id));
      return next;
    });
  }

  function toggleCollapse(key: string) {
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  }

  function toggleSelectAll() {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(allFilteredIds));
  }

  const handleExport = useCallback(async () => {
    setExporting(true);
    try {
      const ids = someSelected ? Array.from(selected) : allFilteredIds;
      await downloadExport(ids, "archive-leads.xlsx");
      toast({ title: `Exported ${ids.length} lead${ids.length !== 1 ? "s" : ""}` });
    } catch {
      toast({ title: "Export failed", variant: "destructive" });
    } finally {
      setExporting(false);
    }
  }, [selected, someSelected, allFilteredIds, toast]);

  const [deleting, setDeleting] = useState(false);
  const handleDeleteSelected = useCallback(async () => {
    const ids = Array.from(selected);
    if (!ids.length) return;
    const confirmed = window.confirm(
      `Permanently delete ${ids.length} lead${ids.length !== 1 ? "s" : ""}? This cannot be undone.`
    );
    if (!confirmed) return;
    setDeleting(true);
    try {
      await Promise.all(ids.map((id) => apiRequest("DELETE", `/api/leads/${id}`)));
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads?archived=true"] });
      toast({ title: `${ids.length} lead${ids.length !== 1 ? "s" : ""} deleted` });
    } catch {
      toast({ title: "Delete failed", variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  }, [selected, toast]);

  const isPending = reopenMutation.isPending || restoreMutation.isPending;

  return (
    <div className="p-6 space-y-5 max-w-4xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
            <Archive className="w-6 h-6 text-muted-foreground" />
            Archive
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {lostCount} lost · {archivedCount} archived
          </p>
        </div>
        <div className="flex items-center gap-2">
          {!isLoading && !isEmpty && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleExport}
              disabled={exporting}
              data-testid="button-export-archive"
            >
              <Download className="w-4 h-4 mr-1.5" />
              {someSelected ? `Export (${selected.size})` : "Export All"}
            </Button>
          )}
          {someSelected && (
            <Button
              variant="destructive"
              size="sm"
              onClick={handleDeleteSelected}
              disabled={deleting}
              data-testid="button-delete-selected-archive"
            >
              <Trash2 className="w-4 h-4 mr-1.5" />
              Delete ({selected.size})
            </Button>
          )}
          <Button size="icon" variant="outline" onClick={refetch} data-testid="button-refresh">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search leads…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-archive"
          />
        </div>
        {!isLoading && !isEmpty && (
          <Button
            size="sm"
            variant="ghost"
            onClick={toggleSelectAll}
            className="flex-shrink-0 text-xs"
            data-testid="button-select-all-archive"
          >
            {allSelected ? (
              <><CheckSquare className="w-4 h-4 mr-1.5 text-primary" />Deselect All</>
            ) : (
              <><Square className="w-4 h-4 mr-1.5" />Select All</>
            )}
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      ) : isEmpty ? (
        <Card>
          <CardContent className="py-16 flex flex-col items-center text-center text-muted-foreground">
            <Archive className="w-10 h-10 mb-3 opacity-30" />
            <p className="font-semibold">
              {search ? "No results found" : "Nothing here yet"}
            </p>
            <p className="text-sm mt-1">
              {search ? "Try a different search" : "Lost and archived leads will appear here"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          <TopLevelSection
            sectionKey="lost"
            icon={XCircle}
            title="Lost"
            count={lostGroups.reduce((n, g) => n + g.leads.length, 0)}
            groups={lostGroups}
            onAction={(id) => reopenMutation.mutate(id)}
            actionLabel="Reopen"
            isPending={isPending}
            selected={selected}
            onToggleSelect={toggleSelect}
            onToggleGroupSelect={toggleGroupSelect}
            collapsed={collapsed}
            onToggleCollapse={toggleCollapse}
          />
          <TopLevelSection
            sectionKey="archived"
            icon={Archive}
            title="Archived"
            count={otherGroups.reduce((n, g) => n + g.leads.length, 0)}
            groups={otherGroups}
            onAction={(id) => restoreMutation.mutate(id)}
            actionLabel="Restore"
            isPending={isPending}
            selected={selected}
            onToggleSelect={toggleSelect}
            onToggleGroupSelect={toggleGroupSelect}
            collapsed={collapsed}
            onToggleCollapse={toggleCollapse}
          />
        </div>
      )}
    </div>
  );
}
