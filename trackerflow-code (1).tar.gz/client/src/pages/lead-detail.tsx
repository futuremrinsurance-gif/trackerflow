import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useParams, Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Phone,
  Mail,
  MapPin,
  Archive,
  ArchiveRestore,
  Minus,
  Plus,
  MessageSquare,
  Clock,
  Trash2,
  ExternalLink,
  AlertTriangle,
  Pencil,
  Globe,
  Cake,
  CalendarPlus,
  Bell,
  RefreshCw,
} from "lucide-react";
import { SiZillow } from "react-icons/si";
import {
  cn,
  STATUSES,
  PRIORITIES,
  statusColor,
  priorityColor,
  insuranceColor,
  formatDate,
  formatRelative,
  daysSince,
} from "@/lib/utils";
import { loadInsuranceTypes, loadLeadSources } from "@/lib/leadSettings";
import { loadActionCfg, buildActionUrl, ACTION_DEFAULTS } from "@/lib/actionConfig";
import { useState, useEffect, useCallback } from "react";
import type { Lead, Task, Activity } from "@shared/schema";

function TimesCalledBar({ value, onChange, disabled }: { value: number; onChange: (n: number) => void; disabled?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <Button
        size="icon"
        variant="outline"
        onClick={() => onChange(Math.max(0, value - 1))}
        disabled={disabled || value <= 0}
        data-testid="button-times-called-decrement"
      >
        <Minus className="w-4 h-4" />
      </Button>
      <div className="flex items-center gap-1.5 flex-1">
        {Array.from({ length: 9 }).map((_, i) => (
          <button
            key={i}
            onClick={() => onChange(i + 1)}
            disabled={disabled}
            className={cn(
              "flex-1 h-4 rounded-full transition-colors",
              i < value
                ? value >= 7
                  ? "bg-red-500"
                  : value >= 4
                  ? "bg-amber-500"
                  : "bg-primary"
                : "bg-muted hover:bg-muted-foreground/20"
            )}
            data-testid={`button-times-called-dot-${i}`}
          />
        ))}
      </div>
      <Button
        size="icon"
        variant="default"
        onClick={() => onChange(Math.min(9, value + 1))}
        disabled={disabled || value >= 9}
        data-testid="button-times-called-increment"
      >
        <Plus className="w-4 h-4" />
      </Button>
      <span className="text-sm font-bold w-8 text-center tabular-nums">{value}/9</span>
    </div>
  );
}

const MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

const YEAR_OPTIONS = Array.from({ length: 8 }, (_, i) => new Date().getFullYear() - 6 + i);

export default function LeadDetailPage() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [note, setNote] = useState("");
  const [wonMonth, setWonMonth] = useState<number>(new Date().getMonth() + 1);
  const [wonYear, setWonYear] = useState<number>(new Date().getFullYear());
  const [wonPremium, setWonPremium] = useState<string>("");
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({
    firstName: "", lastName: "", phone: "", email: "",
    street: "", city: "", state: "", zip: "", crmLink: "", dateOfBirth: "",
  });
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    title: "",
    type: "call",
    dueAt: "",
    emailReminder: false,
  });
  const [actionCfg] = useState(() => loadActionCfg());
  const insuranceTypes = loadInsuranceTypes();
  const leadSources = loadLeadSources();

  const copyToClipboard = useCallback(async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: `${label} copied` });
    } catch {
      toast({ title: "Copy failed", description: "Could not access clipboard.", variant: "destructive" });
    }
  }, [toast]);

  function handlePhoneClick(e: React.MouseEvent, phone: string) {
    const cfg = actionCfg.call;
    if (cfg.enabled) {
      e.preventDefault();
      const url = buildActionUrl("call", cfg, phone, "");
      window.open(url, "_blank");
    } else {
      e.preventDefault();
      copyToClipboard(phone, "Phone number");
    }
  }

  function handleEmailClick(e: React.MouseEvent, email: string) {
    const cfg = actionCfg.email;
    if (cfg.enabled) {
      e.preventDefault();
      const url = buildActionUrl("email", cfg, "", email);
      window.open(url, "_blank");
    } else {
      e.preventDefault();
      copyToClipboard(email, "Email");
    }
  }

  function handleAddressClick(address: string) {
    copyToClipboard(address, "Address");
  }
  const { US_STATES } = { US_STATES: ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"] };

  const { data: lead, isLoading } = useQuery<Lead>({
    queryKey: ["/api/leads", params.id],
    queryFn: async () => {
      const res = await fetch(`/api/leads/${params.id}`);
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
  });

  const { data: activities = [] } = useQuery<Activity[]>({
    queryKey: ["/api/activities", params.id],
    queryFn: async () => {
      const res = await fetch(`/api/activities/${params.id}`);
      return res.json();
    },
    enabled: !!lead,
  });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks", { leadId: params.id }],
    queryFn: async () => {
      const res = await fetch(`/api/tasks?leadId=${params.id}`);
      return res.json();
    },
    enabled: !!lead,
  });

  const updateMutation = useMutation({
    mutationFn: (data: Partial<Lead>) => apiRequest("PATCH", `/api/leads/${params.id}`, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads", params.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      if (variables.status === "Lost" || variables.status === "Declined") {
        toast({ title: "Moved to Lost", description: `Status set to ${variables.status}.` });
        navigate("/lost");
      }
    },
  });

  const archiveMutation = useMutation({
    mutationFn: (archive: boolean) =>
      apiRequest("PATCH", `/api/leads/${params.id}`, {
        isArchived: archive,
        archivedAt: archive ? new Date().toISOString() : null,
      }),
    onSuccess: (_, archive) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads", params.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: archive ? "Lead archived" : "Lead restored", description: archive ? "Lead moved to archive." : "Lead is active again." });
      if (archive) navigate("/leads");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/leads/${params.id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: "Lead deleted" });
      navigate("/leads");
    },
  });

  const notesMutation = useMutation({
    mutationFn: (content: string) =>
      apiRequest("POST", "/api/activities", { leadId: params.id, type: "note", content }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities", params.id] });
      setNote("");
      toast({ title: "Note saved" });
    },
  });

  const completeTaskMutation = useMutation({
    mutationFn: (taskId: string) =>
      apiRequest("PATCH", `/api/tasks/${taskId}`, { completedAt: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tasks", { leadId: params.id }] }),
  });

  const { data: currentUser } = useQuery<{ id: string; username: string; email?: string | null }>({
    queryKey: ["/api/auth/me"],
  });

  const createTaskMutation = useMutation({
    mutationFn: (data: { title: string; type: string; dueAt: string; emailReminder: boolean }) =>
      apiRequest("POST", "/api/tasks", {
        leadId: params.id,
        title: data.title,
        type: data.type,
        dueAt: new Date(data.dueAt).toISOString(),
        emailReminder: data.emailReminder,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", { leadId: params.id }] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setScheduleOpen(false);
      setScheduleForm({ title: "", type: "call", dueAt: "", emailReminder: false });
      toast({ title: "Activity scheduled" });
    },
  });

  const saveWonMutation = useMutation({
    mutationFn: () => {
      const premiumNum = Math.max(0, Number(wonPremium.replace(/[^0-9.]/g, "")) || 0);
      return apiRequest("PATCH", `/api/leads/${params.id}`, {
        status: "Sold",
        wonMonth,
        wonYear,
        soldPremium: premiumNum,
        isArchived: true,
        archivedAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads", params.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({ title: "Won saved & archived", description: `${MONTH_NAMES[wonMonth - 1]} ${wonYear} · $${wonPremium || 0}` });
      navigate("/leads");
    },
  });

  function openEdit() {
    if (!lead) return;
    setEditForm({
      firstName: lead.firstName ?? "",
      lastName: lead.lastName ?? "",
      phone: lead.phone ?? "",
      email: lead.email ?? "",
      street: lead.street ?? "",
      city: lead.city ?? "",
      state: lead.state ?? "",
      zip: lead.zip ?? "",
      crmLink: lead.crmLink ?? "",
      dateOfBirth: lead.dateOfBirth ?? "",
    });
    setEditOpen(true);
  }

  function saveEdit() {
    const patch: Record<string, string | null> = {
      firstName: editForm.firstName.trim() || "(Unknown)",
      lastName: editForm.lastName.trim(),
      phone: editForm.phone.trim() || null,
      email: editForm.email.trim() || null,
      street: editForm.street.trim() || null,
      city: editForm.city.trim() || null,
      state: (editForm.state === "__none__" ? "" : editForm.state).trim() || null,
      zip: editForm.zip.trim() || null,
      crmLink: editForm.crmLink.trim() || null,
      dateOfBirth: editForm.dateOfBirth.trim() || null,
    };
    updateMutation.mutate(patch as any, {
      onSuccess: () => {
        setEditOpen(false);
        toast({ title: "Lead updated" });
      },
    });
  }

  useEffect(() => {
    if (!lead) return;
    if (lead.wonMonth) setWonMonth(lead.wonMonth);
    if (lead.wonYear) setWonYear(lead.wonYear);
    if (lead.soldPremium != null) setWonPremium(String(lead.soldPremium));
  }, [lead?.id]);

  if (isLoading) {
    return (
      <div className="p-6 max-w-4xl mx-auto space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 rounded-xl" />
        <Skeleton className="h-32 rounded-xl" />
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p className="font-semibold">Lead not found</p>
            <Button asChild size="sm" className="mt-4">
              <Link href="/leads">Back to Leads</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const stale = daysSince(lead.updatedAt) > 2;
  const pendingTasks = tasks.filter((t) => !t.completedAt);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <Button variant="ghost" size="sm" asChild className="-ml-2">
          <Link href={lead.isArchived ? "/archive" : "/leads"}>
            <ArrowLeft className="w-4 h-4 mr-1.5" />
            Back
          </Link>
        </Button>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={openEdit}
            data-testid="button-edit-lead"
          >
            <Pencil className="w-4 h-4 mr-1.5" />
            Edit
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => archiveMutation.mutate(!lead.isArchived)}
            disabled={archiveMutation.isPending}
            data-testid="button-archive-toggle"
          >
            {lead.isArchived ? (
              <><ArchiveRestore className="w-4 h-4 mr-1.5" />Restore</>
            ) : (
              <><Archive className="w-4 h-4 mr-1.5" />Archive</>
            )}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              if (confirm(`Delete ${lead.firstName} ${lead.lastName}? This cannot be undone.`)) {
                deleteMutation.mutate();
              }
            }}
            disabled={deleteMutation.isPending}
            className="text-destructive border-destructive/30"
            data-testid="button-delete-lead"
          >
            <Trash2 className="w-4 h-4 mr-1.5" />
            Delete
          </Button>
        </div>
      </div>

      {lead.isArchived && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-amber-50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-900/40 text-amber-700 dark:text-amber-300">
          <Archive className="w-4 h-4 flex-shrink-0" />
          <span className="text-sm font-semibold">This lead is archived</span>
        </div>
      )}

      {stale && !lead.isArchived && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-red-50 border border-red-200 dark:bg-red-950/20 dark:border-red-900/40 text-red-700 dark:text-red-300">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span className="text-sm font-semibold">No activity in {daysSince(lead.updatedAt)} days</span>
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-5">
        <div className="md:col-span-2 space-y-5">
          <Card>
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0 font-black text-xl text-primary">
                  {lead.firstName[0]}{lead.lastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <h1 className="text-xl font-black tracking-tight">{lead.firstName} {lead.lastName}</h1>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full", statusColor(lead.status))}>
                      {lead.status}
                    </span>
                    <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full", insuranceColor(lead.insurance))}>
                      {lead.insurance}
                    </span>
                    <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full", priorityColor(lead.priority))}>
                      {lead.priority} Priority
                    </span>
                    {lead.leadSource && (
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-muted text-muted-foreground">
                        {lead.leadSource}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {lead.phone && (() => {
                  const callEnabled = actionCfg.call.enabled;
                  return (
                    <a
                      href={callEnabled ? buildActionUrl("call", actionCfg.call, lead.phone!, "") : undefined}
                      onClick={(e) => handlePhoneClick(e, lead.phone!)}
                      className="flex items-center gap-2.5 text-sm group cursor-pointer"
                      data-testid="link-phone"
                      title={callEnabled ? "Open phone app" : "Copy phone number"}
                    >
                      <div className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center flex-shrink-0">
                        <Phone className="w-4 h-4 text-green-700 dark:text-green-400" />
                      </div>
                      <span className="font-semibold group-hover:text-primary transition-colors">{lead.phone}</span>
                      {callEnabled
                        ? <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-60 transition-opacity" />
                        : <span className="text-[10px] text-muted-foreground opacity-0 group-hover:opacity-80 transition-opacity">copy</span>
                      }
                    </a>
                  );
                })()}
                {lead.email && (() => {
                  const emailEnabled = actionCfg.email.enabled;
                  return (
                    <a
                      href={emailEnabled ? buildActionUrl("email", actionCfg.email, "", lead.email!) : undefined}
                      onClick={(e) => handleEmailClick(e, lead.email!)}
                      className="flex items-center gap-2.5 text-sm group cursor-pointer"
                      data-testid="link-email"
                      title={emailEnabled ? "Open email app" : "Copy email address"}
                    >
                      <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                        <Mail className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                      </div>
                      <span className="font-semibold group-hover:text-primary transition-colors truncate">{lead.email}</span>
                      {emailEnabled
                        ? <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-60 transition-opacity flex-shrink-0" />
                        : <span className="text-[10px] text-muted-foreground opacity-0 group-hover:opacity-80 transition-opacity flex-shrink-0">copy</span>
                      }
                    </a>
                  );
                })()}
                {lead.dateOfBirth && (
                  <button
                    onClick={() => copyToClipboard(lead.dateOfBirth!, "Date of birth")}
                    className="flex items-center gap-2.5 text-sm group cursor-pointer text-left"
                    data-testid="button-copy-dob"
                    title="Copy date of birth"
                  >
                    <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center flex-shrink-0">
                      <Cake className="w-4 h-4 text-orange-700 dark:text-orange-400" />
                    </div>
                    <span className="font-semibold group-hover:text-primary transition-colors">{lead.dateOfBirth}</span>
                    <span className="text-[10px] text-muted-foreground opacity-0 group-hover:opacity-80 transition-opacity">copy</span>
                  </button>
                )}
                {(lead.street || lead.city || lead.state) && (() => {
                  const addressText = [lead.street, lead.city, lead.state, lead.zip].filter(Boolean).join(", ");
                  const zillowUrl = `https://www.zillow.com/homes/${encodeURIComponent(addressText)}/`;
                  const earthUrl = `https://earth.google.com/web/search/${encodeURIComponent(addressText)}`;
                  return (
                    <div className="sm:col-span-2 flex flex-col gap-1.5">
                      <button
                        onClick={() => handleAddressClick(addressText)}
                        className="flex items-center gap-2.5 text-sm group cursor-pointer text-left"
                        data-testid="button-copy-address"
                        title="Copy address"
                      >
                        <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center flex-shrink-0">
                          <MapPin className="w-4 h-4 text-purple-700 dark:text-purple-400" />
                        </div>
                        <span className="font-semibold group-hover:text-primary transition-colors">
                          {addressText}
                        </span>
                        <span className="text-[10px] text-muted-foreground opacity-0 group-hover:opacity-80 transition-opacity">copy</span>
                      </button>
                      <div className="flex items-center gap-2 pl-10">
                        <a
                          href={zillowUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-lg border border-border/60 bg-background hover:bg-blue-50 dark:hover:bg-blue-950/30 hover:border-blue-300 text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
                          data-testid="link-zillow"
                          title="Search on Zillow"
                        >
                          <SiZillow className="w-3 h-3" />
                          Zillow
                        </a>
                        <a
                          href={earthUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-lg border border-border/60 bg-background hover:bg-green-50 dark:hover:bg-green-950/30 hover:border-green-300 text-muted-foreground hover:text-green-700 dark:hover:text-green-400 transition-colors"
                          data-testid="link-google-earth"
                          title="View on Google Earth"
                        >
                          <Globe className="w-3 h-3" />
                          Google Earth
                        </a>
                      </div>
                    </div>
                  );
                })()}
                {lead.crmLink && (
                  <a
                    href={lead.crmLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2.5 text-sm group"
                    data-testid="link-crm"
                  >
                    <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center flex-shrink-0">
                      <ExternalLink className="w-4 h-4 text-orange-700 dark:text-orange-400" />
                    </div>
                    <span className="font-semibold group-hover:text-primary transition-colors">View in CRM</span>
                    <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-60 transition-opacity" />
                  </a>
                )}
              </div>

              <div className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Created {formatDate(lead.createdAt)} · Updated {formatRelative(lead.updatedAt)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Times Called</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <TimesCalledBar
                value={lead.timesCalled ?? 0}
                onChange={(n) => updateMutation.mutate({ timesCalled: n })}
                disabled={updateMutation.isPending || lead.isArchived}
              />
              {lead.timesCalled >= 7 && (
                <p className="text-xs text-red-500 font-semibold mt-2">
                  Warning: Lead will be auto-archived after 9 calls
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Schedule Activity</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={() => setScheduleOpen(true)}
                data-testid="button-schedule-activity"
              >
                <CalendarPlus className="w-4 h-4 text-primary" />
                Add to Calendar
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Add Note</CardTitle>
            </CardHeader>
            <CardContent className="pt-0 space-y-3">
              <Textarea
                placeholder="What happened on this call? Any follow-ups needed?"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                data-testid="textarea-note"
              />
              <Button
                size="sm"
                onClick={() => note.trim() && notesMutation.mutate(note)}
                disabled={notesMutation.isPending || !note.trim()}
                data-testid="button-save-note"
              >
                <MessageSquare className="w-4 h-4 mr-1.5" />
                {notesMutation.isPending ? "Saving…" : "Save Note"}
              </Button>
            </CardContent>
          </Card>

          {activities.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Activity</CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                {activities.map((a) => (
                  <div key={a.id} className="flex gap-3" data-testid={`activity-${a.id}`}>
                    <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
                      <MessageSquare className="w-3.5 h-3.5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium leading-relaxed">{a.content}</p>
                      <p className="text-xs text-muted-foreground mt-1">{formatRelative(a.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Status</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Select
                value={lead.status}
                onValueChange={(v) => updateMutation.mutate({ status: v })}
                disabled={updateMutation.isPending || lead.isArchived}
              >
                <SelectTrigger data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full", statusColor(s))}>
                        {s}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Priority</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex gap-2">
                {PRIORITIES.map((p) => (
                  <button
                    key={p}
                    onClick={() => updateMutation.mutate({ priority: p })}
                    disabled={updateMutation.isPending || lead.isArchived}
                    className={cn(
                      "flex-1 py-1.5 px-2 text-xs font-bold rounded-lg border transition-all",
                      lead.priority === p
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background text-muted-foreground"
                    )}
                    data-testid={`button-priority-${p.toLowerCase()}`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Insurance Type</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Select
                value={lead.insurance}
                onValueChange={(v) => updateMutation.mutate({ insurance: v })}
                disabled={updateMutation.isPending || lead.isArchived}
              >
                <SelectTrigger data-testid="select-insurance">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {insuranceTypes.map((t) => (
                    <SelectItem key={t} value={t}>
                      <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full", insuranceColor(t))}>
                        {t}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Lead Source</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Select
                value={lead.leadSource ?? ""}
                onValueChange={(v) => updateMutation.mutate({ leadSource: v })}
                disabled={updateMutation.isPending || lead.isArchived}
              >
                <SelectTrigger data-testid="select-lead-source">
                  <SelectValue placeholder="Select…" />
                </SelectTrigger>
                <SelectContent>
                  {leadSources.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {pendingTasks.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-bold text-muted-foreground uppercase tracking-wider">
                  Tasks ({pendingTasks.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-2">
                {pendingTasks.map((task) => (
                  <div key={task.id} className="flex items-center gap-2 text-sm" data-testid={`task-${task.id}`}>
                    <button
                      onClick={() => completeTaskMutation.mutate(task.id)}
                      className="w-4 h-4 rounded-full border-2 border-primary/50 hover:bg-primary/10 flex-shrink-0 transition-colors"
                      data-testid={`button-complete-task-${task.id}`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{task.title}</p>
                      <p className="text-xs text-muted-foreground">{formatRelative(task.dueAt)}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {lead.status === "Sold" && (
            <Card className="border-green-200 dark:border-green-900/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-bold text-green-700 dark:text-green-400 uppercase tracking-wider">
                  Won Details
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-4">
                {lead.wonMonth && lead.wonYear && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="font-semibold text-green-700 dark:text-green-400 text-base">
                      {MONTH_NAMES[lead.wonMonth - 1]} {lead.wonYear}
                    </span>
                    {lead.soldPremium != null && (
                      <span className="font-black text-green-700 dark:text-green-300 text-xl ml-2">
                        ${lead.soldPremium.toLocaleString()}
                      </span>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Month</label>
                    <select
                      value={wonMonth}
                      onChange={(e) => setWonMonth(Number(e.target.value))}
                      className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                      data-testid="select-won-month"
                    >
                      {MONTH_NAMES.map((m, i) => (
                        <option key={m} value={i + 1}>{m}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Year</label>
                    <select
                      value={wonYear}
                      onChange={(e) => setWonYear(Number(e.target.value))}
                      className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                      data-testid="select-won-year"
                    >
                      {YEAR_OPTIONS.map((y) => (
                        <option key={y} value={y}>{y}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Premium Earned</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="e.g. 2500"
                    value={wonPremium}
                    onChange={(e) => setWonPremium(e.target.value)}
                    className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                    data-testid="input-won-premium"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                    <RefreshCw className="w-3 h-3" />
                    Policy Renewal Date
                  </label>
                  <input
                    type="date"
                    value={lead.renewalDate ?? ""}
                    onChange={(e) => updateMutation.mutate({ renewalDate: e.target.value || null } as any)}
                    className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                    data-testid="input-renewal-date"
                  />
                  {lead.renewalDate && (
                    <p className="text-[11px] text-muted-foreground">
                      A new lead will auto-appear 30 days before this date.
                      {lead.renewalLeadCreated && (
                        <span className="ml-1 font-semibold text-green-600 dark:text-green-400">✓ Renewal lead created</span>
                      )}
                    </p>
                  )}
                </div>

                <Button
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => saveWonMutation.mutate()}
                  disabled={saveWonMutation.isPending}
                  data-testid="button-save-won"
                >
                  Save Won + Archive
                </Button>
                <p className="text-[11px] text-muted-foreground text-center">
                  Archives the lead and locks it from auto-restore
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* ── Edit Lead Dialog ── */}
      <Dialog open={editOpen} onOpenChange={(o) => !o && setEditOpen(false)}>
        <DialogContent className="max-w-lg p-0 gap-0 flex flex-col max-h-[90vh]">
          <div className="px-6 pt-6 pb-4 border-b flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-4 h-4 text-primary" />
              Edit Lead
            </DialogTitle>
            <DialogDescription className="mt-1">
              Update contact information and details for this lead.
            </DialogDescription>
          </div>

          <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4 min-h-0">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="edit-first-name" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">First Name</Label>
                <Input
                  id="edit-first-name"
                  value={editForm.firstName}
                  onChange={(e) => setEditForm((f) => ({ ...f, firstName: e.target.value }))}
                  placeholder="First name"
                  data-testid="input-edit-first-name"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="edit-last-name" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Last Name</Label>
                <Input
                  id="edit-last-name"
                  value={editForm.lastName}
                  onChange={(e) => setEditForm((f) => ({ ...f, lastName: e.target.value }))}
                  placeholder="Last name"
                  data-testid="input-edit-last-name"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-phone" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Phone</Label>
              <Input
                id="edit-phone"
                type="tel"
                value={editForm.phone}
                onChange={(e) => setEditForm((f) => ({ ...f, phone: e.target.value }))}
                placeholder="e.g. 555-123-4567"
                data-testid="input-edit-phone"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-email" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Email</Label>
              <Input
                id="edit-email"
                type="email"
                value={editForm.email}
                onChange={(e) => setEditForm((f) => ({ ...f, email: e.target.value }))}
                placeholder="email@example.com"
                data-testid="input-edit-email"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-street" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Street Address</Label>
              <Input
                id="edit-street"
                value={editForm.street}
                onChange={(e) => setEditForm((f) => ({ ...f, street: e.target.value }))}
                placeholder="123 Main St"
                data-testid="input-edit-street"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-1 space-y-1.5">
                <Label htmlFor="edit-city" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">City</Label>
                <Input
                  id="edit-city"
                  value={editForm.city}
                  onChange={(e) => setEditForm((f) => ({ ...f, city: e.target.value }))}
                  placeholder="City"
                  data-testid="input-edit-city"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">State</Label>
                <Select
                  value={editForm.state || "__none__"}
                  onValueChange={(v) => setEditForm((f) => ({ ...f, state: v === "__none__" ? "" : v }))}
                >
                  <SelectTrigger data-testid="select-edit-state">
                    <SelectValue placeholder="State" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— None —</SelectItem>
                    {US_STATES.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="edit-zip" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Zip</Label>
                <Input
                  id="edit-zip"
                  value={editForm.zip}
                  onChange={(e) => setEditForm((f) => ({ ...f, zip: e.target.value }))}
                  placeholder="Zip"
                  data-testid="input-edit-zip"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-dob" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date of Birth</Label>
              <Input
                id="edit-dob"
                type="text"
                value={editForm.dateOfBirth}
                onChange={(e) => setEditForm((f) => ({ ...f, dateOfBirth: e.target.value }))}
                placeholder="MM/DD/YYYY"
                data-testid="input-edit-dob"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-crm-link" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">CRM Link</Label>
              <Input
                id="edit-crm-link"
                type="url"
                value={editForm.crmLink}
                onChange={(e) => setEditForm((f) => ({ ...f, crmLink: e.target.value }))}
                placeholder="https://your-crm.com/lead/123"
                data-testid="input-edit-crm-link"
              />
            </div>
          </div>

          <div className="px-6 py-4 border-t flex-shrink-0 flex justify-between gap-2 bg-background">
            <Button variant="outline" onClick={() => setEditOpen(false)} data-testid="button-edit-cancel">
              Cancel
            </Button>
            <Button
              onClick={saveEdit}
              disabled={updateMutation.isPending}
              data-testid="button-edit-save"
            >
              {updateMutation.isPending ? "Saving…" : "Save Changes"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Schedule Activity Dialog ── */}
      <Dialog open={scheduleOpen} onOpenChange={(o) => { if (!o) { setScheduleOpen(false); setScheduleForm({ title: "", type: "call", dueAt: "", emailReminder: false }); } }}>
        <DialogContent className="max-w-md p-0 gap-0">
          <div className="px-6 pt-6 pb-4 border-b">
            <DialogTitle className="flex items-center gap-2">
              <CalendarPlus className="w-4 h-4 text-primary" />
              Schedule Activity
            </DialogTitle>
            <DialogDescription className="mt-1">
              Add an activity for {lead?.firstName} {lead?.lastName} to your calendar.
            </DialogDescription>
          </div>

          <div className="px-6 py-5 space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Activity Title</Label>
              <Input
                placeholder="e.g. Follow-up call, Policy review…"
                value={scheduleForm.title}
                onChange={(e) => setScheduleForm((f) => ({ ...f, title: e.target.value }))}
                data-testid="input-schedule-title"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Type</Label>
              <select
                value={scheduleForm.type}
                onChange={(e) => setScheduleForm((f) => ({ ...f, type: e.target.value }))}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                data-testid="select-schedule-type"
              >
                <option value="call">Call</option>
                <option value="appointment">Appointment</option>
                <option value="follow-up">Follow-Up</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date &amp; Time</Label>
              <input
                type="datetime-local"
                value={scheduleForm.dueAt}
                onChange={(e) => setScheduleForm((f) => ({ ...f, dueAt: e.target.value }))}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium"
                data-testid="input-schedule-date"
              />
            </div>

            <div
              className={cn(
                "flex items-start gap-3 rounded-xl border px-4 py-3 cursor-pointer transition-colors",
                scheduleForm.emailReminder ? "border-primary/40 bg-primary/5" : "border-border bg-muted/20"
              )}
              onClick={() => setScheduleForm((f) => ({ ...f, emailReminder: !f.emailReminder }))}
              data-testid="toggle-email-reminder"
            >
              <div className={cn(
                "relative inline-flex h-5 w-9 flex-shrink-0 rounded-full border-2 border-transparent transition-colors mt-0.5",
                scheduleForm.emailReminder ? "bg-primary" : "bg-muted"
              )}>
                <span className={cn(
                  "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform",
                  scheduleForm.emailReminder ? "translate-x-4" : "translate-x-0"
                )} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5" />
                  Email Reminder
                </p>
                {currentUser?.email ? (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Sends a reminder 24 hrs before to <span className="font-medium">{currentUser.email}</span>
                  </p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Set a notification email in Settings to enable reminders.
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 px-6 pb-5">
            <Button variant="outline" size="sm" onClick={() => setScheduleOpen(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              disabled={!scheduleForm.title.trim() || !scheduleForm.dueAt || createTaskMutation.isPending}
              onClick={() => createTaskMutation.mutate(scheduleForm)}
              data-testid="button-save-schedule"
            >
              <CalendarPlus className="w-4 h-4 mr-1.5" />
              {createTaskMutation.isPending ? "Scheduling…" : "Schedule"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
