import { ExternalLink, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const SF_URL = "https://agent.smartfinancial.com";

export default function SmartFinancialPage() {
  return (
    <div className="p-6 space-y-5 max-w-4xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-primary" />
            SmartFinancial
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Access your SmartFinancial agent portal
          </p>
        </div>
        <Button asChild variant="outline" data-testid="button-open-sf">
          <a href={SF_URL} target="_blank" rel="noopener noreferrer">
            <ExternalLink className="w-4 h-4 mr-2" />
            Open in new tab
          </a>
        </Button>
      </div>

      <Card className="overflow-hidden border-border/60">
        <CardContent className="p-0">
          <iframe
            src={SF_URL}
            title="SmartFinancial Agent Portal"
            className="w-full border-0"
            style={{ height: "calc(100vh - 180px)", minHeight: 500 }}
            data-testid="iframe-smartfinancial"
            allow="clipboard-write"
          />
        </CardContent>
      </Card>
    </div>
  );
}
