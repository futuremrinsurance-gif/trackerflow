import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Users, CheckCircle2, DollarSign, Target, BarChart3 } from "lucide-react";
import { cn, statusColor, insuranceColor } from "@/lib/utils";
import { useMemo, useState, useEffect } from "react";
import type { Lead } from "@shared/schema";
import { loadPremiumGoal } from "@/lib/leadSettings";

function StatCard({ label, value, sub, icon: Icon, accent }: any) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">{label}</p>
            <p className="text-3xl font-black leading-none">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1.5 font-medium">{sub}</p>}
          </div>
          <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", accent ?? "bg-primary/10")}>
            <Icon className={cn("w-5 h-5", accent ? "text-white" : "text-primary")} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function HorizontalBar({ label, value, max, colorClass }: { label: string; value: number; max: number; colorClass: string }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-sm">
        <span className="font-semibold">{label}</span>
        <span className="font-bold tabular-nums">{value}</span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all", colorClass)}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export default function AnalyticsPage() {
  const [premiumGoal, setPremiumGoal] = useState(0);
  useEffect(() => { setPremiumGoal(loadPremiumGoal()); }, []);

  const { data: leads = [], isLoading } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const { data: archivedLeads = [] } = useQuery<Lead[]>({
    queryKey: ["/api/leads?archived=true"],
    queryFn: async () => {
      const res = await fetch("/api/leads?archived=true");
      return res.json();
    },
  });

  const all = useMemo(() => [...leads, ...archivedLeads], [leads, archivedLeads]);

  const stats = useMemo(() => {
    const active = leads.length;
    const allSold = all.filter((l) => l.status === "Sold");
    const quoted = leads.filter((l) => l.status === "Quoted");
    const lost = leads.filter((l) => l.status === "Lost");
    const totalRevenue = allSold.reduce((sum, l) => sum + (l.soldPremium || 0), 0);
    const closeRate = active > 0 ? (allSold.length / active) * 100 : 0;
    const avgCallsToSold = allSold.length > 0
      ? allSold.reduce((sum, l) => sum + (l.timesCalled ?? 0), 0) / allSold.length
      : 0;

    const bySource: Record<string, number> = {};
    leads.forEach((l) => {
      const k = l.leadSource || "Unknown";
      bySource[k] = (bySource[k] || 0) + 1;
    });

    const byInsurance: Record<string, number> = {};
    leads.forEach((l) => {
      byInsurance[l.insurance] = (byInsurance[l.insurance] || 0) + 1;
    });

    const byStatus: Record<string, number> = {};
    leads.forEach((l) => {
      byStatus[l.status] = (byStatus[l.status] || 0) + 1;
    });

    const soldBySource: Record<string, { count: number; revenue: number }> = {};
    allSold.forEach((l) => {
      const k = l.leadSource || "Unknown";
      if (!soldBySource[k]) soldBySource[k] = { count: 0, revenue: 0 };
      soldBySource[k].count += 1;
      soldBySource[k].revenue += l.soldPremium || 0;
    });

    return {
      active,
      sold: allSold.length,
      quoted: quoted.length,
      lost: lost.length,
      totalRevenue,
      closeRate,
      avgCallsToSold,
      bySource: Object.entries(bySource).sort((a, b) => b[1] - a[1]),
      byInsurance: Object.entries(byInsurance).sort((a, b) => b[1] - a[1]),
      byStatus: Object.entries(byStatus),
      soldBySource: Object.entries(soldBySource).sort((a, b) => b[1].revenue - a[1].revenue),
    };
  }, [leads, all]);

  const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  const monthlyBreakdown = useMemo(() => {
    const now = new Date();
    const currentKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

    const map: Record<string, { year: number; month: number; revenue: number; count: number }> = {};

    // Always include the current month
    map[currentKey] = { year: now.getFullYear(), month: now.getMonth() + 1, revenue: 0, count: 0 };

    all.filter((l) => l.status === "Sold" && l.soldAt).forEach((l) => {
      const d = new Date(l.soldAt!);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      if (!map[key]) map[key] = { year: d.getFullYear(), month: d.getMonth() + 1, revenue: 0, count: 0 };
      map[key].revenue += l.soldPremium || 0;
      map[key].count += 1;
    });

    return Object.entries(map)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, val]) => ({ key, ...val }));
  }, [all]);

  const maxSource = stats.bySource[0]?.[1] ?? 1;
  const maxInsurance = stats.byInsurance[0]?.[1] ?? 1;

  const statusBarColors: Record<string, string> = {
    New: "bg-blue-500",
    "Attempted Contact": "bg-yellow-500",
    Contacted: "bg-orange-500",
    Quoted: "bg-purple-500",
    "Follow-Up Scheduled": "bg-cyan-500",
    Sold: "bg-green-500",
    Lost: "bg-red-500",
  };

  const maxStatus = Math.max(...stats.byStatus.map((s) => s[1]), 1);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-black tracking-tight">Analytics</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Performance metrics for your lead pipeline</p>
      </div>

      {premiumGoal > 0 && (() => {
        const pct = Math.min(100, Math.round((stats.totalRevenue / premiumGoal) * 100));
        const remaining = Math.max(0, premiumGoal - stats.totalRevenue);
        const isComplete = stats.totalRevenue >= premiumGoal;
        return (
          <Card data-testid="card-premium-goal-analytics" className={cn(isComplete && "border-green-300 dark:border-green-800/60")}>
            <CardHeader className="pb-2 pt-4 px-5">
              <CardTitle className={cn("text-sm font-bold flex items-center gap-2", isComplete ? "text-green-600 dark:text-green-400" : "text-foreground")}>
                <Target className="w-4 h-4" />
                Premium Goal
                {isComplete && (
                  <span className="ml-auto text-xs font-bold px-2 py-0.5 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
                    Goal Reached!
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0 pb-5 px-5 space-y-2.5">
              <div className="flex justify-between text-sm font-semibold">
                <span data-testid="text-analytics-premium-earned">${stats.totalRevenue.toLocaleString()}</span>
                <span className="text-muted-foreground">of ${premiumGoal.toLocaleString()} goal</span>
              </div>
              <div className="w-full h-4 rounded-full bg-muted overflow-hidden" data-testid="progress-analytics-goal">
                <div
                  className={cn("h-full rounded-full transition-all duration-500", isComplete ? "bg-green-500" : pct >= 75 ? "bg-primary" : pct >= 40 ? "bg-primary/80" : "bg-primary/60")}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground font-medium">
                <span>{pct}% complete</span>
                {!isComplete
                  ? <span>${remaining.toLocaleString()} remaining</span>
                  : <span className="text-green-600 dark:text-green-400 font-semibold">✓ Goal achieved</span>
                }
              </div>
            </CardContent>
          </Card>
        );
      })()}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Active Leads" value={stats.active} icon={Users} />
        <StatCard label="Policies Sold" value={stats.sold} icon={CheckCircle2} />
        <StatCard
          label="Close Rate"
          value={`${stats.closeRate.toFixed(1)}%`}
          icon={Target}
          sub={`${stats.quoted} quoted`}
        />
        <StatCard
          label="Total Premium"
          value={stats.totalRevenue > 0 ? `$${stats.totalRevenue.toLocaleString()}` : "$0"}
          icon={DollarSign}
          sub={stats.avgCallsToSold > 0 ? `Avg ${stats.avgCallsToSold.toFixed(1)} calls/sale` : undefined}
        />
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              Lead Sources
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {stats.bySource.length === 0 ? (
              <p className="text-sm text-muted-foreground">No data yet</p>
            ) : (
              stats.bySource.map(([source, count]) => (
                <HorizontalBar
                  key={source}
                  label={source}
                  value={count}
                  max={maxSource}
                  colorClass="bg-primary"
                />
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Pipeline Status
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {stats.byStatus.length === 0 ? (
              <p className="text-sm text-muted-foreground">No data yet</p>
            ) : (
              stats.byStatus.map(([status, count]) => (
                <HorizontalBar
                  key={status}
                  label={status}
                  value={count}
                  max={maxStatus}
                  colorClass={statusBarColors[status] ?? "bg-primary"}
                />
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Insurance Types
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {stats.byInsurance.length === 0 ? (
              <p className="text-sm text-muted-foreground">No data yet</p>
            ) : (
              stats.byInsurance.map(([type, count]) => (
                <HorizontalBar
                  key={type}
                  label={type}
                  value={count}
                  max={maxInsurance}
                  colorClass="bg-violet-500"
                />
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            Sold Leads by Source
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {stats.soldBySource.length === 0 ? (
            <p className="text-sm text-muted-foreground">No sold leads yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/50">
                    <th className="text-left py-2 pr-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Source</th>
                    <th className="text-right py-2 pr-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Policies</th>
                    <th className="text-right py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Premium</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.soldBySource.map(([source, data]) => {
                    const maxRev = stats.soldBySource[0]?.[1].revenue || 1;
                    const barPct = maxRev > 0 ? (data.revenue / maxRev) * 100 : 0;
                    return (
                      <tr key={source} className="border-b border-border/30 last:border-0">
                        <td className="py-3 pr-4 font-semibold">{source}</td>
                        <td className="py-3 pr-4 text-right tabular-nums text-muted-foreground">{data.count}</td>
                        <td className="py-3 text-right">
                          <div className="flex items-center justify-end gap-3">
                            <div className="w-24 h-1.5 rounded-full bg-muted overflow-hidden hidden sm:block">
                              <div className="h-full rounded-full bg-green-500 transition-all" style={{ width: `${barPct}%` }} />
                            </div>
                            <span className="font-bold tabular-nums">
                              {data.revenue > 0 ? `$${data.revenue.toLocaleString()}` : "—"}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-border">
                    <td className="py-3 pr-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Total</td>
                    <td className="py-3 pr-4 text-right font-bold tabular-nums">{stats.sold}</td>
                    <td className="py-3 text-right font-black text-base">${stats.totalRevenue.toLocaleString()}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-primary" />
            Monthly Premium Earned
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {monthlyBreakdown.length === 0 ? (
            <p className="text-sm text-muted-foreground">No sold leads yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/50">
                    <th className="text-left py-2 pr-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Month</th>
                    <th className="text-right py-2 pr-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Policies</th>
                    <th className="text-right py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Premium</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyBreakdown.map((row) => {
                    const now = new Date();
                    const isCurrent = row.year === now.getFullYear() && row.month === (now.getMonth() + 1);
                    const maxRevenue = Math.max(...monthlyBreakdown.map((r) => r.revenue), 1);
                    const barPct = maxRevenue > 0 ? (row.revenue / maxRevenue) * 100 : 0;
                    return (
                      <tr key={row.key} className={cn("border-b border-border/30 last:border-0", isCurrent && "bg-primary/5")}>
                        <td className="py-3 pr-4 font-semibold whitespace-nowrap">
                          {MONTH_NAMES[row.month - 1]} {row.year}
                          {isCurrent && (
                            <span className="ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">Current</span>
                          )}
                        </td>
                        <td className="py-3 pr-4 text-right tabular-nums text-muted-foreground">
                          {row.count}
                        </td>
                        <td className="py-3 text-right">
                          <div className="flex items-center justify-end gap-3">
                            <div className="w-24 h-1.5 rounded-full bg-muted overflow-hidden hidden sm:block">
                              <div
                                className="h-full rounded-full bg-primary transition-all"
                                style={{ width: `${barPct}%` }}
                              />
                            </div>
                            <span className={cn("font-bold tabular-nums", row.revenue === 0 ? "text-muted-foreground" : "text-foreground")}>
                              {row.revenue > 0 ? `$${row.revenue.toLocaleString()}` : "—"}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-border">
                    <td className="py-3 pr-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Total</td>
                    <td className="py-3 pr-4 text-right font-bold tabular-nums">
                      {monthlyBreakdown.reduce((s, r) => s + r.count, 0)}
                    </td>
                    <td className="py-3 text-right font-black text-base">
                      ${stats.totalRevenue.toLocaleString()}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
