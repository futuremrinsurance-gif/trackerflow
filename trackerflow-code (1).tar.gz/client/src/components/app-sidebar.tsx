import { useEffect, useState, useCallback } from "react";
import { loadAgencyCompany } from "@/lib/leadSettings";
import { useLocation, Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  Users,
  KanbanSquare,
  BarChart3,
  Archive,
  Plus,
  Settings,
  Share2,
  Globe,
  Star,
  LogOut,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type ExternalSource = {
  id: string;
  name: string;
  slug: string;
  url: string;
  isMain?: boolean;
};

const SOURCES_KEY = "trackerflow_external_sources_v1";

function loadSources(): ExternalSource[] {
  try {
    const raw = localStorage.getItem(SOURCES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function normalizeUrl(u: string) {
  const url = (u || "").trim();
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  return `https://${url}`;
}


const coreNavItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Leads", url: "/leads", icon: Users },
  { title: "Archive", url: "/archive", icon: Archive },
  { title: "Pipeline", url: "/pipeline", icon: KanbanSquare },
  { title: "Analytics", url: "/analytics", icon: BarChart3 },
];

const bottomNavItems = [
  { title: "Settings", url: "/settings", icon: Settings },
  { title: "Share", url: "/share", icon: Share2 },
];

const AGENCY_KEY = "trackerflow_agency_company_v1";

export function AppSidebar() {
  const [location] = useLocation();
  const [sources, setSources] = useState<ExternalSource[]>([]);
  const [agencyCompany, setAgencyCompany] = useState(() => loadAgencyCompany());
  const { toast } = useToast();
  const { user, logout } = useAuth();

  const openExternal = useCallback((url: string, name: string) => {
    const u = normalizeUrl(url);
    if (!u) return;
    const w = window.open(u, "_blank", "noopener,noreferrer");
    if (!w) {
      toast({
        title: `Popup blocked`,
        description: `Could not open ${name} in a new tab.`,
        action: (
          <button
            className="text-xs font-bold underline underline-offset-2"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(u);
                toast({ title: "Link copied!" });
              } catch {
                window.prompt("Copy this link:", u);
              }
            }}
          >
            Copy Link
          </button>
        ) as any,
      });
    } else {
      try { w.focus(); } catch {}
    }
  }, [toast]);

  useEffect(() => {
    setSources(loadSources());
    setAgencyCompany(loadAgencyCompany());

    const onStorage = (e: StorageEvent) => {
      if (e.key === SOURCES_KEY) setSources(loadSources());
      if (e.key === AGENCY_KEY) setAgencyCompany(loadAgencyCompany());
    };
    const onFocus = () => {
      setSources(loadSources());
      setAgencyCompany(loadAgencyCompany());
    };

    window.addEventListener("storage", onStorage);
    window.addEventListener("focus", onFocus);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  const orderedSources = [
    ...sources.filter((s) => s.isMain),
    ...sources.filter((s) => !s.isMain).sort((a, b) => a.name.localeCompare(b.name)),
  ];

  function NavItem({ title, url, icon: Icon }: { title: string; url: string; icon: typeof LayoutDashboard }) {
    const isActive = url === "/" ? location === "/" : location.startsWith(url);
    return (
      <SidebarMenuItem>
        <SidebarMenuButton asChild data-active={isActive}>
          <Link
            href={url}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 transition-colors",
              isActive
                ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold"
                : "text-sidebar-foreground/70"
            )}
            data-testid={`nav-${title.toLowerCase().replace(/\s+/g, "-")}`}
          >
            <Icon className="w-4 h-4 flex-shrink-0" />
            <span>{title}</span>
          </Link>
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  }

  return (
    <Sidebar>
      <SidebarHeader className="px-4 py-5">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="TrackerFlow" className="w-8 h-8 rounded-lg object-contain flex-shrink-0" />
          <div className="min-w-0">
            <div className="font-black text-sm tracking-tight leading-none">TrackerFlow</div>
            {agencyCompany ? (
              <div
                className="text-[11px] font-bold mt-0.5 truncate text-primary"
                data-testid="text-agency-company"
                title={agencyCompany}
              >
                {agencyCompany}
              </div>
            ) : (
              <div className="text-[11px] text-muted-foreground font-medium mt-0.5">Insurance CRM</div>
            )}
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {coreNavItems.map((item) => (
                <NavItem key={item.url} {...item} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {orderedSources.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground/60 px-3 pb-1">
              Lead Sources
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {orderedSources.map((src) => (
                  <SidebarMenuItem key={src.id}>
                    <SidebarMenuButton asChild>
                      <button
                        type="button"
                        onClick={() => openExternal(src.url, src.name)}
                        title={normalizeUrl(src.url)}
                        className="flex items-center gap-3 rounded-lg px-3 py-2 transition-colors text-sidebar-foreground/70 w-full text-left"
                        data-testid={`nav-source-${src.slug}`}
                      >
                        {src.isMain
                          ? <Star className="w-4 h-4 flex-shrink-0" />
                          : <Globe className="w-4 h-4 flex-shrink-0" />
                        }
                        <span>{src.name}</span>
                      </button>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {bottomNavItems.map((item) => (
                <NavItem key={item.url} {...item} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-2">
          <SidebarGroupContent>
            <div className="px-2">
              <Button asChild size="sm" className="w-full" data-testid="button-new-lead-sidebar">
                <Link href="/leads/new">
                  <Plus className="w-4 h-4 mr-1.5" />
                  New Lead
                </Link>
              </Button>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="px-4 py-3 space-y-2">
        <div className="flex items-center justify-between gap-2 rounded-xl bg-muted/50 px-3 py-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
              <span className="text-[10px] font-black text-primary-foreground uppercase">
                {user?.username?.[0] ?? "?"}
              </span>
            </div>
            <span className="text-xs font-semibold truncate">{user?.username}</span>
          </div>
          <button
            onClick={() => logout.mutate()}
            disabled={logout.isPending}
            className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            title="Sign out"
            data-testid="button-sign-out"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="text-[11px] text-muted-foreground/60 font-medium text-center">
          TrackerFlow v1.0
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
