import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Phone,
  Mail,
  MapPin,
  ExternalLink,
  CalendarClock,
  MessageSquare,
  Cake,
  Globe,
  Shield,
  User,
  AlertCircle,
  Copy,
  Check,
  Minus,
  Plus,
} from "lucide-react";
import { useState as useLocalState } from "react";
import { Link } from "wouter";
import {
  cn,
  statusColor,
  insuranceColor,
  priorityColor,
  formatRelative,
  formatDateTime,
  formatDate,
} from "@/lib/utils";
import type { Lead, Task, Activity } from "@shared/schema";


function CopyRow({ icon: Icon, label, value, href, className }: {
  icon: React.ElementType;
  label: string;
  value: string;
  href?: string;
  className?: string;
}) {
  const [copied, setCopied] = useLocalState(false);

  async function handleCopy(e: React.MouseEvent) {
    e.preventDefault();
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  }

  return (
    <button
      onClick={handleCopy}
      className="w-full flex items-start gap-3 py-2 rounded-lg px-1 -mx-1 hover:bg-muted/50 transition-colors group text-left"
      title={`Copy ${label}`}
      data-testid={`copy-${label.toLowerCase().replace(/\s+/g, "-")}`}
    >
      <div className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className={cn("text-sm font-semibold break-words", className)}>{value}</p>
      </div>
      <div className="flex-shrink-0 mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
        {copied
          ? <Check className="w-3.5 h-3.5 text-green-500" />
          : <Copy className="w-3.5 h-3.5 text-muted-foreground" />
        }
      </div>
    </button>
  );
}

function InfoRow({ icon: Icon, label, value, href, className }: {
  icon: React.ElementType;
  label: string;
  value: string;
  href?: string;
  className?: string;
}) {
  return (
    <div className="flex items-start gap-3 py-2">
      <div className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{label}</p>
        {href ? (
          <a href={href} className={cn("text-sm font-semibold hover:text-primary transition-colors break-all", className)}>
            {value}
          </a>
        ) : (
          <p className={cn("text-sm font-semibold break-words", className)}>{value}</p>
        )}
      </div>
    </div>
  );
}

interface LeadSheetProps {
  leadId: string | null;
  open: boolean;
  onClose: () => void;
}

export function LeadSheet({ leadId, open, onClose }: LeadSheetProps) {
  const { data: lead, isLoading } = useQuery<Lead>({
    queryKey: ["/api/leads", leadId],
    enabled: !!leadId,
  });

  const { data: activities = [] } = useQuery<Activity[]>({
    queryKey: ["/api/activities", leadId],
    enabled: !!leadId,
  });

  const { data: allTasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    enabled: !!leadId,
  });

  const updateMutation = useMutation({
    mutationFn: (data: { timesCalled: number }) =>
      apiRequest("PATCH", `/api/leads/${leadId}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads", leadId] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
    },
  });

  const pendingTasks = allTasks.filter((t) => t.leadId === leadId && !t.completedAt);
  const recentNotes = activities.filter((a) => a.note).slice(0, 5);

  const fullAddress = lead
    ? [lead.street, lead.city, lead.state, lead.zip].filter(Boolean).join(", ")
    : "";

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        className="max-w-3xl w-full p-0 gap-0 flex flex-col max-h-[88vh] overflow-hidden"
        data-testid="lead-sheet"
      >
        <DialogTitle className="sr-only">
          {lead ? `${lead.firstName} ${lead.lastName}` : "Lead Details"}
        </DialogTitle>
        <DialogDescription className="sr-only">
          Full contact card for this lead
        </DialogDescription>

        {isLoading || !lead ? (
          <div className="p-8 space-y-4">
            <div className="flex items-center gap-4">
              <Skeleton className="w-16 h-16 rounded-2xl flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-6 w-48" />
                <Skeleton className="h-4 w-72" />
              </div>
            </div>
            <Skeleton className="h-px w-full" />
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-3">
                <Skeleton className="h-12 rounded-xl" />
                <Skeleton className="h-12 rounded-xl" />
                <Skeleton className="h-12 rounded-xl" />
              </div>
              <div className="space-y-3">
                <Skeleton className="h-12 rounded-xl" />
                <Skeleton className="h-24 rounded-xl" />
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="px-7 pt-7 pb-5 border-b flex-shrink-0">
              <div className="flex items-start gap-5">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0 font-black text-2xl text-primary">
                  {lead.firstName[0]}{lead.lastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <h2 className="text-xl font-black tracking-tight">
                        {lead.firstName} {lead.lastName}
                      </h2>
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        <span className={cn("text-[11px] font-semibold px-2.5 py-0.5 rounded-full", statusColor(lead.status))}>
                          {lead.status}
                        </span>
                        <span className={cn("text-[11px] font-semibold px-2.5 py-0.5 rounded-full", insuranceColor(lead.insurance))}>
                          {lead.insurance}
                        </span>
                        {lead.priority && (
                          <span className={cn("text-[11px] font-semibold px-2.5 py-0.5 rounded-full", priorityColor(lead.priority))}>
                            {lead.priority}
                          </span>
                        )}
                        {lead.isArchived && (
                          <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-muted text-muted-foreground">
                            Archived
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {lead.phone && (
                        <Button size="sm" asChild data-testid="sheet-button-call">
                          <a href={`tel:${lead.phone}`}>
                            <Phone className="w-3.5 h-3.5 mr-1.5" />
                            Call
                          </a>
                        </Button>
                      )}
                      {lead.email && (
                        <Button size="sm" variant="outline" asChild data-testid="sheet-button-email">
                          <a href={`mailto:${lead.email}`}>
                            <Mail className="w-3.5 h-3.5 mr-1.5" />
                            Email
                          </a>
                        </Button>
                      )}
                      <Button size="sm" variant="outline" asChild data-testid="sheet-button-open-full">
                        <Link href={`/leads/${lead.id}`} onClick={onClose}>
                          <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                          Full Profile
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-0 divide-y md:divide-y-0 md:divide-x">

                {/* Left column — Contact Info */}
                <div className="px-7 py-5 space-y-0.5">
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">Contact Info</p>

                  {lead.phone && (
                    <CopyRow icon={Phone} label="Phone" value={lead.phone} />
                  )}
                  {lead.email && (
                    <CopyRow icon={Mail} label="Email" value={lead.email} />
                  )}
                  {fullAddress && (
                    <CopyRow icon={MapPin} label="Address" value={fullAddress} />
                  )}
                  {lead.dateOfBirth && (
                    <InfoRow icon={Cake} label="Date of Birth" value={formatDate(lead.dateOfBirth)} />
                  )}
                  {lead.crmLink && (
                    <InfoRow icon={Globe} label="CRM Link" value={lead.crmLink} href={lead.crmLink} />
                  )}

                  <Separator className="my-4" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">Lead Details</p>

                  {lead.leadSource && (
                    <InfoRow icon={User} label="Source" value={lead.leadSource} />
                  )}
                  {lead.insurance && (
                    <InfoRow icon={Shield} label="Insurance" value={lead.insurance} />
                  )}
                  {lead.soldPremium && (
                    <InfoRow
                      icon={Shield}
                      label="Sold Premium"
                      value={`$${lead.soldPremium.toLocaleString()}`}
                      className="text-green-700 dark:text-green-400 font-bold"
                    />
                  )}
                  {lead.renewalDate && (
                    <InfoRow icon={CalendarClock} label="Renewal Date" value={formatDate(lead.renewalDate)} />
                  )}

                  <div className="py-2">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Times Called</p>
                    <div className="flex items-center gap-2">
                      <Button
                        size="icon"
                        variant="outline"
                        className="w-8 h-8 flex-shrink-0"
                        disabled={updateMutation.isPending || (lead.timesCalled ?? 0) <= 0}
                        onClick={() => updateMutation.mutate({ timesCalled: Math.max(0, (lead.timesCalled ?? 0) - 1) })}
                        data-testid="sheet-button-decrement-calls"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </Button>
                      <div className="flex-1 flex items-center gap-1">
                        {Array.from({ length: 9 }).map((_, i) => (
                          <button
                            key={i}
                            disabled={updateMutation.isPending}
                            onClick={() => updateMutation.mutate({ timesCalled: i + 1 })}
                            className={cn(
                              "flex-1 h-4 rounded-full transition-colors",
                              i < (lead.timesCalled ?? 0)
                                ? (lead.timesCalled ?? 0) >= 7
                                  ? "bg-red-500 hover:bg-red-400"
                                  : (lead.timesCalled ?? 0) >= 4
                                  ? "bg-amber-500 hover:bg-amber-400"
                                  : "bg-primary hover:bg-primary/80"
                                : "bg-muted hover:bg-muted-foreground/30"
                            )}
                            data-testid={`sheet-dot-${i}`}
                          />
                        ))}
                      </div>
                      <Button
                        size="icon"
                        variant="default"
                        className="w-8 h-8 flex-shrink-0"
                        disabled={updateMutation.isPending || (lead.timesCalled ?? 0) >= 9}
                        onClick={() => updateMutation.mutate({ timesCalled: Math.min(9, (lead.timesCalled ?? 0) + 1) })}
                        data-testid="sheet-button-increment-calls"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </Button>
                      <span className="text-sm font-bold tabular-nums w-8 text-center text-muted-foreground">
                        {lead.timesCalled ?? 0}/9
                      </span>
                    </div>
                    {(lead.timesCalled ?? 0) >= 7 && (
                      <p className="text-xs font-semibold text-red-500 mt-2">
                        High call count — consider archiving if no response.
                      </p>
                    )}
                  </div>
                </div>

                {/* Right column — Activity & Tasks */}
                <div className="px-7 py-5">
                  {pendingTasks.length > 0 && (
                    <>
                      <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-3">
                        Upcoming Activities
                      </p>
                      <div className="space-y-2 mb-5">
                        {pendingTasks.slice(0, 4).map((task) => {
                          const isOver = new Date(task.dueAt) < new Date();
                          return (
                            <div
                              key={task.id}
                              className={cn(
                                "flex items-start gap-3 rounded-xl px-3 py-2.5 border",
                                isOver
                                  ? "border-red-200 bg-red-50/50 dark:border-red-900/40 dark:bg-red-950/20"
                                  : "border-border/50 bg-muted/30"
                              )}
                              data-testid={`sheet-task-${task.id}`}
                            >
                              <CalendarClock className={cn("w-3.5 h-3.5 flex-shrink-0 mt-0.5", isOver ? "text-red-500" : "text-primary")} />
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-bold">{task.title || "Follow-up"}</p>
                                <p className={cn("text-xs mt-0.5", isOver ? "text-red-500 font-semibold" : "text-muted-foreground")}>
                                  {formatDateTime(task.dueAt)}
                                </p>
                              </div>
                              {isOver && <AlertCircle className="w-3.5 h-3.5 text-red-500 flex-shrink-0 mt-0.5" />}
                            </div>
                          );
                        })}
                      </div>
                      <Separator className="mb-5" />
                    </>
                  )}

                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-3">
                    Recent Notes
                  </p>
                  {recentNotes.length === 0 ? (
                    <div className="py-6 text-center text-muted-foreground rounded-xl border border-dashed border-border">
                      <MessageSquare className="w-6 h-6 mx-auto mb-1.5 opacity-30" />
                      <p className="text-sm font-medium">No notes yet</p>
                      <p className="text-xs mt-0.5">Open the full profile to add notes.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {recentNotes.map((act) => (
                        <div
                          key={act.id}
                          className="flex items-start gap-3 rounded-xl border border-border/50 bg-muted/20 px-3 py-2.5"
                          data-testid={`sheet-activity-${act.id}`}
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-medium text-foreground/80 leading-relaxed">{act.note}</p>
                            <p className="text-[11px] text-muted-foreground/60 mt-1">{formatRelative(act.createdAt)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="px-7 py-4 border-t bg-muted/20">
                <Button variant="outline" className="w-full" asChild>
                  <Link href={`/leads/${lead.id}`} onClick={onClose} data-testid="sheet-button-full-profile-bottom">
                    <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                    Open Full Profile to Edit & Manage
                  </Link>
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
