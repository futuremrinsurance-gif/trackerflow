import { useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle2, X } from "lucide-react";
import { cn } from "@/lib/utils";

// ── Field definitions ─────────────────────────────────────────────────────────

const LEAD_FIELDS = [
  { key: "firstName",   label: "First Name" },
  { key: "lastName",    label: "Last Name" },
  { key: "phone",       label: "Phone" },
  { key: "email",       label: "Email" },
  { key: "address",     label: "Full Address (stores street + parses city/state/zip)" },
  { key: "street",      label: "Street Address" },
  { key: "city",        label: "City" },
  { key: "state",       label: "State" },
  { key: "zip",         label: "Zip" },
  { key: "leadSource",  label: "Lead Source" },
  { key: "insurance",   label: "Insurance Type" },
  { key: "status",      label: "Status (Lost/Declined detection)" },
  { key: "dateOfBirth", label: "Date of Birth" },
  { key: "timesCalled", label: "Times Called" },
  { key: "crmLink",     label: "CRM Link" },
] as const;

type LeadFieldKey = (typeof LEAD_FIELDS)[number]["key"];
type ColumnMap = Record<string, LeadFieldKey | "ignore">;

// ── Alias matching ────────────────────────────────────────────────────────────

const ALIASES: Record<LeadFieldKey, string[]> = {
  firstName:   ["first name", "first", "fname", "given name", "firstname", "forename"],
  lastName:    ["last name", "last", "lname", "surname", "lastname", "family name"],
  phone:       ["phone", "phone number", "cell", "mobile", "telephone", "tel", "cell phone", "contact number"],
  email:       ["email", "e-mail", "email address", "mail"],
  address:     ["address", "full address", "mailing address", "addr", "d"],
  street:      ["street", "street address", "street 1", "address line 1", "addr1", "address 1"],
  city:        ["city", "town", "municipality", "locality"],
  state:       ["state", "province", "region", "state/province"],
  zip:         ["zip", "zip code", "postal", "postal code", "zipcode", "postcode"],
  leadSource:  ["lead source", "source", "referral", "channel", "origin", "marketing source"],
  insurance:   ["line of insurance", "insurance type", "insurance", "line", "policy type", "coverage", "product"],
  status:      ["status", "lead status", "disposition", "outcome", "result", "call status", "stage"],
  dateOfBirth: ["date of birth", "dob", "birth date", "birthday", "birth", "born", "date of birth (mm/dd/yyyy)", "dob (mm/dd/yyyy)"],
  timesCalled: ["times called", "call count", "calls", "called", "num calls", "number of calls"],
  crmLink:     ["crm link", "crm", "crm url", "salesforce link", "sf link", "link", "record link", "opportunity link"],
};

function normalize(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}

function guessField(header: string): LeadFieldKey | "ignore" {
  const h = normalize(header);
  for (const [field, aliases] of Object.entries(ALIASES) as [LeadFieldKey, string[]][]) {
    if (aliases.some((a) => h === a || h.includes(a))) return field;
  }
  return "ignore";
}

function autoMap(headers: string[]): ColumnMap {
  const map: ColumnMap = {};
  const used = new Set<LeadFieldKey>();
  for (const h of headers) {
    const guess = guessField(h);
    if (guess !== "ignore" && !used.has(guess)) {
      map[h] = guess;
      used.add(guess);
    } else {
      map[h] = "ignore";
    }
  }
  return map;
}

// ── Address parser ────────────────────────────────────────────────────────────

const STATE_ABBR: Record<string, string> = {
  "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR", "california": "CA",
  "colorado": "CO", "connecticut": "CT", "delaware": "DE", "florida": "FL", "georgia": "GA",
  "hawaii": "HI", "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA",
  "kansas": "KS", "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD",
  "massachusetts": "MA", "michigan": "MI", "minnesota": "MN", "mississippi": "MS",
  "missouri": "MO", "montana": "MT", "nebraska": "NE", "nevada": "NV",
  "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM", "new york": "NY",
  "north carolina": "NC", "north dakota": "ND", "ohio": "OH", "oklahoma": "OK",
  "oregon": "OR", "pennsylvania": "PA", "rhode island": "RI", "south carolina": "SC",
  "south dakota": "SD", "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT",
  "virginia": "VA", "washington": "WA", "west virginia": "WV", "wisconsin": "WI",
  "wyoming": "WY",
};

const STREET_SUFFIX_RE = /\b(st|ave|blvd|rd|dr|ln|way|cir|ct|pl|hwy|pkwy|trl|loop|run|pass|pike|route|rte)\b\.?/gi;

function extractCityFromMixed(raw: string): string {
  const matches = Array.from(raw.matchAll(STREET_SUFFIX_RE));
  if (matches.length) {
    const last = matches[matches.length - 1];
    const afterSuffix = raw.slice(last.index! + last[0].length).trim();
    if (afterSuffix.length > 0) return afterSuffix;
  }
  return raw;
}

function toTitleCase(s: string) {
  return s.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
}

function parseAddress(address: string): { city: string; state: string; zip: string } {
  const empty = { city: "", state: "", zip: "" };
  if (!address?.trim()) return empty;
  const cleaned = address.replace(/\s*,?\s*united states\s*$/i, "").replace(/\s*,?\s*usa\s*$/i, "").trim();
  const parts = cleaned.split(",").map((p) => p.trim()).filter(Boolean);
  if (parts.length < 2) return empty;
  const lastPart = parts[parts.length - 1];
  const zipMatch = lastPart.match(/(\d{5}(?:-\d{4})?)\s*$/);
  if (zipMatch) {
    const zip = zipMatch[1];
    const beforeZip = lastPart.slice(0, lastPart.lastIndexOf(zipMatch[0])).trim();
    let state = "";
    if (/^[A-Z]{2}$/i.test(beforeZip)) {
      state = beforeZip.toUpperCase();
    } else {
      state = STATE_ABBR[beforeZip.toLowerCase()] ?? beforeZip.slice(0, 2).toUpperCase();
    }
    let city = parts[parts.length - 2];
    if (/\d/.test(city)) city = extractCityFromMixed(city);
    return { city: toTitleCase(city.trim()), state, zip };
  }
  if (/^[A-Z]{2}$/i.test(lastPart)) {
    const state = lastPart.toUpperCase();
    const prevPart = parts[parts.length - 2];
    const prevZip = prevPart.match(/(\d{5}(?:-\d{4})?)$/);
    if (prevZip) {
      const city = prevPart.slice(0, prevPart.lastIndexOf(prevZip[0])).trim();
      return { city: toTitleCase(city), state, zip: prevZip[1] };
    }
    return { city: toTitleCase(prevPart), state, zip: "" };
  }
  return empty;
}

// ── Row processing ────────────────────────────────────────────────────────────

function rowToLead(row: Record<string, string>, colMap: ColumnMap) {
  const lead: Record<string, string> = {};
  for (const [col, field] of Object.entries(colMap)) {
    if (field === "ignore" || !row[col]) continue;
    const val = String(row[col]).trim();
    if (field === "address") {
      if (!lead.street) lead.street = val;
      const { city, state, zip } = parseAddress(val);
      if (city && !lead.city) lead.city = city;
      if (state && !lead.state) lead.state = state;
      if (zip && !lead.zip) lead.zip = zip;
    } else {
      lead[field] = val;
    }
  }
  return lead;
}

function isValidRow(lead: Record<string, string>) {
  return !!(lead.firstName || lead.lastName || lead.phone || lead.email);
}

function cleanPhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length === 10) return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  if (digits.length === 11 && digits[0] === "1")
    return `${digits.slice(1, 4)}-${digits.slice(4, 7)}-${digits.slice(7)}`;
  return phone;
}

function cleanInsurance(val: string): string {
  const v = val.toLowerCase().trim();
  if (v.includes("home") && v.includes("auto")) return "Auto and Home";
  if (v.includes("auto")) return "Auto";
  if (v.includes("home")) return "Home";
  if (v.includes("life")) return "Life";
  if (v.includes("health")) return "Health";
  if (v.includes("commercial")) return "Commercial";
  if (v.includes("umbrella")) return "Umbrella";
  return val;
}

// ── Component ─────────────────────────────────────────────────────────────────

interface Props {
  open: boolean;
  onClose: () => void;
}

type Step = "upload" | "map" | "done";

export default function ExcelImportDialog({ open, onClose }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const [step, setStep] = useState<Step>("upload");
  const [fileName, setFileName] = useState("");
  const [headers, setHeaders] = useState<string[]>([]);
  const [rows, setRows] = useState<Record<string, string>[]>([]);
  const [colMap, setColMap] = useState<ColumnMap>({});
  const [importCount, setImportCount] = useState(0);
  const [skippedCount, setSkippedCount] = useState(0);
  const [updatedCount, setUpdatedCount] = useState(0);
  const [updateMode, setUpdateMode] = useState(false);
  const [destination, setDestination] = useState<"auto" | "active" | "archive" | "lost">("auto");
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);

  function reset() {
    setStep("upload");
    setFileName("");
    setHeaders([]);
    setRows([]);
    setColMap({});
    setImportCount(0);
    setSkippedCount(0);
    setUpdatedCount(0);
    setDestination("auto");
  }

  async function uploadFile(file: File) {
    setIsParsing(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/import/parse", {
        method: "POST",
        body: form,
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        throw new Error(err.error || "Upload failed");
      }
      const { headers: hdrs, rows: data } = await res.json();
      setHeaders(hdrs);
      setRows(data);
      setColMap(autoMap(hdrs));
      setFileName(file.name);
      setStep("map");
    } catch (err: any) {
      toast({ title: "Parse error", description: err.message, variant: "destructive" });
    } finally {
      setIsParsing(false);
    }
  }

  function handleFileInput(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) uploadFile(file);
    e.target.value = "";
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) uploadFile(file);
  }

  const importMutation = useMutation({
    mutationFn: async () => {
      const valid = rows.map((r) => rowToLead(r, colMap)).filter(isValidRow);
      if (!valid.length) throw new Error("No valid rows to import.");
      let imported = 0;
      let skipped = 0;
      let updated = 0;
      for (const lead of valid) {
        const tc = parseInt(lead.timesCalled ?? "0", 10);
        const rawStatus = (lead.status ?? "").toLowerCase().trim();
        const isLost = rawStatus.includes("lost");
        const isDeclined = rawStatus.includes("declined") || rawStatus.includes("decline");

        let resolvedStatus: string;
        let resolvedArchived: boolean;
        if (destination === "active") {
          resolvedStatus = "New";
          resolvedArchived = false;
        } else if (destination === "archive") {
          resolvedStatus = "New";
          resolvedArchived = true;
        } else if (destination === "lost") {
          resolvedStatus = "Lost";
          resolvedArchived = false;
        } else {
          resolvedStatus = isLost ? "Lost" : isDeclined ? "Declined" : "New";
          resolvedArchived = false;
        }

        const payload = {
          skipIfDuplicate: true,
          firstName: (lead.firstName || "(Unknown)").trim(),
          lastName: (lead.lastName || "").trim(),
          phone: lead.phone ? cleanPhone(lead.phone) : null,
          email: lead.email || null,
          street: lead.street || null,
          city: lead.city || null,
          state: lead.state || null,
          zip: lead.zip || null,
          leadSource: lead.leadSource || null,
          insurance: lead.insurance ? cleanInsurance(lead.insurance) : "Auto",
          status: resolvedStatus,
          priority: "Warm",
          timesCalled: isNaN(tc) ? 0 : Math.min(tc, 9),
          crmLink: lead.crmLink || null,
          dateOfBirth: lead.dateOfBirth || null,
          isArchived: resolvedArchived,
        };
        const res = await apiRequest("POST", "/api/leads", payload);
        const json = await res.json();
        if (json?.skipped) {
          if (updateMode && json.existingId) {
            const updatePayload: Record<string, unknown> = {
              status: resolvedStatus,
              isArchived: resolvedArchived,
            };
            if (lead.phone) updatePayload.phone = cleanPhone(lead.phone);
            if (lead.email) updatePayload.email = lead.email;
            if (lead.street) updatePayload.street = lead.street;
            if (lead.city) updatePayload.city = lead.city;
            if (lead.state) updatePayload.state = lead.state;
            if (lead.zip) updatePayload.zip = lead.zip;
            if (lead.leadSource) updatePayload.leadSource = lead.leadSource;
            if (lead.insurance) updatePayload.insurance = cleanInsurance(lead.insurance);
            if (lead.crmLink) updatePayload.crmLink = lead.crmLink;
            if (lead.dateOfBirth) updatePayload.dateOfBirth = lead.dateOfBirth;
            if (!isNaN(tc)) updatePayload.timesCalled = Math.min(tc, 9);
            await apiRequest("PATCH", `/api/leads/${json.existingId}`, updatePayload);
            updated++;
          } else {
            skipped++;
          }
        } else {
          imported++;
          const shouldNote = destination === "auto"
            ? (isLost || isDeclined)
            : destination === "lost" || destination === "archive";
          if (shouldNote && json?.id) {
            const noteText = destination === "archive"
              ? "Imported directly to Archive."
              : destination === "lost"
              ? "Imported directly to Lost Leads."
              : `Marked as ${resolvedStatus} in previous iteration — imported from spreadsheet.`;
            await apiRequest("POST", "/api/activities", {
              leadId: json.id,
              type: "note",
              content: noteText,
            });
          }
        }
      }
      return { imported, skipped, updated };
    },
    onSuccess: ({ imported, skipped, updated }) => {
      setImportCount(imported);
      setSkippedCount(skipped);
      setUpdatedCount(updated);
      setStep("done");
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
    },
    onError: (err: any) => {
      toast({ title: "Import failed", description: err.message, variant: "destructive" });
    },
  });

  const mappedHeaders = headers.filter((h) => colMap[h] !== "ignore");
  const preview = rows.slice(0, 5);
  const validCount = rows.map((r) => rowToLead(r, colMap)).filter(isValidRow).length;

  function handleClose() {
    reset();
    onClose();
  }

  function fieldLabel(key: LeadFieldKey | "ignore") {
    if (key === "ignore") return "— Ignore —";
    return LEAD_FIELDS.find((f) => f.key === key)?.label ?? key;
  }

  function previewValue(row: Record<string, string>, header: string) {
    const field = colMap[header];
    if (field === "address") {
      const { city, state, zip } = parseAddress(row[header] ?? "");
      const parts = [city, state, zip].filter(Boolean);
      return parts.length ? parts.join(", ") : row[header];
    }
    if (field === "phone" && row[header]) return cleanPhone(row[header]);
    if (field === "insurance" && row[header]) return cleanInsurance(row[header]);
    return row[header] || "";
  }

  const needsMapping = validCount === 0 && step === "map";

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="max-w-3xl p-0 gap-0 flex flex-col max-h-[90vh]">
        {/* Fixed header */}
        <div className="px-6 pt-6 pb-4 border-b flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-primary" />
            Import from Excel / CSV
          </DialogTitle>
          <DialogDescription className="mt-1">
            Upload a spreadsheet — TrackerFlow will auto-detect columns and extract name, address, phone, email, and more.
          </DialogDescription>
        </div>

        {/* Scrollable middle */}
        <div className="flex-1 overflow-y-auto px-6 py-5 min-h-0">
          {/* ── Step 1: Upload ── */}
          {step === "upload" && (
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => !isParsing && fileRef.current?.click()}
              className={cn(
                "border-2 border-dashed rounded-xl p-12 flex flex-col items-center gap-4 transition-colors",
                isParsing ? "opacity-60 cursor-default" : "cursor-pointer",
                isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/40"
              )}
              data-testid="excel-drop-zone"
            >
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Upload className={cn("w-7 h-7 text-primary", isParsing && "animate-pulse")} />
              </div>
              <div className="text-center">
                <p className="font-semibold">
                  {isParsing ? "Reading file…" : "Drop your file here or click to browse"}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Supports .xlsx, .xls, and .csv</p>
              </div>
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={handleFileInput}
                data-testid="input-excel-file"
              />
            </div>
          )}

          {/* ── Step 2: Map ── */}
          {step === "map" && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 text-sm p-3 bg-muted/50 rounded-xl">
                <FileSpreadsheet className="w-4 h-4 text-primary flex-shrink-0" />
                <span className="font-medium truncate">{fileName}</span>
                <span className="text-muted-foreground ml-auto flex-shrink-0">{rows.length} rows</span>
                <Button size="icon" variant="ghost" className="h-6 w-6" onClick={reset}>
                  <X className="w-3.5 h-3.5" />
                </Button>
              </div>

              <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-xl border border-border bg-muted/30">
                <div>
                  <p className="text-sm font-semibold leading-tight">Update existing leads</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    When a match is found, overwrite their data with values from this file instead of skipping them.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setUpdateMode((v) => !v)}
                  data-testid="toggle-update-mode"
                  className={cn(
                    "relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors focus:outline-none",
                    updateMode ? "bg-primary" : "bg-muted-foreground/30"
                  )}
                >
                  <span
                    className={cn(
                      "pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform transition-transform",
                      updateMode ? "translate-x-5" : "translate-x-0"
                    )}
                  />
                </button>
              </div>

              <div className="px-4 py-3 rounded-xl border border-border bg-muted/30 space-y-2">
                <p className="text-sm font-semibold leading-tight">Import destination</p>
                <p className="text-xs text-muted-foreground">
                  Choose where all leads land, or let TrackerFlow detect it from the Status column.
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {([
                    { value: "auto",    label: "Auto-detect",   desc: "Reads Status column" },
                    { value: "active",  label: "Active Leads",  desc: "Leads page" },
                    { value: "archive", label: "Archive",       desc: "Archive page" },
                    { value: "lost",    label: "Lost Leads",    desc: "Lost page" },
                  ] as const).map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setDestination(opt.value)}
                      data-testid={`dest-${opt.value}`}
                      className={cn(
                        "text-left px-3 py-2 rounded-lg border text-sm transition-colors",
                        destination === opt.value
                          ? "border-primary bg-primary/10 text-primary font-semibold"
                          : "border-border bg-background hover:border-primary/50 text-muted-foreground"
                      )}
                    >
                      <div className="font-medium">{opt.label}</div>
                      <div className="text-[11px] opacity-70 mt-0.5">{opt.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm font-semibold mb-1">Column Mapping</p>
                <p className="text-xs text-muted-foreground mb-3">
                  Auto-detected below. Adjust any dropdowns if needed. <strong>Full Address</strong> splits city, state, and zip automatically.
                </p>
                <div className="divide-y divide-border border border-border rounded-xl overflow-hidden">
                  {headers.map((h) => (
                    <div key={h} className="flex items-center gap-3 px-4 py-2 bg-background">
                      <span className="text-xs font-mono text-muted-foreground w-36 truncate flex-shrink-0" title={h}>
                        {h}
                      </span>
                      <span className="text-muted-foreground text-xs">→</span>
                      <Select
                        value={colMap[h] || "ignore"}
                        onValueChange={(v) => setColMap((prev) => ({ ...prev, [h]: v as LeadFieldKey | "ignore" }))}
                      >
                        <SelectTrigger className="h-7 text-xs flex-1" data-testid={`select-col-${h}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ignore">— Ignore this column —</SelectItem>
                          {LEAD_FIELDS.map((f) => (
                            <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {colMap[h] !== "ignore"
                        ? <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                        : <div className="w-4 h-4 flex-shrink-0" />}
                    </div>
                  ))}
                </div>
              </div>

              {preview.length > 0 && mappedHeaders.length > 0 && (
                <div>
                  <p className="text-sm font-semibold mb-2">Preview — first {preview.length} rows</p>
                  <div className="overflow-x-auto rounded-xl border border-border">
                    <table className="w-full text-xs">
                      <thead className="bg-muted/50">
                        <tr>
                          {mappedHeaders.map((h) => (
                            <th key={h} className="px-3 py-2 text-left font-semibold text-muted-foreground whitespace-nowrap">
                              {fieldLabel(colMap[h])}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {preview.map((row, i) => (
                          <tr key={i} className="bg-background">
                            {mappedHeaders.map((h) => (
                              <td key={h} className="px-3 py-2 text-muted-foreground max-w-[160px] truncate">
                                {previewValue(row, h) || <span className="italic text-border">empty</span>}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {needsMapping && (
                <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-3">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  To enable import, map at least one column to: First Name, Last Name, Phone, or Email.
                </div>
              )}
            </div>
          )}

          {/* ── Step 3: Done ── */}
          {step === "done" && (
            <div className="flex flex-col items-center gap-4 py-8">
              <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
              <div className="text-center space-y-2">
                {importCount > 0 && (
                  <p className="text-xl font-bold">
                    {importCount} lead{importCount !== 1 ? "s" : ""} imported
                  </p>
                )}
                {updatedCount > 0 && (
                  <p className="text-xl font-bold text-blue-600 dark:text-blue-400">
                    {updatedCount} lead{updatedCount !== 1 ? "s" : ""} updated
                  </p>
                )}
                {importCount === 0 && updatedCount === 0 && (
                  <p className="text-xl font-bold">Nothing to import</p>
                )}
                {skippedCount > 0 && (
                  <p className="text-sm font-semibold text-amber-600 dark:text-amber-400">
                    {skippedCount} duplicate{skippedCount !== 1 ? "s" : ""} skipped — already in your CRM
                  </p>
                )}
                <p className="text-sm text-muted-foreground">
                  {importCount > 0 && updatedCount === 0
                    ? "New leads are now visible in your pipeline."
                    : updatedCount > 0
                    ? "Existing leads have been refreshed with the latest data."
                    : "No changes were made."}
                </p>
              </div>
              <div className="flex gap-2 mt-2">
                <Button variant="outline" onClick={reset} data-testid="button-import-another">Import another file</Button>
                <Button onClick={handleClose} data-testid="button-import-done">Done</Button>
              </div>
            </div>
          )}
        </div>

        {/* Fixed footer — always visible */}
        {step === "map" && (
          <div className="px-6 py-4 border-t flex-shrink-0 flex justify-between items-center gap-2 flex-wrap bg-background">
            <Button variant="outline" onClick={reset}>Choose different file</Button>
            <div className="flex items-center gap-3">
              {needsMapping && (
                <span className="text-xs text-amber-600 font-medium">Map a name, phone, or email column first</span>
              )}
              <Button
                onClick={() => importMutation.mutate()}
                disabled={validCount === 0 || importMutation.isPending}
                data-testid="button-import-leads"
              >
                {importMutation.isPending ? "Importing…" : validCount > 0 ? `Import ${validCount} lead${validCount !== 1 ? "s" : ""}` : "Import leads"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
