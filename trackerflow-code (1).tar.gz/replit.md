# TrackerFlow — Insurance Lead CRM

## Overview
TrackerFlow is an insurance lead tracking CRM built with React + Express (Vite full-stack). It allows insurance agents to manage leads, track pipeline stages, and monitor analytics.

## Architecture
- **Frontend**: React + Vite, TanStack Query, shadcn/ui, Wouter routing, Tailwind CSS
- **Backend**: Express.js with in-memory storage (MemStorage)
- **Shared types**: Drizzle-Zod schemas in `shared/schema.ts`

## Key Features
- **Leads**: Grouped alphabetically by lead source, times-called tracker (0–9 dots)
- **Lead Detail**: Status updates, priority, times-called bar, notes/activity log, archive/restore
- **Pipeline**: Kanban board view by status (New → Attempted Contact → Contacted → Quoted → Follow-Up → Sold/Lost)
- **Analytics**: Close rate, revenue, lead source breakdown, insurance type breakdown
- **Dashboard**: Upcoming tasks, overdue tasks, stale leads alert
- **Archive**: View and restore archived leads

## Data Models
- **Lead**: firstName, lastName, phone, email, city, state, zip, leadSource, insurance, status, priority, timesCalled, crmLink, isArchived, archivedAt, soldPremium
- **Task**: leadId, title, type, dueAt, completedAt
- **Activity**: leadId, type, content (notes log)

## API Routes
- `GET /api/leads` — all active leads (or `?archived=true` for all)
- `GET /api/leads/:id` — single lead
- `POST /api/leads` — create lead
- `PATCH /api/leads/:id` — update lead (status, archive, timesCalled, etc.)
- `DELETE /api/leads/:id` — delete lead
- `GET /api/tasks` — all tasks (or `?leadId=X` for lead-specific)
- `POST /api/tasks` — create task
- `PATCH /api/tasks/:id` — update task (complete it)
- `GET /api/activities/:leadId` — activity log for a lead
- `POST /api/activities` — add note/activity

## Design
- Blue primary color (#3b82f6 / hsl 221 83% 53%)
- Light/dark mode support via shadcn CSS variables
- Sidebar navigation, card-based content layout
- Color-coded status badges and insurance type badges

## Seed Data
Pre-populated with 11 realistic insurance leads across 5 lead sources (Facebook Ads, Google Ads, Referral, Website, Cold Call) and 5 follow-up tasks.
