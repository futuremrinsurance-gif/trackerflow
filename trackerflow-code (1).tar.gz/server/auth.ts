import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import bcrypt from "bcryptjs";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { pool } from "./db";
import { storage } from "./storage";
import type { Express, RequestHandler } from "express";
import type { User } from "@shared/schema";

const PgStore = connectPgSimple(session);

declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      password: string;
    }
  }
}

function getBaseUrl(req: any): string {
  const host = req?.headers?.host || "localhost:5000";
  const protocol = host.includes("replit") || host.includes("repl.co") ? "https" : "http";
  return `${protocol}://${host}`;
}

export function setupAuth(app: Express) {
  app.use(
    session({
      store: new PgStore({
        pool,
        tableName: "session",
      }),
      secret: process.env.SESSION_SECRET || "trackerflow-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 30 * 24 * 60 * 60 * 1000,
      },
    })
  );

  app.use(passport.initialize());
  app.use(passport.session());

  // ── Username/password strategy ────────────────────────────────────────────
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username.toLowerCase().trim());
        if (!user) return done(null, false, { message: "Invalid username or password" });
        const match = await bcrypt.compare(password, user.password);
        if (!match) return done(null, false, { message: "Invalid username or password" });
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  // ── Google strategy (only enabled when credentials are present) ───────────
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    passport.use(
      new GoogleStrategy(
        {
          clientID: process.env.GOOGLE_CLIENT_ID,
          clientSecret: process.env.GOOGLE_CLIENT_SECRET,
          callbackURL: "/api/auth/google/callback",
          scope: ["profile", "email"],
        },
        async (_accessToken, _refreshToken, profile, done) => {
          try {
            const email = profile.emails?.[0]?.value;
            const googleId = profile.id;

            let user = await storage.getUserByGoogleId(googleId);
            if (user) return done(null, user);

            if (email) {
              user = await storage.getUserByUsername(email.toLowerCase());
              if (user) {
                await storage.linkGoogleId(user.id, googleId);
                return done(null, user);
              }
            }

            const displayName = email?.toLowerCase() ?? `google_${googleId}`;
            const placeholder = await bcrypt.hash(googleId + Date.now(), 4);
            user = await storage.createUser({ username: displayName, password: placeholder });
            await storage.linkGoogleId(user.id, googleId);
            return done(null, user);
          } catch (err) {
            return done(err as Error);
          }
        }
      )
    );
  }

  passport.serializeUser((user, done) => done(null, user.id));

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user ?? false);
    } catch (err) {
      done(err);
    }
  });
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export const requireAuth: RequestHandler = (req, res, next) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
};

export function safeUser(user: User) {
  const { password: _pw, ...safe } = user;
  return safe;
}

export function googleEnabled(): boolean {
  return !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}
