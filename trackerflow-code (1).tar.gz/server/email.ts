import { Resend } from "resend";

function getResend(): Resend | null {
  if (!process.env.RESEND_API_KEY) return null;
  return new Resend(process.env.RESEND_API_KEY);
}

const FROM = process.env.EMAIL_FROM || "TrackerFlow <onboarding@resend.dev>";

export async function sendTaskReminderEmail({
  to,
  taskTitle,
  taskType,
  dueAt,
  leadName,
  leadPhone,
}: {
  to: string;
  taskTitle: string;
  taskType: string;
  dueAt: Date | string;
  leadName: string;
  leadPhone?: string | null;
}): Promise<void> {
  const client = getResend();
  if (!client) {
    console.log("[email] RESEND_API_KEY not set — skipping email to", to);
    return;
  }

  const due = new Date(dueAt);
  const formatted = due.toLocaleString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  try {
    await client.emails.send({
      from: FROM,
      to,
      subject: `Reminder: ${taskTitle} with ${leadName}`,
      html: `
        <div style="font-family:sans-serif;max-width:520px;margin:0 auto;padding:24px;background:#f9fafb;border-radius:12px">
          <h2 style="margin:0 0 16px;font-size:20px;color:#111827">📋 Activity Reminder</h2>
          <div style="background:#ffffff;border-radius:8px;padding:20px;border:1px solid #e5e7eb">
            <table style="width:100%;border-collapse:collapse;font-size:14px">
              <tr style="border-bottom:1px solid #f3f4f6">
                <td style="padding:10px 8px;font-weight:600;color:#6b7280;width:110px">Activity</td>
                <td style="padding:10px 8px;font-weight:700;color:#111827">${taskTitle}</td>
              </tr>
              <tr style="border-bottom:1px solid #f3f4f6">
                <td style="padding:10px 8px;font-weight:600;color:#6b7280">Type</td>
                <td style="padding:10px 8px;color:#111827;text-transform:capitalize">${taskType}</td>
              </tr>
              <tr style="border-bottom:1px solid #f3f4f6">
                <td style="padding:10px 8px;font-weight:600;color:#6b7280">Scheduled</td>
                <td style="padding:10px 8px;color:#111827">${formatted}</td>
              </tr>
              <tr>
                <td style="padding:10px 8px;font-weight:600;color:#6b7280">Lead</td>
                <td style="padding:10px 8px;color:#111827">${leadName}${leadPhone ? ` &middot; ${leadPhone}` : ""}</td>
              </tr>
            </table>
          </div>
          <p style="margin:16px 0 0;font-size:12px;color:#9ca3af;text-align:center">
            TrackerFlow CRM &middot; You are receiving this because email reminders are enabled for this activity.
          </p>
        </div>
      `,
    });
    console.log(`[email] Sent reminder to ${to} for task "${taskTitle}"`);
  } catch (err) {
    console.error("[email] Failed to send reminder:", err);
  }
}
