import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertLeadSchema, insertTaskSchema, insertActivitySchema } from "@shared/schema";
import { z } from "zod";
import { setupAuth, requireAuth, hashPassword, safeUser, googleEnabled } from "./auth";
import passport from "passport";
import multer from "multer";
import * as XLSX from "xlsx";
import { sendTaskReminderEmail } from "./email";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// ─── Email reminder background job ──────────────────────────────────────────
async function runEmailReminders() {
  try {
    const pending = await storage.getPendingEmailTasks();
    for (const task of pending) {
      const lead = await storage.getLead(task.leadId);
      if (!lead) continue;
      const user = await storage.getUser(lead.userId);
      if (!user?.email) continue;
      await sendTaskReminderEmail({
        to: user.email,
        taskTitle: task.title,
        taskType: task.type,
        dueAt: task.dueAt,
        leadName: `${lead.firstName} ${lead.lastName}`,
        leadPhone: lead.phone,
      });
      await storage.markEmailSent(task.id);
    }
  } catch (err) {
    console.error("[email-job] Error running email reminders:", err);
  }
}

// ─── Renewal lead background job ─────────────────────────────────────────────
async function runRenewalCheck() {
  try {
    const soldLeads = await storage.getSoldLeadsNeedingRenewal();
    for (const lead of soldLeads) {
      await storage.createLead(
        {
          firstName: lead.firstName,
          lastName: lead.lastName,
          phone: lead.phone ?? undefined,
          email: lead.email ?? undefined,
          street: lead.street ?? undefined,
          city: lead.city ?? undefined,
          state: lead.state ?? undefined,
          zip: lead.zip ?? undefined,
          leadSource: lead.leadSource ?? undefined,
          insurance: lead.insurance,
          status: "New",
          priority: "Warm",
          timesCalled: 0,
          isArchived: false,
          dateOfBirth: lead.dateOfBirth ?? undefined,
          crmLink: lead.crmLink ?? undefined,
          renewalDate: undefined,
          renewalLeadCreated: false,
        },
        lead.userId,
      );
      await storage.updateLead(lead.id, { renewalLeadCreated: true });
      console.log(`[renewal] Created renewal lead for ${lead.firstName} ${lead.lastName} (renewalDate: ${lead.renewalDate})`);
    }
  } catch (err) {
    console.error("[renewal-job] Error running renewal check:", err);
  }
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  setupAuth(app);
  await (storage as any).seed?.();

  // Start background jobs
  setInterval(runEmailReminders, 15 * 60 * 1000);   // every 15 min
  setInterval(runRenewalCheck,   60 * 60 * 1000);    // every hour
  runRenewalCheck();                                  // also run at startup

  // ─── Auth routes ────────────────────────────────────────────────────────────

  app.post("/api/auth/register", async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: "Username and password required" });
    if (password.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters" });
    const existing = await storage.getUserByUsername(username.toLowerCase().trim());
    if (existing) return res.status(409).json({ error: "Username already taken" });
    const hashed = await hashPassword(password);
    const user = await storage.createUser({ username: username.toLowerCase().trim(), password: hashed });
    req.login(user, (err) => {
      if (err) return res.status(500).json({ error: "Login failed after registration" });
      res.status(201).json(safeUser(user));
    });
  });

  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ error: info?.message || "Invalid credentials" });
      req.login(user, (loginErr) => {
        if (loginErr) return next(loginErr);
        res.json(safeUser(user));
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.json({ ok: true });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    res.json(safeUser(req.user as any));
  });

  app.get("/api/auth/google/enabled", (_req, res) => {
    res.json({ enabled: googleEnabled() });
  });

  if (googleEnabled()) {
    app.get("/api/auth/google", passport.authenticate("google", { scope: ["profile", "email"] }));

    app.get(
      "/api/auth/google/callback",
      passport.authenticate("google", { failureRedirect: "/?error=google_failed" }),
      (req, res) => {
        res.redirect("/");
      }
    );
  }

  // ─── User profile ────────────────────────────────────────────────────────────

  app.patch("/api/user", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const { email } = req.body;
    if (email !== undefined && email !== null) {
      const trimmed = String(email).trim().toLowerCase();
      if (trimmed && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
        return res.status(400).json({ error: "Invalid email address" });
      }
      const updated = await storage.updateUser(userId, { email: trimmed || null });
      if (!updated) return res.status(404).json({ error: "User not found" });
      return res.json(safeUser(updated));
    }
    return res.status(400).json({ error: "No updatable fields provided" });
  });

  // ─── Leads ─────────────────────────────────────────────────────────────────

  app.get("/api/leads", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const includeArchived = req.query.archived === "true";
    const leads = await storage.getLeads(userId, includeArchived);
    res.json(leads);
  });

  app.get("/api/leads/:id", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const id = req.params.id as string;
    const lead = await storage.getLead(id, userId);
    if (!lead) return res.status(404).json({ error: "Not found" });
    res.json(lead);
  });

  app.post("/api/leads", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const { skipIfDuplicate, ...body } = req.body;
    const result = insertLeadSchema.safeParse(body);
    if (!result.success) return res.status(400).json({ error: result.error.flatten() });
    if (skipIfDuplicate) {
      const dup = await storage.findLeadDuplicate(
        userId,
        result.data.phone ?? null,
        result.data.firstName,
        result.data.lastName,
      );
      if (dup) return res.status(200).json({ skipped: true, existingId: dup.id });
    }
    const lead = await storage.createLead(result.data, userId);
    res.status(201).json(lead);
  });

  app.patch("/api/leads/:id", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const id = req.params.id as string;
    const body = { ...req.body };

    // Convert any ISO date strings to Date objects for timestamp columns
    for (const field of ["archivedAt", "lostAt", "soldAt"]) {
      if (body[field] && typeof body[field] === "string") {
        body[field] = new Date(body[field]);
      }
    }

    // Server-managed archive timestamp
    if ("isArchived" in body) {
      body.archivedAt = body.isArchived ? new Date() : null;
    }

    if ("status" in body) {
      const isLost = body.status === "Lost" || body.status === "Declined";
      body.lostAt = isLost ? new Date() : null;
      if (body.status === "Sold") {
        const existing = await storage.getLead(id, userId);
        if (existing && !existing.soldAt) body.soldAt = new Date();
      }
    }
    const lead = await storage.updateLead(id, body, userId);
    if (!lead) return res.status(404).json({ error: "Not found" });
    res.json(lead);
  });

  app.delete("/api/leads/:id", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    await storage.deleteLead(req.params.id as string, userId);
    res.status(204).send();
  });

  // ─── Tasks ──────────────────────────────────────────────────────────────────

  app.get("/api/tasks", requireAuth, async (req, res) => {
    const user = req.user as any;
    const leadId = req.query.leadId as string | undefined;
    const tasks = await storage.getTasks(leadId, leadId ? undefined : user.id);
    res.json(tasks);
  });

  app.post("/api/tasks", requireAuth, async (req, res) => {
    const result = insertTaskSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ error: result.error.flatten() });
    const task = await storage.createTask(result.data);
    res.status(201).json(task);
  });

  app.patch("/api/tasks/:id", requireAuth, async (req, res) => {
    const task = await storage.updateTask(req.params.id as string, req.body);
    if (!task) return res.status(404).json({ error: "Not found" });
    res.json(task);
  });

  // ─── Activities ─────────────────────────────────────────────────────────────

  app.get("/api/activities/:leadId", requireAuth, async (req, res) => {
    const activities = await storage.getActivities(req.params.leadId as string);
    res.json(activities);
  });

  app.post("/api/activities", requireAuth, async (req, res) => {
    const result = insertActivitySchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ error: result.error.flatten() });
    const activity = await storage.createActivity(result.data);
    res.status(201).json(activity);
  });

  // ─── Import ─────────────────────────────────────────────────────────────────

  app.post("/api/import/parse", requireAuth, upload.single("file"), (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ error: "No file uploaded" });
      const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows: Record<string, string>[] = XLSX.utils.sheet_to_json(sheet, { defval: "", raw: false });
      if (!rows.length) return res.status(400).json({ error: "No data rows found" });
      const headers = Object.keys(rows[0]);
      res.json({ headers, rows });
    } catch (err: any) {
      res.status(400).json({ error: "Could not parse file: " + err.message });
    }
  });

  // ─── Export ──────────────────────────────────────────────────────────────────

  app.post("/api/export/leads", requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const { ids, includeArchived } = req.body as { ids?: string[]; includeArchived?: boolean };
    const all = await storage.getLeads(userId, includeArchived ?? true);
    const selected = ids && ids.length > 0 ? all.filter((l) => ids.includes(l.id)) : all;
    const rows = selected.map((l) => ({
      "First Name": l.firstName,
      "Last Name": l.lastName,
      "Phone": l.phone ?? "",
      "Email": l.email ?? "",
      "City": l.city ?? "",
      "State": l.state ?? "",
      "Zip": l.zip ?? "",
      "Lead Source": l.leadSource ?? "",
      "Insurance": l.insurance ?? "",
      "Status": l.status ?? "",
      "Priority": l.priority ?? "",
      "Times Called": l.timesCalled ?? 0,
      "Street": l.street ?? "",
      "CRM Link": l.crmLink ?? "",
      "Date of Birth": l.dateOfBirth ?? "",
      "Renewal Date": l.renewalDate ?? "",
      "Archived": l.isArchived ? "Yes" : "No",
      "Won Premium": l.soldPremium ?? "",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Leads");
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
    res.setHeader("Content-Disposition", `attachment; filename=leads-export.xlsx`);
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.send(buf);
  });

  // ─── Cron / maintenance (internal — uses all leads) ─────────────────────────

  app.get("/api/cron/lead-maintenance", async (_req, res) => {
    const now = new Date();
    const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const allLeads = await storage.getAllLeads(true);

    let archivedMaxed = 0;
    let archivedLost = 0;

    for (const lead of allLeads) {
      if (lead.isArchived) continue;

      if ((lead.timesCalled ?? 0) >= 9) {
        await storage.updateLead(lead.id, { isArchived: true, archivedAt: now });
        archivedMaxed++;
        continue;
      }

      const isLost = lead.status === "Lost" || lead.status === "Declined";
      if (isLost && lead.lostAt && new Date(lead.lostAt) < oneMonthAgo) {
        await storage.updateLead(lead.id, { isArchived: true, archivedAt: now });
        archivedLost++;
      }
    }

    // Also run renewal and email checks
    await runRenewalCheck();
    await runEmailReminders();

    res.json({ archived_maxed: archivedMaxed, archived_lost: archivedLost });
  });

  return httpServer;
}
