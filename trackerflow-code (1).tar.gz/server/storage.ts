import {
  type Lead, type InsertLead, type Task, type InsertTask,
  type Activity, type InsertActivity, type User, type InsertUser,
  leads, tasks, activities, users,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ilike, isNull, lte, gte, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  linkGoogleId(userId: string, googleId: string): Promise<void>;

  getLeads(userId: string, includeArchived?: boolean): Promise<Lead[]>;
  getAllLeads(includeArchived?: boolean): Promise<Lead[]>;
  getLead(id: string, userId?: string): Promise<Lead | undefined>;
  createLead(lead: InsertLead, userId: string): Promise<Lead>;
  updateLead(id: string, data: Partial<Lead>, userId?: string): Promise<Lead | undefined>;
  deleteLead(id: string, userId?: string): Promise<void>;
  findLeadDuplicate(userId: string, phone: string | null, firstName: string, lastName: string): Promise<Lead | undefined>;
  getSoldLeadsNeedingRenewal(): Promise<(Lead & { userId: string })[]>;

  getTasks(leadId?: string, userId?: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, data: Partial<Task>): Promise<Task | undefined>;
  getPendingEmailTasks(): Promise<Task[]>;
  markEmailSent(taskId: string): Promise<void>;

  getActivities(leadId: string): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class DbStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return rows[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const rows = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return rows[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = randomUUID();
    const rows = await db.insert(users).values({ ...user, id }).returning();
    return rows[0];
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const rows = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return rows[0];
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const rows = await db.select().from(users).where(eq(users.googleId, googleId)).limit(1);
    return rows[0];
  }

  async linkGoogleId(userId: string, googleId: string): Promise<void> {
    await db.update(users).set({ googleId }).where(eq(users.id, userId));
  }

  async getLeads(userId: string, includeArchived = false): Promise<Lead[]> {
    const base = await db.select().from(leads).where(
      includeArchived
        ? eq(leads.userId, userId)
        : and(eq(leads.userId, userId), eq(leads.isArchived, false))
    );
    return base.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getAllLeads(includeArchived = false): Promise<Lead[]> {
    const base = includeArchived
      ? await db.select().from(leads)
      : await db.select().from(leads).where(eq(leads.isArchived, false));
    return base.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getLead(id: string, userId?: string): Promise<Lead | undefined> {
    const cond = userId
      ? and(eq(leads.id, id), eq(leads.userId, userId))
      : eq(leads.id, id);
    const rows = await db.select().from(leads).where(cond).limit(1);
    return rows[0];
  }

  async createLead(lead: InsertLead, userId: string): Promise<Lead> {
    const id = randomUUID();
    const now = new Date();
    const rows = await db.insert(leads).values({
      id,
      userId,
      firstName: lead.firstName,
      lastName: lead.lastName,
      phone: lead.phone ?? null,
      email: lead.email ?? null,
      street: lead.street ?? null,
      city: lead.city ?? null,
      state: lead.state ?? null,
      zip: lead.zip ?? null,
      leadSource: lead.leadSource ?? null,
      insurance: lead.insurance ?? "Auto",
      status: lead.status ?? "New",
      priority: lead.priority ?? "Warm",
      timesCalled: lead.timesCalled ?? 0,
      crmLink: lead.crmLink ?? null,
      dateOfBirth: lead.dateOfBirth ?? null,
      renewalDate: lead.renewalDate ?? null,
      renewalLeadCreated: lead.renewalLeadCreated ?? false,
      isArchived: lead.isArchived ?? false,
      archivedAt: lead.archivedAt ?? null,
      lostAt: lead.lostAt ?? null,
      soldAt: lead.soldAt ?? null,
      wonYear: lead.wonYear ?? null,
      wonMonth: lead.wonMonth ?? null,
      soldPremium: lead.soldPremium ?? null,
      createdAt: now,
      updatedAt: now,
    }).returning();
    return rows[0];
  }

  async updateLead(id: string, data: Partial<Lead>, userId?: string): Promise<Lead | undefined> {
    const cond = userId
      ? and(eq(leads.id, id), eq(leads.userId, userId))
      : eq(leads.id, id);
    const rows = await db.update(leads)
      .set({ ...data, updatedAt: new Date() })
      .where(cond)
      .returning();
    return rows[0];
  }

  async deleteLead(id: string, userId?: string): Promise<void> {
    const cond = userId
      ? and(eq(leads.id, id), eq(leads.userId, userId))
      : eq(leads.id, id);
    await db.delete(leads).where(cond);
  }

  async findLeadDuplicate(
    userId: string,
    phone: string | null,
    firstName: string,
    lastName: string,
  ): Promise<Lead | undefined> {
    if (phone) {
      const byPhone = await db.select().from(leads).where(
        and(eq(leads.userId, userId), eq(leads.phone, phone))
      ).limit(1);
      if (byPhone[0]) return byPhone[0];
    }
    const byName = await db.select().from(leads).where(
      and(
        eq(leads.userId, userId),
        ilike(leads.firstName, firstName),
        ilike(leads.lastName, lastName),
      )
    ).limit(1);
    return byName[0];
  }

  async getSoldLeadsNeedingRenewal(): Promise<(Lead & { userId: string })[]> {
    const all = await db.select().from(leads).where(
      and(
        eq(leads.status, "Sold"),
        eq(leads.renewalLeadCreated, false),
      )
    );
    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    return all.filter((l) => {
      if (!l.renewalDate) return false;
      const rd = new Date(l.renewalDate);
      return rd >= now && rd <= thirtyDaysFromNow;
    }) as (Lead & { userId: string })[];
  }

  async getTasks(leadId?: string, userId?: string): Promise<Task[]> {
    let base: Task[];
    if (leadId) {
      base = await db.select().from(tasks).where(eq(tasks.leadId, leadId));
    } else if (userId) {
      const userLeads = await db.select({ id: leads.id }).from(leads).where(eq(leads.userId, userId));
      const leadIds = userLeads.map((l) => l.id);
      if (leadIds.length === 0) return [];
      base = await db.select().from(tasks).where(inArray(tasks.leadId, leadIds));
    } else {
      base = await db.select().from(tasks);
    }
    return base.sort((a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime());
  }

  async createTask(task: InsertTask): Promise<Task> {
    const id = randomUUID();
    const now = new Date();
    const rows = await db.insert(tasks).values({
      id,
      leadId: task.leadId,
      title: task.title,
      type: task.type ?? "call",
      dueAt: task.dueAt,
      completedAt: task.completedAt ?? null,
      emailReminder: task.emailReminder ?? false,
      emailSentAt: null,
      createdAt: now,
    }).returning();
    return rows[0];
  }

  async updateTask(id: string, data: Partial<Task>): Promise<Task | undefined> {
    const rows = await db.update(tasks).set(data).where(eq(tasks.id, id)).returning();
    return rows[0];
  }

  async getPendingEmailTasks(): Promise<Task[]> {
    const now = new Date();
    const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const all = await db.select().from(tasks).where(
      and(
        eq(tasks.emailReminder, true),
        isNull(tasks.emailSentAt),
      )
    );
    return all.filter((t) => {
      const due = new Date(t.dueAt);
      return !t.completedAt && due >= now && due <= in24h;
    });
  }

  async markEmailSent(taskId: string): Promise<void> {
    await db.update(tasks).set({ emailSentAt: new Date() }).where(eq(tasks.id, taskId));
  }

  async getActivities(leadId: string): Promise<Activity[]> {
    const base = await db.select().from(activities).where(eq(activities.leadId, leadId));
    return base.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const now = new Date();
    const rows = await db.insert(activities).values({
      id,
      leadId: activity.leadId,
      type: activity.type ?? "note",
      content: activity.content,
      createdAt: now,
    }).returning();
    return rows[0];
  }
}

export const storage = new DbStorage();
